package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.DentalViewModel
import com.example.model.NavTab
import com.example.ui.components.WavyDividerDoodle
import com.example.ui.components.sketchbookPaperBackground
import com.example.ui.screens.BookAppointmentOverlaySheet
import com.example.ui.screens.ComfortScaleQuizSection
import com.example.ui.screens.FaqAccordionSection
import com.example.ui.screens.FinalBookingBannerSection
import com.example.ui.screens.FloatingQuickConversionPill
import com.example.ui.screens.HeroSection
import com.example.ui.screens.InsuranceAndSavingsSection
import com.example.ui.screens.LocationAndVisitSection
import com.example.ui.screens.MeetOurTeamSection
import com.example.ui.screens.ServiceDetailOverlaySheet
import com.example.ui.screens.ServiceSketchCard
import com.example.ui.screens.ServicesHeaderAndFilters
import com.example.ui.screens.SmileCraftBottomNavBar
import com.example.ui.screens.SmileCraftTopBar
import com.example.ui.screens.SmileTransformationSection
import com.example.ui.screens.TeamMemberDetailOverlaySheet
import com.example.ui.screens.TestimonialsSection
import com.example.ui.screens.TopAmbientPostItBanner
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.PrimaryTeal
import com.example.ui.theme.SecondaryCoralDark
import com.example.ui.theme.TertiaryGoldDark
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                SmileCraftApp()
            }
        }
    }
}

@Composable
fun SmileCraftApp(
    viewModel: DentalViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    var isProgrammaticScroll by remember { mutableStateOf(false) }

    val filteredServices = remember(uiState.selectedServiceCategory, viewModel.services) {
        if (uiState.selectedServiceCategory == "Todos") {
            viewModel.services
        } else {
            viewModel.services.filter { it.categoryTag == uiState.selectedServiceCategory }
        }
    }

    // Calculate continuous scroll offset for parallax sketchbook graph paper
    val scrollOffsetPx by remember {
        derivedStateOf {
            listState.firstVisibleItemIndex * 280f + listState.firstVisibleItemScrollOffset
        }
    }

    // Calculate overall page scroll progress (0f..1f) for the top pencil progress bar
    val scrollFraction by remember {
        derivedStateOf {
            val totalItems = listState.layoutInfo.totalItemsCount.coerceAtLeast(1)
            val visibleItems = listState.layoutInfo.visibleItemsInfo
            if (visibleItems.isEmpty()) {
                0f
            } else {
                val lastVisible = visibleItems.last().index
                if (lastVisible >= totalItems - 1 && !listState.canScrollForward) {
                    1f
                } else {
                    (listState.firstVisibleItemIndex.toFloat() / (totalItems - 2).coerceAtLeast(1)).coerceIn(0f, 1f)
                }
            }
        }
    }

    // Show floating quick conversion pill when scrolled past the Hero section, hide near the final banner
    val showFloatingConversionBar by remember {
        derivedStateOf {
            val idx = listState.firstVisibleItemIndex
            val total = listState.layoutInfo.totalItemsCount
            idx >= 2 && idx < (total - 3)
        }
    }

    val servicesStartIdx = 5
    // 5 (services_header) + filteredServices.size + 1 (transformation) + 1 (insurance) + 1 (divider_3)
    val teamStartIdx = 5 + 1 + filteredServices.size + 3
    val visitStartIdx = teamStartIdx + 3

    // Keep bottom navigation tab synchronized with vertical scroll position
    val currentVisibleSectionTab by remember(filteredServices.size) {
        derivedStateOf {
            val idx = listState.firstVisibleItemIndex
            when {
                idx < servicesStartIdx - 1 -> NavTab.HOME
                idx < teamStartIdx - 1 -> NavTab.SERVICES
                idx < visitStartIdx -> NavTab.TEAM
                else -> NavTab.VISIT
            }
        }
    }

    LaunchedEffect(currentVisibleSectionTab) {
        if (!isProgrammaticScroll && uiState.activeTab != currentVisibleSectionTab) {
            viewModel.selectTab(currentVisibleSectionTab)
        }
    }

    BackHandler(enabled = uiState.activeTab != NavTab.HOME) {
        coroutineScope.launch {
            isProgrammaticScroll = true
            viewModel.selectTab(NavTab.HOME)
            listState.animateScrollToItem(0)
            isProgrammaticScroll = false
        }
    }

    val launchDialer = {
        runCatching {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:3052347645"))
            context.startActivity(intent)
        }
    }

    val launchSms = {
        runCatching {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("sms:3052347645"))
            context.startActivity(intent)
        }
    }

    val launchDirections = {
        runCatching {
            val intent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("geo:0,0?q=742+Evergreen+Terrace+Suite+102+SmileCraft+Dental+Studio")
            )
            context.startActivity(intent)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .sketchbookPaperBackground(scrollOffsetPx = scrollOffsetPx)
    ) {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = Color.Transparent,
            topBar = {
                SmileCraftTopBar(
                    bookedCount = uiState.bookedAppointments.size,
                    scrollFraction = scrollFraction,
                    onBookClick = { viewModel.openBookingSheet() },
                    onProfileClick = { viewModel.openBookingSheet() }
                )
            },
            bottomBar = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(modifier = Modifier.widthIn(max = 600.dp)) {
                        FloatingQuickConversionPill(
                            visible = showFloatingConversionBar,
                            onBookNowClick = { viewModel.openBookingSheet() }
                        )
                    }
                    SmileCraftBottomNavBar(
                        activeTab = uiState.activeTab,
                        onSelectTab = { tab ->
                            viewModel.selectTab(tab)
                            val targetIndex = when (tab) {
                                NavTab.HOME -> 0
                                NavTab.SERVICES -> servicesStartIdx
                                NavTab.TEAM -> teamStartIdx
                                NavTab.VISIT -> visitStartIdx
                            }
                            coroutineScope.launch {
                                isProgrammaticScroll = true
                                listState.animateScrollToItem(targetIndex)
                                isProgrammaticScroll = false
                            }
                        }
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.TopCenter
            ) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 600.dp)
                        .testTag("main_vertical_scroll_list")
                ) {
                    // 0: Top Ambient Post-It Banner
                    item(key = "ambient_banner") {
                        TopAmbientPostItBanner(
                            onClick = { viewModel.openBookingSheet() }
                        )
                    }

                    // 1: Hero Section with Scribble Aesthetics
                    item(key = "hero_section") {
                        HeroSection(
                            comfortAmenities = viewModel.comfortMenuAmenities,
                            selectedAmenities = uiState.selectedComfortAmenities,
                            onToggleAmenity = { viewModel.toggleComfortAmenity(it) },
                            onBookClick = { viewModel.openBookingSheet() },
                            onCallClick = { launchDialer() }
                        )
                    }

                    // 2: Hand-drawn Divider 1
                    item(key = "divider_1") {
                        WavyDividerDoodle(
                            color = PrimaryTeal.copy(alpha = 0.32f),
                            isDashed = true
                        )
                    }

                    // 3: Interactive Anxiety Level Quiz / Reassurance Widget
                    item(key = "comfort_quiz") {
                        ComfortScaleQuizSection(
                            selectedMood = uiState.selectedMood,
                            selectedAmenities = uiState.selectedComfortAmenities,
                            onSelectMood = { viewModel.selectMood(it) },
                            onToggleAmenity = { viewModel.toggleComfortAmenity(it) }
                        )
                    }

                    // 4: Hand-drawn Divider 2
                    item(key = "divider_2") {
                        WavyDividerDoodle(
                            color = SecondaryCoralDark.copy(alpha = 0.32f),
                            isDashed = false
                        )
                    }

                    // 5: Services Header, Filter Chips & Quick-Compare Horizontal Carousel
                    item(key = "services_header") {
                        ServicesHeaderAndFilters(
                            services = viewModel.services,
                            selectedCategory = uiState.selectedServiceCategory,
                            onSelectCategory = { viewModel.selectServiceCategory(it) },
                            onServiceDetailsClick = { viewModel.openServiceDetail(it) },
                            onSeeAllClick = { viewModel.selectServiceCategory("Todos") }
                        )
                    }

                    // Individual Service Boxes with independent scroll-driven Modifier.graphicsLayer parallax & fade
                    itemsIndexed(
                        items = filteredServices,
                        key = { _, service -> "service_box_${service.id}" }
                    ) { index, service ->
                        ServiceSketchCard(
                            service = service,
                            wobbleSeed = index + 1,
                            onDetailsClick = { viewModel.openServiceDetail(service) },
                            onUrgentCallClick = { launchDialer() }
                        )
                    }

                    // Interactive Before & After Smile Transformation Slider
                    item(key = "smile_transformation_slider") {
                        SmileTransformationSection(
                            onBookCaseClick = { viewModel.openBookingSheet() }
                        )
                    }

                    // Interactive Insurance & Savings Calculator
                    item(key = "insurance_calculator") {
                        InsuranceAndSavingsSection(
                            onVerifyInsuranceClick = { viewModel.openBookingSheet() }
                        )
                    }

                    // Hand-drawn Divider 3
                    item(key = "divider_3") {
                        WavyDividerDoodle(
                            color = PrimaryTeal.copy(alpha = 0.32f),
                            isDashed = true
                        )
                    }

                    // Meet Our Team / Polaroid Presentation
                    item(key = "team_section") {
                        MeetOurTeamSection(
                            teamMembers = viewModel.teamMembers,
                            onMemberClick = { viewModel.openTeamMemberDetail(it) }
                        )
                    }

                    // Hand-drawn Divider 4
                    item(key = "divider_4") {
                        WavyDividerDoodle(
                            color = TertiaryGoldDark.copy(alpha = 0.32f),
                            isDashed = false,
                            invertWave = true
                        )
                    }

                    // Scribble Testimonials / Patient Love (Horizontal Pager + Chips)
                    item(key = "testimonials_section") {
                        TestimonialsSection(
                            testimonials = viewModel.testimonials
                        )
                    }

                    // Location & Visit Info Section
                    item(key = "location_visit_section") {
                        LocationAndVisitSection(
                            onSmsClick = { launchSms() },
                            onCallClick = { launchDialer() },
                            onDirectionsClick = { launchDirections() }
                        )
                    }

                    // Interactive FAQ Accordion Overcoming Anxiety & Objections
                    item(key = "faq_accordion_section") {
                        FaqAccordionSection()
                    }

                    // Final Sticky-like Booking Banner
                    item(key = "final_booking_banner") {
                        FinalBookingBannerSection(
                            onClaimSlotClick = { viewModel.openBookingSheet() }
                        )
                    }

                    // Bottom breathing room
                    item(key = "bottom_spacer") {
                        Spacer(modifier = Modifier.height(20.dp))
                    }
                }
            }
        }

        // Interactive Overlay Modals (Service Details, Team Member Bio, 60s Booking Flow)
        val activeService = uiState.activeServiceDetail
        if (activeService != null) {
            ServiceDetailOverlaySheet(
                service = activeService,
                onBookService = { service -> viewModel.openBookingSheet(service) },
                onDismiss = { viewModel.closeServiceDetail() }
            )
        }

        val activeMember = uiState.activeTeamMemberDetail
        if (activeMember != null) {
            TeamMemberDetailOverlaySheet(
                member = activeMember,
                onBookWithMember = {
                    viewModel.closeTeamMemberDetail()
                    viewModel.openBookingSheet()
                },
                onDismiss = { viewModel.closeTeamMemberDetail() }
            )
        }

        if (uiState.isBookingSheetOpen) {
            BookAppointmentOverlaySheet(
                services = viewModel.services,
                teamMembers = viewModel.teamMembers,
                comfortAmenities = viewModel.comfortMenuAmenities,
                preselectedService = uiState.preselectedBookingService ?: viewModel.services.first(),
                selectedMood = uiState.selectedMood,
                selectedAmenities = uiState.selectedComfortAmenities,
                bookedAppointments = uiState.bookedAppointments,
                lastConfirmation = uiState.lastBookedConfirmation,
                onSelectMood = { viewModel.selectMood(it) },
                onToggleAmenity = { viewModel.toggleComfortAmenity(it) },
                onConfirmBooking = { service, doctor, day, time, name, phone, gift ->
                    viewModel.confirmBooking(service, doctor, day, time, name, phone, gift)
                },
                onDismiss = { viewModel.closeBookingSheet() }
            )
        }
    }
}
