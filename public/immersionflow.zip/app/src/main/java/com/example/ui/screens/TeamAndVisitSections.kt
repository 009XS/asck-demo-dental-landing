package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.NavTab
import com.example.model.PatientTestimonial
import com.example.model.TeamMember
import com.example.ui.components.DashedLineSeparator
import com.example.ui.components.DoodleBottomNavIcon
import com.example.ui.components.DoodleCalendarIcon
import com.example.ui.components.DoodleClockIcon
import com.example.ui.components.DoodleHandDrawnStar
import com.example.ui.components.DoodleIllustratedMapCanvas
import com.example.ui.components.DoodleMapPinIcon
import com.example.ui.components.DoodleNavigationPaperPlaneIcon
import com.example.ui.components.DoodlePhoneIcon
import com.example.ui.components.DoodleSmsIcon
import com.example.ui.components.SketchCard
import com.example.ui.components.SketchPill
import com.example.ui.components.SketchTape
import com.example.ui.components.horizontalScrollDrivenEffect
import com.example.ui.components.rememberScrollParallaxProgress
import com.example.ui.components.scrollDrivenParallaxAndFade
import com.example.ui.theme.CaveatFontFamily
import com.example.ui.theme.KalamFontFamily
import com.example.ui.theme.LiveStatusMint
import com.example.ui.theme.MapCanvasGray
import com.example.ui.theme.OnPrimaryContainerIce
import com.example.ui.theme.OnPrimaryWhite
import com.example.ui.theme.OnSecondaryContainerBrown
import com.example.ui.theme.OnSurfaceCharcoal
import com.example.ui.theme.OnSurfaceVariantSlate
import com.example.ui.theme.OnTertiaryFixedDark
import com.example.ui.theme.PatrickHandFontFamily
import com.example.ui.theme.PostItWarmYellow
import com.example.ui.theme.PrimaryFixedCyan
import com.example.ui.theme.PrimaryTeal
import com.example.ui.theme.QuotePaperCream
import com.example.ui.theme.SecondaryContainerCoral
import com.example.ui.theme.SecondaryCoralDark
import com.example.ui.theme.SketchSurface
import com.example.ui.theme.SurfaceContainer
import com.example.ui.theme.SurfaceContainerHigh
import com.example.ui.theme.SurfaceContainerLow
import com.example.ui.theme.SurfaceContainerLowest
import com.example.ui.theme.TagSoftTeal
import com.example.ui.theme.TertiaryFixedGold
import com.example.ui.theme.TertiaryGoldDark
import com.example.ui.theme.TestimonialNoteCream
import kotlin.math.abs
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MeetOurTeamSection(
    teamMembers: List<TeamMember>,
    onMemberClick: (TeamMember) -> Unit,
    modifier: Modifier = Modifier
) {
    val drMaya = teamMembers.first()
    val careTeam = teamMembers.drop(1)
    val (polaroidProgress, polaroidTrackMod) = rememberScrollParallaxProgress()
    val (careTeamProgress, careTeamTrackMod) = rememberScrollParallaxProgress()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 16.dp)
    ) {
        // Section Header
        Column(
            modifier = Modifier.graphicsLayer {
                val p = polaroidProgress.value
                translationY = p * 8.dp.toPx()
                alpha = (1f - abs(p) * 0.3f).coerceIn(0.4f, 1f)
            }
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "LOS HUMANOS DETRÁS DE LAS SONRISAS",
                    fontFamily = PatrickHandFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.5.sp,
                    letterSpacing = 0.5.sp,
                    color = PrimaryTeal
                )
                Text(
                    text = "♥ primero amigos",
                    fontFamily = CaveatFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = SecondaryCoralDark,
                    modifier = Modifier.rotate(-3f)
                )
            }

            Text(
                text = "Conoce a la Dra. Maya y al Equipo de Cuidado",
                fontFamily = KalamFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 21.sp,
                lineHeight = 26.sp,
                color = OnSurfaceCharcoal
            )
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Polaroid Card Frame for Dr. Maya Lin with scroll-driven parallax & window-parallax portrait
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .then(polaroidTrackMod)
                .scrollDrivenParallaxAndFade(
                    maxParallaxDp = 20.dp,
                    minAlpha = 0.25f,
                    minScale = 0.91f,
                    maxTiltDegrees = 1.8f,
                    maxRotationX = 6f,
                    indexParity = 0
                )
        ) {
            SketchCard(
                backgroundColor = SurfaceContainerLowest,
                cornerRadius = 18.dp,
                rotationDegrees = -1f,
                onClick = { onMemberClick(drMaya) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dr_maya_polaroid_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Doctor Image Photo in Sketchy Polaroid Inner Frame with internal window parallax
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .drawBehind {
                                drawRoundRect(
                                    color = OnSurfaceCharcoal,
                                    topLeft = Offset(2.dp.toPx(), 2.dp.toPx()),
                                    size = size,
                                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(12.dp.toPx(), 12.dp.toPx())
                                )
                            }
                            .clip(RoundedCornerShape(12.dp))
                            .background(SurfaceContainer)
                            .border(2.dp, OnSurfaceCharcoal, RoundedCornerShape(12.dp))
                    ) {
                        AsyncImage(
                            model = drMaya.imageUrl,
                            contentDescription = "Dr. Maya Lin smiling warmly in modern teal scrubs",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer {
                                    // Window parallax inside the polaroid frame as user scrolls
                                    val p = polaroidProgress.value
                                    scaleX = 1.10f
                                    scaleY = 1.10f
                                    translationY = -p * 18.dp.toPx()
                                }
                        )

                        // Certificada Fear-Free™ pill over bottom-right corner with counter-parallax
                        SketchPill(
                            backgroundColor = SurfaceContainerLowest.copy(alpha = 0.96f),
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(10.dp)
                                .graphicsLayer {
                                    val p = polaroidProgress.value
                                    translationY = p * 8.dp.toPx()
                                    translationX = -p * 5.dp.toPx()
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(14.dp)
                                        .background(SecondaryContainerCoral, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "✦",
                                        fontSize = 9.sp,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    text = "Certificada Fear-Free™",
                                    fontFamily = PatrickHandFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.5.sp,
                                    color = OnSurfaceCharcoal
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Name + Tufts '11 badge
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = drMaya.name,
                                fontFamily = KalamFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 19.sp,
                                color = OnSurfaceCharcoal
                            )
                            Text(
                                text = drMaya.role,
                                fontFamily = PatrickHandFontFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.5.sp,
                                color = PrimaryTeal
                            )
                        }

                        SketchPill(
                            backgroundColor = TertiaryFixedGold.copy(alpha = 0.4f),
                            rotationDegrees = 2f,
                            modifier = Modifier.graphicsLayer {
                                rotationZ = 2f + polaroidProgress.value * 8f
                            }
                        ) {
                            Text(
                                text = drMaya.badge,
                                fontFamily = CaveatFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = TertiaryGoldDark,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Handwritten Quote Box with Sketchy Speech Tail
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .graphicsLayer {
                                translationY = -polaroidProgress.value * 4.dp.toPx()
                            }
                    ) {
                        SketchCard(
                            backgroundColor = QuotePaperCream,
                            shadowOffsetX = 2.dp,
                            shadowOffsetY = 2.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = drMaya.quote,
                                fontFamily = PatrickHandFontFamily,
                                fontStyle = FontStyle.Italic,
                                fontSize = 13.5.sp,
                                lineHeight = 18.5.sp,
                                color = OnSurfaceVariantSlate,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                        // Speech tail at top-left
                        Canvas(
                            modifier = Modifier
                                .size(width = 14.dp, height = 9.dp)
                                .offset(x = 22.dp, y = (-7).dp)
                        ) {
                            val tail = Path().apply {
                                moveTo(0f, size.height)
                                lineTo(size.width * 0.5f, 0f)
                                lineTo(size.width, size.height)
                            }
                            drawPath(tail, color = QuotePaperCream)
                            drawPath(
                                tail,
                                color = OnSurfaceCharcoal,
                                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Credentials tags with horizontal scroll-driven graphicsLayer effect
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(drMaya.specialties) { tag ->
                            SketchPill(
                                backgroundColor = SurfaceContainerHigh,
                                shadowOffset = 1.5.dp,
                                modifier = Modifier.horizontalScrollDrivenEffect()
                            ) {
                                Text(
                                    text = tag,
                                    fontFamily = PatrickHandFontFamily,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 11.5.sp,
                                    color = OnSurfaceVariantSlate,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Tape sticker accent on top: ★ ALMA SUAVE ★ with counter-parallax
            SketchTape(
                rotationDegrees = 1f,
                modifier = Modifier
                    .width(118.dp)
                    .height(28.dp)
                    .align(Alignment.TopCenter)
                    .offset(y = (-12).dp)
                    .graphicsLayer {
                        val p = polaroidProgress.value
                        translationX = -p * 10.dp.toPx()
                        rotationZ = 1f - p * 6f
                    }
            ) {
                Text(
                    text = "★ ALMA SUAVE ★",
                    fontFamily = CaveatFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.5.sp,
                    color = OnTertiaryFixedDark
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Care Team Avatars Card (Julian T., Chloe R., Sam P.) + Horizontal Interactive Team Superpowers Carousel
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .then(careTeamTrackMod)
                .scrollDrivenParallaxAndFade(
                    maxParallaxDp = 16.dp,
                    minAlpha = 0.28f,
                    minScale = 0.92f,
                    indexParity = 1
                )
        ) {
            SketchCard(
                backgroundColor = SurfaceContainerLow,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "El Equipo de Higiene y Confort",
                            fontFamily = PatrickHandFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = OnSurfaceCharcoal
                        )
                        Text(
                            text = "¡siempre a tu lado!",
                            fontFamily = CaveatFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = PrimaryTeal,
                            modifier = Modifier.rotate(-1.5f)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        careTeam.forEachIndexed { idx, member ->
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onMemberClick(member) }
                                    .padding(horizontal = 4.dp)
                                    .graphicsLayer {
                                        val p = careTeamProgress.value
                                        val stagger = (idx - 1) * 6.dp.toPx()
                                        translationY = p * stagger
                                    }
                                    .testTag("team_member_${member.id}"),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(58.dp)
                                        .rotate(member.rotationDeg)
                                        .drawBehind {
                                            drawCircle(
                                                color = OnSurfaceCharcoal,
                                                radius = size.minDimension / 2f,
                                                center = center + Offset(2.dp.toPx(), 2.dp.toPx())
                                            )
                                        }
                                        .clip(CircleShape)
                                        .border(2.dp, OnSurfaceCharcoal, CircleShape)
                                ) {
                                    AsyncImage(
                                        model = member.imageUrl,
                                        contentDescription = member.name,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = member.name,
                                    fontFamily = PatrickHandFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.5.sp,
                                    color = OnSurfaceCharcoal,
                                    textAlign = TextAlign.Center
                                )
                                Text(
                                    text = member.role,
                                    fontFamily = PatrickHandFontFamily,
                                    fontSize = 11.5.sp,
                                    color = OnSurfaceVariantSlate,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    DashedLineSeparator()
                    Spacer(modifier = Modifier.height(10.dp))

                    // Interactive Horizontal Scroll of Team Playlists & Superpowers with horizontalScrollDrivenEffect
                    LazyRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("team_superpowers_horizontal_scroll"),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(teamMembers, key = { "bio_${it.id}" }) { member ->
                            SketchPill(
                                backgroundColor = SurfaceContainerLowest,
                                onClick = { onMemberClick(member) },
                                modifier = Modifier.horizontalScrollDrivenEffect(
                                    maxParallaxDp = 14.dp,
                                    minAlpha = 0.45f,
                                    minScale = 0.91f
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "🎧",
                                        fontSize = 14.sp
                                    )
                                    Column {
                                        Text(
                                            text = "${member.name} • ${member.badge}",
                                            fontFamily = PatrickHandFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = PrimaryTeal
                                        )
                                        Text(
                                            text = "Playlist: ${member.favoritePlaylist}",
                                            fontFamily = PatrickHandFontFamily,
                                            fontSize = 11.sp,
                                            color = OnSurfaceVariantSlate
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TestimonialsSection(
    testimonials: List<PatientTestimonial>,
    modifier: Modifier = Modifier
) {
    val pagerState = rememberPagerState(pageCount = { testimonials.size })
    val scope = rememberCoroutineScope()
    val (testimonialScrollProgress, testimonialTrackMod) = rememberScrollParallaxProgress()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .then(testimonialTrackMod)
            .scrollDrivenParallaxAndFade(
                maxParallaxDp = 18.dp,
                minAlpha = 0.26f,
                minScale = 0.91f,
                indexParity = 2
            )
            .padding(vertical = 10.dp)
    ) {
        HorizontalPager(
            state = pagerState,
            contentPadding = PaddingValues(horizontal = 16.dp),
            pageSpacing = 12.dp,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("testimonials_horizontal_pager")
        ) { page ->
            val item = testimonials[page]
            val pageOffset = (pagerState.currentPage - page) + pagerState.currentPageOffsetFraction
            val absOffset = abs(pageOffset).coerceIn(0f, 1f)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp)
                    .graphicsLayer {
                        // 3D Page-turn parallax & fade as user swipes horizontally
                        alpha = 1f - absOffset * 0.38f
                        val scale = 1f - absOffset * 0.08f
                        scaleX = scale
                        scaleY = scale
                        rotationY = -pageOffset * 12f
                        rotationZ = -pageOffset * 2.5f
                        cameraDistance = 14f * density
                    }
            ) {
                SketchCard(
                    backgroundColor = TestimonialNoteCream,
                    shadowColor = SecondaryCoralDark,
                    wobbleSeed = page + 3,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // 5 Hand-drawn stars with staggered horizontal & vertical parallax
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                val rotations = listOf(-2f, 1f, -1f, 3f, -2f)
                                rotations.forEachIndexed { starIdx, rot ->
                                    DoodleHandDrawnStar(
                                        fillColor = SecondaryContainerCoral,
                                        modifier = Modifier
                                            .size(20.dp)
                                            .graphicsLayer {
                                                rotationZ = rot + pageOffset * (starIdx + 1) * 8f
                                                translationY = -testimonialScrollProgress.value * (starIdx + 1) * 1.5.dp.toPx()
                                            }
                                    )
                                }
                            }

                            SketchPill(
                                backgroundColor = SurfaceContainerLowest,
                                shadowOffset = 1.5.dp
                            ) {
                                Text(
                                    text = item.badgeLabel,
                                    fontFamily = PatrickHandFontFamily,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 11.5.sp,
                                    color = OnSurfaceVariantSlate,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Box(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "“",
                                fontFamily = CaveatFontFamily,
                                fontSize = 52.sp,
                                color = SecondaryContainerCoral.copy(alpha = 0.32f),
                                modifier = Modifier
                                    .offset(x = (-4).dp, y = (-16).dp)
                                    .graphicsLayer {
                                        translationX = pageOffset * 36.dp.toPx()
                                        translationY = -testimonialScrollProgress.value * 8.dp.toPx()
                                    }
                            )
                            Text(
                                text = item.quote,
                                fontFamily = KalamFontFamily,
                                fontWeight = FontWeight.Normal,
                                fontSize = 17.5.sp,
                                lineHeight = 24.5.sp,
                                color = OnSurfaceCharcoal,
                                modifier = Modifier
                                    .padding(start = 10.dp)
                                    .graphicsLayer {
                                        translationX = pageOffset * 14.dp.toPx()
                                    }
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        DashedLineSeparator()
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .drawBehind {
                                            drawCircle(
                                                color = OnSurfaceCharcoal,
                                                radius = size.minDimension / 2f,
                                                center = center + Offset(1.5.dp.toPx(), 1.5.dp.toPx())
                                            )
                                        }
                                        .background(SecondaryContainerCoral, CircleShape)
                                        .border(2.dp, OnSurfaceCharcoal, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = item.initials,
                                        fontFamily = PatrickHandFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = OnSecondaryContainerBrown
                                    )
                                }

                                Column {
                                    Text(
                                        text = item.name,
                                        fontFamily = PatrickHandFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.5.sp,
                                        color = OnSurfaceCharcoal
                                    )
                                    Text(
                                        text = item.treatment,
                                        fontFamily = PatrickHandFontFamily,
                                        fontSize = 11.5.sp,
                                        color = OnSurfaceVariantSlate
                                    )
                                }
                            }

                            Text(
                                text = item.timeAgo,
                                fontFamily = CaveatFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = OnSurfaceVariantSlate
                            )
                        }
                    }
                }

                // Top sticky label: nota real de paciente with counter-parallax
                SketchTape(
                    rotationDegrees = -2f,
                    modifier = Modifier
                        .padding(start = 16.dp)
                        .height(24.dp)
                        .graphicsLayer {
                            translationX = -pageOffset * 20.dp.toPx()
                        }
                ) {
                    Text(
                        text = "nota real de paciente",
                        fontFamily = CaveatFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = OnTertiaryFixedDark,
                        modifier = Modifier.padding(horizontal = 10.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Horizontal Scrollable Review Selector Pills with horizontalScrollDrivenEffect
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(testimonials.size) { index ->
                val review = testimonials[index]
                val isCurrent = pagerState.currentPage == index
                SketchPill(
                    backgroundColor = if (isCurrent) SecondaryContainerCoral else SurfaceContainerLowest,
                    onClick = {
                        scope.launch { pagerState.animateScrollToPage(index) }
                    },
                    modifier = Modifier.horizontalScrollDrivenEffect()
                ) {
                    Text(
                        text = "★ ${review.name} • ${review.moodAfter}",
                        fontFamily = PatrickHandFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = if (isCurrent) OnSecondaryContainerBrown else OnSurfaceVariantSlate,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun LocationAndVisitSection(
    onSmsClick: () -> Unit,
    onCallClick: () -> Unit,
    onDirectionsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "liveStatusPulse")
    val dotScale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "dotScale"
    )

    var mapPanOffset by remember { mutableStateOf(Offset.Zero) }
    var mapZoom by remember { mutableFloatStateOf(1f) }
    val (visitScrollProgress, visitTrackMod) = rememberScrollParallaxProgress()

    val studioSpots = listOf(
        "Sala de Espera Soleada" to "Luz natural, plantas y barra de té orgánico",
        "Suites Silenciosas" to "Aislamiento acústico + pantallas Netflix en el techo",
        "Estación de Confort" to "Mantas con peso, almohadas térmicas y aromaterapia",
        "Parking Privado Gratis" to "Detrás del estudio con acceso directo sin escalones"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .then(visitTrackMod)
            .scrollDrivenParallaxAndFade(
                maxParallaxDp = 18.dp,
                minAlpha = 0.25f,
                minScale = 0.91f,
                maxTiltDegrees = 1.5f,
                indexParity = 0
            )
            .padding(horizontal = 16.dp, vertical = 16.dp)
    ) {
        // Section Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Text(
                text = "ENCUENTRA NUESTRO REFUGIO",
                fontFamily = PatrickHandFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                letterSpacing = 0.6.sp,
                color = PrimaryTeal
            )
            DoodleMapPinIcon(
                fillColor = PrimaryTeal.copy(alpha = 0.2f),
                strokeColor = PrimaryTeal,
                modifier = Modifier.size(15.dp)
            )
        }

        Text(
            text = "Visita Nuestro Estudio en el Centro",
            fontFamily = KalamFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 21.sp,
            color = OnSurfaceCharcoal
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Map Container Card with Hand-Drawn Sketch aesthetics
        SketchCard(
            backgroundColor = SurfaceContainerLowest,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Interactive Pan/Zoom Hand-Drawn Style Illustrated Map with scroll-driven parallax
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(176.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MapCanvasGray)
                        .border(2.dp, OnSurfaceCharcoal, RoundedCornerShape(12.dp))
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                val newZoom = (mapZoom * zoom).coerceIn(1f, 1.8f)
                                mapZoom = newZoom
                                val maxOffset = 45f * newZoom
                                mapPanOffset = Offset(
                                    x = (mapPanOffset.x + pan.x).coerceIn(-maxOffset, maxOffset),
                                    y = (mapPanOffset.y + pan.y).coerceIn(-maxOffset, maxOffset)
                                )
                            }
                        }
                        .clickable {
                            mapZoom = if (mapZoom > 1.05f) 1f else 1.25f
                            mapPanOffset = Offset.Zero
                        }
                        .testTag("interactive_sketch_map"),
                    contentAlignment = Alignment.Center
                ) {
                    DoodleIllustratedMapCanvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                val p = visitScrollProgress.value
                                scaleX = mapZoom * 1.06f
                                scaleY = mapZoom * 1.06f
                                translationX = mapPanOffset.x + p * 8.dp.toPx()
                                translationY = mapPanOffset.y - p * 12.dp.toPx()
                            }
                    )

                    // Sketchy Pin overlay badge: SmileCraft Studio with counter-parallax
                    SketchPill(
                        backgroundColor = SurfaceContainerLowest,
                        rotationDegrees = -2f,
                        onClick = onDirectionsClick,
                        modifier = Modifier.graphicsLayer {
                            val p = visitScrollProgress.value
                            translationX = mapPanOffset.x * 0.5f - p * 6.dp.toPx()
                            translationY = mapPanOffset.y * 0.5f + p * 10.dp.toPx()
                        }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            DoodleMapPinIcon(
                                fillColor = SecondaryContainerCoral,
                                strokeColor = OnSurfaceCharcoal,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "SmileCraft Studio",
                                fontFamily = PatrickHandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.5.sp,
                                color = OnSurfaceCharcoal
                            )
                        }
                    }
                }

                // Address & Live Status
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "SmileCraft Dental Studio",
                            fontFamily = KalamFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.5.sp,
                            color = OnSurfaceCharcoal
                        )
                        Text(
                            text = "742 Evergreen Terrace, Suite 102",
                            fontFamily = PatrickHandFontFamily,
                            fontSize = 13.5.sp,
                            color = OnSurfaceVariantSlate
                        )
                        Text(
                            text = "Distrito Creativo del Centro (Estacionamiento gratuito detrás)",
                            fontFamily = PatrickHandFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 13.5.sp,
                            color = OnSurfaceVariantSlate
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Live Status Badge
                    SketchPill(
                        backgroundColor = LiveStatusMint
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .graphicsLayer {
                                        scaleX = dotScale
                                        scaleY = dotScale
                                    }
                                    .background(PrimaryTeal, CircleShape)
                            )
                            Text(
                                text = "Abierto hasta\nlas 6 PM",
                                fontFamily = PatrickHandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                lineHeight = 13.sp,
                                color = PrimaryTeal
                            )
                        }
                    }
                }

                // Hours Pill
                SketchPill(
                    backgroundColor = SurfaceContainerLow,
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        DoodleClockIcon(
                            color = OnSurfaceVariantSlate,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "Lun–Vie: 8am – 6pm • Sáb: 9am – 2pm",
                            fontFamily = PatrickHandFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 13.5.sp,
                            color = OnSurfaceCharcoal
                        )
                    }
                }

                // Quick Action Buttons with Hand-drawn Icons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SketchPill(
                        backgroundColor = SurfaceContainerHigh,
                        onClick = onSmsClick,
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                            .testTag("visit_sms_button")
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            DoodleSmsIcon(color = PrimaryTeal, modifier = Modifier.size(18.dp))
                            Text(
                                text = "Escribirnos",
                                fontFamily = PatrickHandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = OnSurfaceCharcoal
                            )
                        }
                    }

                    SketchPill(
                        backgroundColor = SurfaceContainerHigh,
                        onClick = onCallClick,
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                            .testTag("visit_call_button")
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            DoodlePhoneIcon(color = SecondaryCoralDark, modifier = Modifier.size(18.dp))
                            Text(
                                text = "Llamar a Recepción",
                                fontFamily = PatrickHandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp,
                                color = OnSurfaceCharcoal
                            )
                        }
                    }

                    SketchPill(
                        backgroundColor = SurfaceContainerHigh,
                        onClick = onDirectionsClick,
                        modifier = Modifier
                            .weight(1f)
                            .height(54.dp)
                            .testTag("visit_directions_button")
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            DoodleNavigationPaperPlaneIcon(
                                color = TertiaryGoldDark,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Cómo Llegar",
                                fontFamily = PatrickHandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = OnSurfaceCharcoal
                            )
                        }
                    }
                }

                // Horizontal Scrollable Studio Tour Strip with horizontalScrollDrivenEffect
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("studio_tour_horizontal_scroll"),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(studioSpots) { (spotTitle, spotDesc) ->
                        SketchPill(
                            backgroundColor = TagSoftTeal,
                            shadowOffset = 1.5.dp,
                            modifier = Modifier.horizontalScrollDrivenEffect(
                                maxParallaxDp = 12.dp,
                                minAlpha = 0.45f,
                                minScale = 0.91f
                            )
                        ) {
                            Column(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "✦ $spotTitle",
                                    fontFamily = PatrickHandFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = PrimaryTeal
                                )
                                Text(
                                    text = spotDesc,
                                    fontFamily = PatrickHandFontFamily,
                                    fontSize = 11.sp,
                                    color = OnSurfaceVariantSlate
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FinalBookingBannerSection(
    onClaimSlotClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (bannerProgress, bannerTrackMod) = rememberScrollParallaxProgress()
    Box(
        modifier = modifier
            .fillMaxWidth()
            .then(bannerTrackMod)
            .scrollDrivenParallaxAndFade(
                maxParallaxDp = 16.dp,
                minAlpha = 0.30f,
                minScale = 0.92f,
                maxTiltDegrees = 1.5f,
                indexParity = 1
            )
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        SketchCard(
            backgroundColor = PrimaryTeal,
            shadowColor = OnSurfaceCharcoal,
            shadowOffsetX = 4.dp,
            shadowOffsetY = 4.5.dp,
            rotationDegrees = -0.5f,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                // Background doodle star top-left with scroll-driven rotation & parallax
                Canvas(
                    modifier = Modifier
                        .size(64.dp)
                        .offset(x = (-12).dp, y = (-12).dp)
                        .graphicsLayer {
                            val p = bannerProgress.value
                            rotationZ = p * 40f
                            translationY = -p * 14.dp.toPx()
                        }
                ) {
                    val s = size.width / 40f
                    val star = Path().apply {
                        moveTo(20f * s, 2f * s)
                        cubicTo(20.8f * s, 11.5f * s, 28.5f * s, 19.2f * s, 38f * s, 20f * s)
                        cubicTo(28.5f * s, 20.8f * s, 20.8f * s, 28.5f * s, 20f * s, 38f * s)
                        cubicTo(19.2f * s, 28.5f * s, 11.5f * s, 20.8f * s, 2f * s, 20f * s)
                        cubicTo(11.5f * s, 19.2f * s, 19.2f * s, 11.5f * s, 20f * s, 2f * s)
                        close()
                    }
                    drawPath(star, color = PrimaryFixedCyan.copy(alpha = 0.2f))
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp, vertical = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "¿Listo para sonreír sin\npreocupaciones?",
                        fontFamily = KalamFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                        lineHeight = 27.sp,
                        color = OnPrimaryWhite,
                        textAlign = TextAlign.Center
                    )

                    Canvas(
                        modifier = Modifier
                            .width(210.dp)
                            .height(6.dp)
                    ) {
                        val path = Path().apply {
                            moveTo(2f, 3.dp.toPx())
                            quadraticTo(size.width * 0.25f, 1.dp.toPx(), size.width * 0.5f, 3.dp.toPx())
                            quadraticTo(size.width * 0.75f, 5.dp.toPx(), size.width - 2f, 3.dp.toPx())
                        }
                        drawPath(
                            path,
                            color = SecondaryContainerCoral.copy(alpha = 0.8f),
                            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Elige el horario que mejor te convenga. Cancela o reprograma en cualquier momento sin complicaciones.",
                        fontFamily = PatrickHandFontFamily,
                        fontSize = 14.sp,
                        lineHeight = 19.sp,
                        color = OnPrimaryContainerIce,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    SketchCard(
                        backgroundColor = SecondaryContainerCoral,
                        onClick = onClaimSlotClick,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("claim_next_slot_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            DoodleCalendarIcon(
                                color = OnSecondaryContainerBrown,
                                hasCheckmark = true,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "Reclamar Próximo Turno Disponible",
                                fontFamily = PatrickHandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.5.sp,
                                color = OnSecondaryContainerBrown
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Confirmación instantánea • No se requiere tarjeta de crédito ✎",
                        fontFamily = CaveatFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 18.sp,
                        color = OnPrimaryContainerIce.copy(alpha = 0.92f),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // Corner tape doodle with counter-parallax
        SketchTape(
            rotationDegrees = 6f,
            modifier = Modifier
                .width(64.dp)
                .height(20.dp)
                .align(Alignment.TopEnd)
                .offset(x = (-22).dp, y = (-8).dp)
                .graphicsLayer {
                    translationX = -bannerProgress.value * 8.dp.toPx()
                }
        )
    }
}

@Composable
fun SmileCraftBottomNavBar(
    activeTab: NavTab,
    onSelectTab: (NavTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(SketchSurface.copy(alpha = 0.96f))
            .drawBehind {
                drawLine(
                    color = OnSurfaceCharcoal,
                    start = Offset(0f, 0f),
                    end = Offset(size.width, 0f),
                    strokeWidth = 2.dp.toPx()
                )
            }
            .windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(74.dp)
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavTab.entries.forEach { tab ->
                val isSelected = activeTab == tab
                Column(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onSelectTab(tab) }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                        .testTag("bottom_nav_${tab.route}"),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    DoodleBottomNavIcon(
                        route = tab.route,
                        isSelected = isSelected,
                        color = if (isSelected) PrimaryTeal else OnSurfaceVariantSlate,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = tab.label,
                        fontFamily = PatrickHandFontFamily,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                        fontSize = 12.sp,
                        color = if (isSelected) PrimaryTeal else OnSurfaceVariantSlate
                    )
                    if (isSelected) {
                        Canvas(
                            modifier = Modifier
                                .width(32.dp)
                                .height(5.dp)
                                .padding(top = 1.dp)
                        ) {
                            val path = Path().apply {
                                moveTo(2f, size.height * 0.6f)
                                quadraticTo(size.width * 0.5f, 0f, size.width - 2f, size.height * 0.6f)
                            }
                            drawPath(
                                path,
                                color = SecondaryContainerCoral,
                                style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }
                    } else {
                        Spacer(modifier = Modifier.height(5.dp))
                    }
                }
            }
        }
    }
}
