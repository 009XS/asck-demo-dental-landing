package com.example.model

import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import com.example.ui.theme.ErrorContainerRose
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.OnErrorContainerDark
import com.example.ui.theme.OnSurfaceCharcoal
import com.example.ui.theme.PrimaryTeal
import com.example.ui.theme.SecondaryCoralDark
import com.example.ui.theme.TagSoftCoral
import com.example.ui.theme.TagSoftGold
import com.example.ui.theme.TagSoftTeal
import com.example.ui.theme.TertiaryGoldDark
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

object HtmlAssets {
    const val LOGO_URL =
        "https://lh3.googleusercontent.com/aida-public/AB6AXuDCpx6VEX6eufhTlbFb_zJPKfTDTOt1f4xlJJfwdMdSnvAdTwWHlE-OnMQc53hIduG4suLbxQUcqawvof3lgUa2rrUv8R_2c9cgVyHshm_c3O7RmoiJzRa2sHjnTlmb3EPNZ_aMY8Q7kJaKiwy_1omv03-KavQGlXm0heWR42Nu8tO4DPrfTNka31qUu7xMHxfwAxN3d-7HeCe-KlpC5Bk5sfhqMseonzulGw65DtgMM55XHsKW--JZIQ"

    const val DR_MAYA_URL =
        "https://lh3.googleusercontent.com/aida-public/AB6AXuBXnhXBDULXcwEA0Ar5nv5VXmD6cJ1AJV0g6zMFznKlP8OYu27JNxPL3SwWmbzqecJfsaag5nymm5SCfJ_jx94m95P5gQoD92VM3zf6Hu08H43n1ng5-mvZ5VlOV8H2JPO-4d24AMQMgAJvk45Ub93HDtVzvknsm8xr3C9RKM5m_rBwidT1jgCALA2M38iGDbmD83Iyt9xrr1lzd1BWPnPRpj7XcQtPWM71TOrSuqfUdUHIhWBYwHrXkw"

    const val JULIAN_URL =
        "https://lh3.googleusercontent.com/aida-public/AB6AXuBm0CcQk1c9U2WFcTTwT63AZCLN0s0-7c01K-DuW7CrO7-OdEUDlnaauMitrhv-iCPQQDP1Wkq5RD_Z1fyOJVaiMQUWKmXcVW2wIzkYoq0VFKBmLFtRJ2HmNmVpOKeuSiq-7yyX6UQ1I690dyiKR1Vd1gY8IiAF6dQuVuIS6paUW76NcsdVHmkyjN04ghCgwyzlSq9H877Uv_K3jdli4hCvmKIOPfvusTNPLhO2OUUIzp_kcUbrhN5d-A"

    const val CHLOE_URL =
        "https://lh3.googleusercontent.com/aida-public/AB6AXuB841hDwURpRfVyYyigrkfkT3d8DS3dYu0yr39hkk2w_gBNO7YanCViumZq0TfD2r7oZQE0PD1506VoPPY-j3jWK225pw6jeP84k4T03Y0acz8T8l6qa-4fNnmKD7_yAE13bJLntfMmEGRhNLv54zrnvEOd73LNmZumG1nn2yeTxtSOAWE5zcaaFE7fYY58-8Hm_m949NJYTvGYSpMwxDG6bwmfEzbvcenpQvLIV8HQbG2KrVSs0tpjcA"

    const val SAM_URL =
        "https://lh3.googleusercontent.com/aida-public/AB6AXuAmQnBqJjA9NIbglKDaA8OZ19kWl262HH7FzltB4AFhlNd2o9JJvOJlmlO0mrSdABDKFe9E9xmTPEgPgUAXF-rOFnHJLhff8Cs3AOKhqnJ46KN_rf1RgLO-bTlwIEC-Wj7BWg9w5ifxjExGv0QkpeZ7uc6JTIHa1IrZYCV7kQoYh5kl-T4NlOtjeQaX03p5Zup6rAhM8bYgp0MsfsYBbcK7ddPFD4EAV_UJhDqVnS1qoclTOezKQy_nCw"
}

enum class NavTab(val route: String, val label: String) {
    HOME("home", "Inicio"),
    SERVICES("services", "Servicios"),
    TEAM("our-team", "Equipo"),
    VISIT("visit-and-contact", "Visítanos")
}

enum class ComfortMood(
    val id: String,
    val label: String,
    val boldIntro: String,
    val message: String,
    val recommendedPerks: List<String>
) {
    SUPER_ANXIOUS(
        id = "super-anxious",
        label = "Aterrorizado/a",
        boldIntro = "¡Cero preocupaciones!",
        message = "Almohadas térmicas para el cuello, mantas con peso, óxido nitroso y señales manuales de \"pausa cuando quieras\" están listas para ti.",
        recommendedPerks = listOf(
            "Manta con peso (7 kg)",
            "Señal manual «Pausa Ya»",
            "Óxido nitroso suave",
            "Almohada térmica cervical",
            "Cita silenciosa sin prisas"
        )
    ),
    A_BIT_NERVOUS(
        id = "a-bit-nervous",
        label = "Un poco intranquilo/a",
        boldIntro = "¡Te escuchamos!",
        message = "¡La mayoría de nuestros pacientes empiezan aquí! Ponte nuestros auriculares con cancelación de ruido con tu lista favorita de Spotify o serie de Netflix.",
        recommendedPerks = listOf(
            "Auriculares Bose + Netflix",
            "Playlist Lo-Fi en Spotify",
            "Gel anestésico sabor menta",
            "Explicación paso a paso",
            "Té herbal de manzanilla"
        )
    ),
    TOTALLY_FINE(
        id = "totally-fine",
        label = "Listo/a y Zen",
        boldIntro = "¡Genial!",
        message = "Te atenderemos sin demoras con toallitas tibias de lavanda, limpiezas suaves y una sonrisa radiante y pulida.",
        recommendedPerks = listOf(
            "Toallita tibia de lavanda",
            "Pulido herbal a la menta",
            "Escaneo 3D instantáneo",
            "Bálsamo labial orgánico",
            "Check-in expreso en 60s"
        )
    )
}

enum class ServiceIconType {
    TOOTH, SMILE, SUNBURST, SHIELD
}

data class DentalService(
    val id: String,
    val categoryTag: String,
    val durationNote: String,
    val title: String,
    val description: String,
    val pricePrefix: String,
    val priceMain: String,
    val priceSuffix: String,
    val strikethroughPrice: String? = null,
    val isUrgent: Boolean = false,
    val iconType: ServiceIconType,
    val shadowColor: Color,
    val tagBgColor: Color,
    val tagTextColor: Color,
    val steps: List<String>,
    val comfortIncluded: List<String>
)

data class TeamMember(
    val id: String,
    val name: String,
    val role: String,
    val badge: String,
    val imageUrl: String,
    val rotationDeg: Float,
    val quote: String,
    val superpower: String,
    val favoritePlaylist: String,
    val specialties: List<String>
)

data class PatientTestimonial(
    val id: String,
    val initials: String,
    val name: String,
    val treatment: String,
    val timeAgo: String,
    val quote: String,
    val moodBefore: String,
    val moodAfter: String,
    val badgeLabel: String = "Paciente Verificado"
)

data class ComfortAmenity(
    val id: String,
    val title: String,
    val subtitle: String,
    val tag: String,
    val isFree: Boolean = true
)

data class BookedAppointment(
    val serviceTitle: String,
    val doctorName: String,
    val dayLabel: String,
    val timeSlot: String,
    val patientName: String,
    val patientPhone: String,
    val mood: ComfortMood,
    val selectedAmenities: List<String>,
    val includeFreeElectricBrushBox: Boolean
)

data class DentalUiState(
    val activeTab: NavTab = NavTab.HOME,
    val selectedMood: ComfortMood = ComfortMood.SUPER_ANXIOUS,
    val selectedServiceCategory: String = "Todos",
    val selectedComfortAmenities: Set<String> = setOf(
        "Auriculares Bose + Netflix",
        "Almohada térmica cervical",
        "Señal manual «Pausa Ya»"
    ),
    val activeServiceDetail: DentalService? = null,
    val activeTeamMemberDetail: TeamMember? = null,
    val isBookingSheetOpen: Boolean = false,
    val preselectedBookingService: DentalService? = null,
    val claimElectricBrushGift: Boolean = true,
    val bookedAppointments: List<BookedAppointment> = emptyList(),
    val lastBookedConfirmation: BookedAppointment? = null
)

class DentalViewModel : ViewModel() {
    val services = listOf(
        DentalService(
            id = "routine-cleaning",
            categoryTag = "Rutina y Prevención",
            durationNote = "✎ 45 min",
            title = "Limpiezas y Exámenes de Rutina Suaves",
            description = "Eliminación ultrasónica suave de placa sin molestos sonidos de raspado, acompañada de un refrescante pulido herbal a la menta y cero culpas.",
            pricePrefix = "Desde",
            priceMain = "$89",
            priceSuffix = "(o 100% Cubierto)",
            iconType = ServiceIconType.TOOTH,
            shadowColor = PrimaryTeal,
            tagBgColor = TagSoftTeal,
            tagTextColor = PrimaryTeal,
            steps = listOf(
                "Bienvenida con té caliente y elección de música o serie en Netflix en el techo.",
                "Escaneo digital suave sin pinchazos ni radiografías incómodas.",
                "Baño ultrasónico tibio con agua temperada (sin raspado metálico).",
                "Pulido herbal con menta orgánica y toallita tibia de lavanda."
            ),
            comfortIncluded = listOf("Agua tibia regulada", "Gel adormecedor natural", "Auriculares con cancelación")
        ),
        DentalService(
            id = "invisible-aligners",
            categoryTag = "Ortodoncia",
            durationNote = "✎ Escaneo 3D",
            title = "Alineadores Invisibles",
            description = "Cero pastas pegajosas. Usamos una cámara 3D instantánea para previsualizar la transformación de tu nueva sonrisa en pantalla.",
            pricePrefix = "Planes desde",
            priceMain = "$85",
            priceSuffix = "/mes",
            iconType = ServiceIconType.SMILE,
            shadowColor = SecondaryCoralDark,
            tagBgColor = TagSoftCoral,
            tagTextColor = SecondaryCoralDark,
            steps = listOf(
                "Escaneo óptico 3D iTero en 3 minutos (cero moldes ni pastas).",
                "Simulación interactiva del antes y después de tu sonrisa en vivo.",
                "Plan personalizado revisado por la Dra. Maya Lin (Invisalign Platinum).",
                "Kit de inicio con estuche magnético y blanqueamiento de cortesía."
            ),
            comfortIncluded = listOf("Cero moldes de pasta", "Simulación 3D gratis", "Seguimiento por app")
        ),
        DentalService(
            id = "whitening-veneers",
            categoryTag = "Brillo y Resplandor",
            durationNote = "✎ 60 min",
            title = "Aclaramiento y Carillas Cosméticas",
            description = "Blanqueamiento láser sin sensibilidad en clínica y carillas de porcelana ultrafinas hechas a mano para una belleza natural y orgánica.",
            pricePrefix = "Especial",
            priceMain = "$199",
            priceSuffix = "",
            strikethroughPrice = "$350",
            iconType = ServiceIconType.SUNBURST,
            shadowColor = TertiaryGoldDark,
            tagBgColor = TagSoftGold,
            tagTextColor = TertiaryGoldDark,
            steps = listOf(
                "Análisis digital de tono natural para evitar un blanco artificial.",
                "Aplicación de suero desensibilizante de hidroxiapatita mineral.",
                "Sesión de luz fría LED mientras ves tu película favorita con manta térmica.",
                "Sello remineralizante para que puedas tomar café o té sin dolor."
            ),
            comfortIncluded = listOf("Fórmula 0% sensibilidad", "Gafas de descanso cálidas", "Bálsamo de karité")
        ),
        DentalService(
            id = "same-day-emergency",
            categoryTag = "Alivio Inmediato",
            durationNote = "✎ Inmediato",
            title = "Odontología Restauradora y Urgencias el Mismo Día",
            description = "¿Diente astillado o dolor repentino? Reservamos espacios de rescate diarios con protocolos inmediatos para aliviar el dolor.",
            pricePrefix = "Triaje prioritario",
            priceMain = "",
            priceSuffix = "",
            isUrgent = true,
            iconType = ServiceIconType.SHIELD,
            shadowColor = ErrorRed,
            tagBgColor = ErrorContainerRose,
            tagTextColor = OnErrorContainerDark,
            steps = listOf(
                "Atención inmediata al llegar — pasas directo a nuestra suite tranquila.",
                "Alivio del dolor en los primeros 5 minutos con anestesia computarizada sin aguja.",
                "Diagnóstico claro con cámara intraoral y presupuesto transparente antes de actuar.",
                "Restauración biomimética en una sola visita para que salgas sonriendo."
            ),
            comfortIncluded = listOf("Turno reservado hoy", "Óxido nitroso incluido", "Anestesia suave The Wand")
        )
    )

    val teamMembers = listOf(
        TeamMember(
            id = "maya-lin",
            name = "Dra. Maya Lin, DDS",
            role = "Fundadora y Especialista en Confort",
            badge = "Tufts '11 ✎",
            imageUrl = HtmlAssets.DR_MAYA_URL,
            rotationDeg = -1f,
            quote = "«Mi promesa es sencilla: Escuchamos primero. Nos movemos a tu propio ritmo y jamás te haremos sentir apenado por tu historial dental.»",
            superpower = "Transformar el miedo dental en siestas reparadoras",
            favoritePlaylist = "Acoustic Sunday Morning & Bossa Nova Suave",
            specialties = listOf("12+ Años de Experiencia", "Defensora contra la Ansiedad Dental", "Invisalign Platinum", "Certificada Fear-Free™")
        ),
        TeamMember(
            id = "julian-t",
            name = "Julian T.",
            role = "Pulido Suave",
            badge = "Higienista RDH",
            imageUrl = HtmlAssets.JULIAN_URL,
            rotationDeg = 1.5f,
            quote = "«Uso agua tibia temperada y ultrasonido silencioso. Muchos pacientes se quedan dormidos a mitad de la limpieza.»",
            superpower = "Manos de pluma y limpiezas con sabor a menta dulce",
            favoritePlaylist = "Indie Folk & Lluvia Suave",
            specialties = listOf("Ultrasonido Tibio", "Cero Raspado", "Cuidado de Encías Sensibles")
        ),
        TeamMember(
            id = "chloe-r",
            name = "Chloe R.",
            role = "Apoyo para Ansiedad",
            badge = "Coordinadora Zen",
            imageUrl = HtmlAssets.CHLOE_URL,
            rotationDeg = -2f,
            quote = "«Desde que cruzas la puerta, preparo tu manta con peso, tu aromaterapia y me aseguro de que nunca tengas dudas con tu seguro.»",
            superpower = "Respiración guiada y abrazos en forma de té caliente",
            favoritePlaylist = "Soul Acústico & Lo-Fi Chill",
            specialties = listOf("Guía de Confort", "Transparencia de Seguros", "Aromaterapia Clínica")
        ),
        TeamMember(
            id = "sam-p",
            name = "Sam P.",
            role = "DJ de Listas",
            badge = "Asistente Dental",
            imageUrl = HtmlAssets.SAM_URL,
            rotationDeg = 2f,
            quote = "«¿Quieres ver tu serie favorita en el techo o escuchar tu álbum favorito con cancelación de ruido? Yo lo dejo listo en 10 segundos.»",
            superpower = "Curador oficial de Netflix en el techo y sonido inmersivo",
            favoritePlaylist = "Synthwave Suave & Clásicos de los 90",
            specialties = listOf("Cine en el Techo", "Escaneo 3D Rápido", "Señales de Pausa")
        )
    )

    val testimonials = listOf(
        PatientTestimonial(
            id = "sarah-k",
            initials = "SK",
            name = "Sarah K.",
            treatment = "Limpieza de Rutina y Aclaramiento",
            timeAgo = "Hace 3 días ✎",
            quote = "«Literalmente solía llorar en mi auto antes de cada cita dental. El equipo aquí me dio auriculares cálidos, me preguntaban cómo estaba cada 2 minutos, ¡y hasta me hicieron reír!»",
            moodBefore = "Aterrorizada (5 años sin ir)",
            moodAfter = "Zen y feliz"
        ),
        PatientTestimonial(
            id = "mateo-r",
            initials = "MR",
            name = "Mateo R.",
            treatment = "Alineadores Invisibles 3D",
            timeAgo = "Hace 1 semana ✎",
            quote = "«Odio los moldes de pasta que dan náuseas. Aquí escanearon mis dientes con una camarita en 2 minutos mientras veía un documental en el techo con una manta pesada.»",
            moodBefore = "Un poco intranquilo",
            moodAfter = "Emocionado por su sonrisa"
        ),
        PatientTestimonial(
            id = "elena-v",
            initials = "EV",
            name = "Elena V.",
            treatment = "Urgencia el Mismo Día",
            timeAgo = "Hace 2 semanas ✎",
            quote = "«Se me astilló un diente antes de una boda. Me recibieron en 40 minutos con té de lavanda, cero dolor y quedó tan natural que ni yo noto dónde estaba la fractura.»",
            moodBefore = "En pánico total",
            moodAfter = "Aliviada al 100%"
        ),
        PatientTestimonial(
            id = "lucas-g",
            initials = "LG",
            name = "Lucas G.",
            treatment = "Primera Visita + Caja de Regalo",
            timeAgo = "Hace 3 semanas ✎",
            quote = "«¡El estudio huele a panadería y lavanda en vez de hospital! Además me llevé mi caja de regalo con cepillo eléctrico gratis. Nunca pensé que me gustaría ir al dentista.»",
            moodBefore = "Nervioso por el costo",
            moodAfter = "Cliente de por vida"
        )
    )

    val comfortMenuAmenities = listOf(
        ComfortAmenity(
            id = "bose-netflix",
            title = "Auriculares con cancelación de ruido y Netflix",
            subtitle = "Pantallas en el techo + sonido Bose inalámbrico",
            tag = "Favorito #1"
        ),
        ComfortAmenity(
            id = "zero-judgment",
            title = "Garantía cero juicios",
            subtitle = "No importa si pasaron 6 meses o 10 años",
            tag = "Promesa Ética"
        ),
        ComfortAmenity(
            id = "same-day-urgent",
            title = "Urgencias el mismo día",
            subtitle = "Espacios diarios reservados para alivio inmediato",
            tag = "Respuesta Rápida"
        ),
        ComfortAmenity(
            id = "weighted-blanket",
            title = "Mantas con peso y almohadas térmicas",
            subtitle = "Calor relajante para hombros y cuello",
            tag = "Confort Táctil"
        ),
        ComfortAmenity(
            id = "stop-signal",
            title = "Señal manual «Pausa cuando quieras»",
            subtitle = "Tú tienes el control total en cada segundo",
            tag = "Control 100%"
        ),
        ComfortAmenity(
            id = "warm-lavender",
            title = "Toallitas tibias de lavanda y té herbal",
            subtitle = "Ritual de spa antes y después de tu cita",
            tag = "Spa Dental"
        )
    )

    private val _uiState = MutableStateFlow(DentalUiState())
    val uiState: StateFlow<DentalUiState> = _uiState.asStateFlow()

    fun selectTab(tab: NavTab) {
        _uiState.update { it.copy(activeTab = tab) }
    }

    fun selectMood(mood: ComfortMood) {
        _uiState.update {
            it.copy(
                selectedMood = mood,
                selectedComfortAmenities = mood.recommendedPerks.take(3).toSet()
            )
        }
    }

    fun selectServiceCategory(category: String) {
        _uiState.update { it.copy(selectedServiceCategory = category) }
    }

    fun toggleComfortAmenity(amenity: String) {
        _uiState.update { state ->
            val updated = state.selectedComfortAmenities.toMutableSet()
            if (updated.contains(amenity)) {
                updated.remove(amenity)
            } else {
                updated.add(amenity)
            }
            state.copy(selectedComfortAmenities = updated)
        }
    }

    fun openServiceDetail(service: DentalService) {
        _uiState.update { it.copy(activeServiceDetail = service) }
    }

    fun closeServiceDetail() {
        _uiState.update { it.copy(activeServiceDetail = null) }
    }

    fun openTeamMemberDetail(member: TeamMember) {
        _uiState.update { it.copy(activeTeamMemberDetail = member) }
    }

    fun closeTeamMemberDetail() {
        _uiState.update { it.copy(activeTeamMemberDetail = null) }
    }

    fun openBookingSheet(preselectedService: DentalService? = null) {
        _uiState.update {
            it.copy(
                isBookingSheetOpen = true,
                preselectedBookingService = preselectedService ?: it.preselectedBookingService ?: services.first(),
                activeServiceDetail = null,
                lastBookedConfirmation = null
            )
        }
    }

    fun closeBookingSheet() {
        _uiState.update { it.copy(isBookingSheetOpen = false, lastBookedConfirmation = null) }
    }

    fun confirmBooking(
        service: DentalService,
        doctorName: String,
        dayLabel: String,
        timeSlot: String,
        patientName: String,
        patientPhone: String,
        includeGiftBox: Boolean
    ) {
        val appointment = BookedAppointment(
            serviceTitle = service.title,
            doctorName = doctorName,
            dayLabel = dayLabel,
            timeSlot = timeSlot,
            patientName = patientName.ifBlank { "Invitado SmileCraft" },
            patientPhone = patientPhone.ifBlank { "(305) 234-SMILE" },
            mood = _uiState.value.selectedMood,
            selectedAmenities = _uiState.value.selectedComfortAmenities.toList(),
            includeFreeElectricBrushBox = includeGiftBox
        )
        _uiState.update {
            it.copy(
                bookedAppointments = listOf(appointment) + it.bookedAppointments,
                lastBookedConfirmation = appointment
            )
        }
    }
}
