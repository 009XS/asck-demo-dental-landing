package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.ComfortMood
import com.example.model.ServiceIconType
import com.example.ui.theme.ErrorContainerRose
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.MapTreeMint
import com.example.ui.theme.OnSurfaceCharcoal
import com.example.ui.theme.OutlineVariantLight
import com.example.ui.theme.PostItWarmYellow
import com.example.ui.theme.PrimaryFixedCyan
import com.example.ui.theme.PrimaryFixedDimCyan
import com.example.ui.theme.PrimaryTeal
import com.example.ui.theme.SecondaryContainerCoral
import com.example.ui.theme.SecondaryCoralDark
import com.example.ui.theme.SurfaceContainerLowest
import com.example.ui.theme.TagSoftCoral
import com.example.ui.theme.TagSoftTeal
import com.example.ui.theme.TertiaryFixedDimSunbeam
import com.example.ui.theme.TertiaryGoldDark

@Composable
fun DoodleSparkle(
    color: Color = SecondaryCoralDark,
    modifier: Modifier = Modifier.size(14.dp)
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(w * 0.5f, 0f)
            lineTo(w * 0.58f, h * 0.38f)
            lineTo(w, h * 0.5f)
            lineTo(w * 0.58f, h * 0.62f)
            lineTo(w * 0.5f, h)
            lineTo(w * 0.42f, h * 0.62f)
            lineTo(0f, h * 0.5f)
            lineTo(w * 0.42f, h * 0.38f)
            close()
        }
        drawPath(path, color = color)
    }
}

@Composable
fun DoodlePencilIcon(
    color: Color,
    modifier: Modifier = Modifier.size(16.dp)
) {
    Canvas(modifier = modifier) {
        val s = size.width / 24f
        val path = Path().apply {
            moveTo(3f * s, 21f * s)
            lineTo(6.5f * s, 20.5f * s)
            lineTo(20f * s, 7f * s)
            lineTo(17f * s, 4f * s)
            lineTo(3.5f * s, 17.5f * s)
            close()
        }
        drawPath(
            path = path,
            color = color,
            style = Stroke(width = 2f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
        drawLine(
            color = color,
            start = Offset(14.5f * s, 6.5f * s),
            end = Offset(17.5f * s, 9.5f * s),
            strokeWidth = 2f * s,
            cap = StrokeCap.Round
        )
    }
}

@Composable
fun DoodleHeartIcon(
    modifier: Modifier = Modifier.size(20.dp)
) {
    Canvas(modifier = modifier) {
        val s = size.width / 24f
        val path = Path().apply {
            moveTo(12f * s, 21.35f * s)
            lineTo(10.55f * s, 20.03f * s)
            cubicTo(5.4f * s, 15.36f * s, 2f * s, 12.28f * s, 2f * s, 8.5f * s)
            cubicTo(2f * s, 5.42f * s, 4.42f * s, 3f * s, 7.5f * s, 3f * s)
            cubicTo(9.24f * s, 3f * s, 10.91f * s, 3.81f * s, 12f * s, 5.09f * s)
            cubicTo(13.09f * s, 3.81f * s, 14.76f * s, 3f * s, 16.5f * s, 3f * s)
            cubicTo(19.58f * s, 3f * s, 22f * s, 5.42f * s, 22f * s, 8.5f * s)
            cubicTo(22f * s, 12.28f * s, 18.6f * s, 15.36f * s, 13.45f * s, 20.04f * s)
            close()
        }
        drawPath(path, color = SecondaryContainerCoral.copy(alpha = 0.35f))
        drawPath(
            path,
            color = SecondaryCoralDark,
            style = Stroke(width = 2.2f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

@Composable
fun DoodleStarburstTopRight(
    modifier: Modifier = Modifier.size(42.dp)
) {
    val infiniteTransition = rememberInfiniteTransition(label = "starburstSpin")
    val pulse by infiniteTransition.animateFloat(
        initialValue = -6f,
        targetValue = 6f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "starburstAngle"
    )
    Canvas(
        modifier = modifier.graphicsLayer {
            rotationZ = pulse
        }
    ) {
        val s = size.width / 42f
        val starPath = Path().apply {
            moveTo(21f * s, 2f * s)
            cubicTo(21.8f * s, 11.5f * s, 29.5f * s, 19.2f * s, 39f * s, 20f * s)
            cubicTo(29.5f * s, 20.8f * s, 21.8f * s, 29.5f * s, 21f * s, 39f * s)
            cubicTo(20.2f * s, 29.5f * s, 12.5f * s, 20.8f * s, 3f * s, 20f * s)
            cubicTo(12.5f * s, 19.2f * s, 20.2f * s, 11.5f * s, 21f * s, 2f * s)
            close()
        }
        drawPath(starPath, color = TertiaryFixedDimSunbeam.copy(alpha = 0.55f))
        drawPath(
            starPath,
            color = OnSurfaceCharcoal,
            style = Stroke(width = 1.8f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
        val dash = PathEffect.dashPathEffect(floatArrayOf(2f * s, 2f * s), 0f)
        drawLine(
            color = TertiaryGoldDark,
            start = Offset(14f * s, 14f * s),
            end = Offset(28f * s, 28f * s),
            strokeWidth = 1.2f * s,
            pathEffect = dash
        )
        drawLine(
            color = TertiaryGoldDark,
            start = Offset(28f * s, 14f * s),
            end = Offset(14f * s, 28f * s),
            strokeWidth = 1.2f * s,
            pathEffect = dash
        )
    }
}

@Composable
fun DoodleVerifiedBadge(
    modifier: Modifier = Modifier.size(16.dp)
) {
    Canvas(modifier = modifier) {
        val s = size.width / 24f
        val seal = Path().apply {
            moveTo(12f * s, 2f * s)
            lineTo(15f * s, 4f * s)
            lineTo(18f * s, 3f * s)
            lineTo(19f * s, 6f * s)
            lineTo(22f * s, 8f * s)
            lineTo(21f * s, 11f * s)
            lineTo(23f * s, 14f * s)
            lineTo(21f * s, 17f * s)
            lineTo(22f * s, 20f * s)
            lineTo(19f * s, 22f * s)
            lineTo(18f * s, 25f * s)
            lineTo(15f * s, 24f * s)
            lineTo(12f * s, 26f * s)
            lineTo(9f * s, 24f * s)
            lineTo(6f * s, 25f * s)
            lineTo(5f * s, 22f * s)
            lineTo(2f * s, 20f * s)
            lineTo(3f * s, 17f * s)
            lineTo(1f * s, 14f * s)
            lineTo(3f * s, 11f * s)
            lineTo(2f * s, 8f * s)
            lineTo(5f * s, 6f * s)
            lineTo(6f * s, 3f * s)
            lineTo(9f * s, 4f * s)
            close()
        }
        drawPath(seal, color = PrimaryFixedDimCyan.copy(alpha = 0.4f))
        drawPath(
            seal,
            color = PrimaryTeal,
            style = Stroke(width = 2f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
        val check = Path().apply {
            moveTo(9f * s, 13f * s)
            lineTo(11f * s, 15f * s)
            lineTo(15f * s, 11f * s)
        }
        drawPath(
            check,
            color = PrimaryTeal,
            style = Stroke(width = 2.5f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

@Composable
fun DoodleStarSparkleYellow(
    modifier: Modifier = Modifier.size(26.dp)
) {
    Canvas(modifier = modifier) {
        val s = size.width / 24f
        val path = Path().apply {
            moveTo(12f * s, 2f * s)
            lineTo(14f * s, 8f * s)
            lineTo(20f * s, 9f * s)
            lineTo(15f * s, 14f * s)
            lineTo(17f * s, 20f * s)
            lineTo(12f * s, 16f * s)
            lineTo(7f * s, 20f * s)
            lineTo(9f * s, 14f * s)
            lineTo(4f * s, 9f * s)
            lineTo(10f * s, 8f * s)
            close()
        }
        drawPath(path, color = TertiaryFixedDimSunbeam)
        drawPath(
            path,
            color = OnSurfaceCharcoal,
            style = Stroke(width = 1.8f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

@Composable
fun DoodleCurvedArrowDownRight(
    color: Color = SecondaryCoralDark,
    modifier: Modifier = Modifier.size(26.dp)
) {
    Canvas(modifier = modifier) {
        val s = size.width / 32f
        val curve = Path().apply {
            moveTo(8f * s, 8f * s)
            cubicTo(14f * s, 16f * s, 20f * s, 20f * s, 24f * s, 24f * s)
        }
        val head = Path().apply {
            moveTo(24f * s, 16f * s)
            lineTo(24f * s, 24f * s)
            lineTo(16f * s, 24f * s)
        }
        drawPath(curve, color = color, style = Stroke(width = 2.5f * s, cap = StrokeCap.Round))
        drawPath(
            head,
            color = color,
            style = Stroke(width = 2.5f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

@Composable
fun DoodleCalendarIcon(
    color: Color,
    hasCheckmark: Boolean = false,
    modifier: Modifier = Modifier.size(20.dp)
) {
    Canvas(modifier = modifier) {
        val s = size.width / 24f
        drawRoundRect(
            color = color,
            topLeft = Offset(3f * s, 4f * s),
            size = Size(18f * s, 18f * s),
            cornerRadius = CornerRadius(2.5f * s, 2.5f * s),
            style = Stroke(width = 2.2f * s)
        )
        drawLine(color, Offset(16f * s, 2f * s), Offset(16f * s, 6f * s), strokeWidth = 2.2f * s, cap = StrokeCap.Round)
        drawLine(color, Offset(8f * s, 2f * s), Offset(8f * s, 6f * s), strokeWidth = 2.2f * s, cap = StrokeCap.Round)
        drawLine(color, Offset(3f * s, 10f * s), Offset(21f * s, 10f * s), strokeWidth = 2.2f * s, cap = StrokeCap.Round)
        if (hasCheckmark) {
            val check = Path().apply {
                moveTo(9f * s, 16f * s)
                lineTo(11f * s, 18f * s)
                lineTo(15f * s, 14f * s)
            }
            drawPath(
                check,
                color = color,
                style = Stroke(width = 2.2f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
        } else {
            drawCircle(color = color, radius = 1.8f * s, center = Offset(12f * s, 15.5f * s))
        }
    }
}

@Composable
fun DoodlePhoneIcon(
    color: Color,
    modifier: Modifier = Modifier.size(18.dp)
) {
    Canvas(modifier = modifier) {
        val s = size.width / 24f
        val path = Path().apply {
            moveTo(22f * s, 16.92f * s)
            lineTo(22f * s, 19.92f * s)
            cubicTo(22f * s, 21f * s, 21f * s, 22f * s, 19.82f * s, 21.92f * s)
            cubicTo(15.5f * s, 21.4f * s, 11.4f * s, 19.5f * s, 8.19f * s, 16.85f * s)
            cubicTo(5.3f * s, 14.3f * s, 3.1f * s, 10.6f * s, 2.12f * s, 6.18f * s)
            cubicTo(1.9f * s, 5f * s, 2.9f * s, 4f * s, 4.11f * s, 4f * s)
            lineTo(7.11f * s, 4f * s)
            lineTo(9.11f * s, 8.5f * s)
            lineTo(7.2f * s, 10.4f * s)
            cubicTo(8.8f * s, 13.4f * s, 11.3f * s, 15.9f * s, 14.3f * s, 17.5f * s)
            lineTo(16.2f * s, 15.6f * s)
            close()
        }
        drawPath(
            path,
            color = color,
            style = Stroke(width = 2.1f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

@Composable
fun DoodleHeadphonesIcon(
    color: Color = PrimaryTeal,
    modifier: Modifier = Modifier.size(16.dp)
) {
    Canvas(modifier = modifier) {
        val s = size.width / 24f
        drawArc(
            color = color,
            startAngle = 180f,
            sweepAngle = 180f,
            useCenter = false,
            topLeft = Offset(3f * s, 3f * s),
            size = Size(18f * s, 18f * s),
            style = Stroke(width = 2.1f * s, cap = StrokeCap.Round)
        )
        drawRoundRect(
            color = PrimaryFixedDimCyan.copy(alpha = 0.35f),
            topLeft = Offset(3f * s, 14f * s),
            size = Size(5f * s, 7f * s),
            cornerRadius = CornerRadius(2f * s, 2f * s)
        )
        drawRoundRect(
            color = color,
            topLeft = Offset(3f * s, 14f * s),
            size = Size(5f * s, 7f * s),
            cornerRadius = CornerRadius(2f * s, 2f * s),
            style = Stroke(width = 2f * s)
        )
        drawRoundRect(
            color = PrimaryFixedDimCyan.copy(alpha = 0.35f),
            topLeft = Offset(16f * s, 14f * s),
            size = Size(5f * s, 7f * s),
            cornerRadius = CornerRadius(2f * s, 2f * s)
        )
        drawRoundRect(
            color = color,
            topLeft = Offset(16f * s, 14f * s),
            size = Size(5f * s, 7f * s),
            cornerRadius = CornerRadius(2f * s, 2f * s),
            style = Stroke(width = 2f * s)
        )
    }
}

@Composable
fun DoodleSmileFaceIcon(
    color: Color = SecondaryCoralDark,
    modifier: Modifier = Modifier.size(16.dp)
) {
    Canvas(modifier = modifier) {
        val s = size.width / 24f
        drawCircle(
            color = color,
            radius = 9f * s,
            center = Offset(12f * s, 12f * s),
            style = Stroke(width = 2f * s)
        )
        val smile = Path().apply {
            moveTo(8f * s, 14f * s)
            quadraticTo(12f * s, 17.5f * s, 16f * s, 14f * s)
        }
        drawPath(smile, color = color, style = Stroke(width = 2f * s, cap = StrokeCap.Round))
        drawCircle(color = color, radius = 1.3f * s, center = Offset(9f * s, 9.5f * s))
        drawCircle(color = color, radius = 1.3f * s, center = Offset(15f * s, 9.5f * s))
    }
}

@Composable
fun DoodleClockIcon(
    color: Color = TertiaryGoldDark,
    modifier: Modifier = Modifier.size(16.dp)
) {
    Canvas(modifier = modifier) {
        val s = size.width / 24f
        drawCircle(
            color = color,
            radius = 9f * s,
            center = Offset(12f * s, 12f * s),
            style = Stroke(width = 2f * s)
        )
        val hands = Path().apply {
            moveTo(12f * s, 7f * s)
            lineTo(12f * s, 12f * s)
            lineTo(15.5f * s, 14f * s)
        }
        drawPath(
            hands,
            color = color,
            style = Stroke(width = 2f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

/**
 * The 3 expressive comfort quiz mood illustrations from the HTML.
 */
@Composable
fun DoodleMoodFace(
    mood: ComfortMood,
    modifier: Modifier = Modifier.size(34.dp)
) {
    Canvas(modifier = modifier) {
        val s = size.width / 36f
        val strokeCharcoal = Stroke(width = 1.9f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (mood) {
            ComfortMood.SUPER_ANXIOUS -> {
                drawCircle(
                    color = TagSoftCoral,
                    radius = 15f * s,
                    center = Offset(18f * s, 18f * s)
                )
                drawCircle(
                    color = OnSurfaceCharcoal,
                    radius = 15f * s,
                    center = Offset(18f * s, 18f * s),
                    style = strokeCharcoal
                )
                // Wide eyes
                drawCircle(color = Color.White, radius = 3.5f * s, center = Offset(12.5f * s, 14f * s))
                drawCircle(color = OnSurfaceCharcoal, radius = 3.5f * s, center = Offset(12.5f * s, 14f * s), style = strokeCharcoal)
                drawCircle(color = OnSurfaceCharcoal, radius = 1.5f * s, center = Offset(12.5f * s, 14f * s))

                drawCircle(color = Color.White, radius = 3.5f * s, center = Offset(23.5f * s, 14f * s))
                drawCircle(color = OnSurfaceCharcoal, radius = 3.5f * s, center = Offset(23.5f * s, 14f * s), style = strokeCharcoal)
                drawCircle(color = OnSurfaceCharcoal, radius = 1.5f * s, center = Offset(23.5f * s, 14f * s))

                // Worried eyebrows
                val leftBrow = Path().apply {
                    moveTo(9f * s, 10f * s)
                    quadraticTo(13f * s, 8f * s, 16f * s, 11f * s)
                }
                val rightBrow = Path().apply {
                    moveTo(27f * s, 10f * s)
                    quadraticTo(23f * s, 8f * s, 20f * s, 11f * s)
                }
                drawPath(leftBrow, color = OnSurfaceCharcoal, style = strokeCharcoal)
                drawPath(rightBrow, color = OnSurfaceCharcoal, style = strokeCharcoal)

                // Wavy nervous mouth
                val mouth = Path().apply {
                    moveTo(11f * s, 25f * s)
                    quadraticTo(14.5f * s, 21f * s, 18f * s, 25f * s)
                    quadraticTo(21.5f * s, 28f * s, 25f * s, 24f * s)
                }
                drawPath(mouth, color = OnSurfaceCharcoal, style = Stroke(width = 2.2f * s, cap = StrokeCap.Round))

                // Sweat drop
                val drop = Path().apply {
                    moveTo(29f * s, 11f * s)
                    cubicTo(32f * s, 14f * s, 32f * s, 17f * s, 30f * s, 18f * s)
                    cubicTo(28f * s, 19f * s, 27f * s, 17f * s, 28f * s, 14f * s)
                    close()
                }
                drawPath(drop, color = PrimaryFixedDimCyan)
                drawPath(drop, color = OnSurfaceCharcoal, style = Stroke(width = 1.2f * s))
            }

            ComfortMood.A_BIT_NERVOUS -> {
                drawCircle(
                    color = PostItWarmYellow,
                    radius = 15f * s,
                    center = Offset(18f * s, 18f * s)
                )
                drawCircle(
                    color = OnSurfaceCharcoal,
                    radius = 15f * s,
                    center = Offset(18f * s, 18f * s),
                    style = strokeCharcoal
                )
                drawOval(
                    color = OnSurfaceCharcoal,
                    topLeft = Offset(10.2f * s, 12.3f * s),
                    size = Size(3.6f * s, 4.4f * s)
                )
                drawOval(
                    color = OnSurfaceCharcoal,
                    topLeft = Offset(22.2f * s, 12.3f * s),
                    size = Size(3.6f * s, 4.4f * s)
                )
                drawLine(OnSurfaceCharcoal, Offset(10f * s, 11f * s), Offset(15f * s, 12f * s), strokeWidth = 1.8f * s, cap = StrokeCap.Round)
                drawLine(OnSurfaceCharcoal, Offset(26f * s, 11f * s), Offset(21f * s, 12f * s), strokeWidth = 1.8f * s, cap = StrokeCap.Round)

                // Clenched teeth box
                drawRoundRect(
                    color = Color.White,
                    topLeft = Offset(11f * s, 21f * s),
                    size = Size(14f * s, 6f * s),
                    cornerRadius = CornerRadius(3f * s, 3f * s)
                )
                drawRoundRect(
                    color = OnSurfaceCharcoal,
                    topLeft = Offset(11f * s, 21f * s),
                    size = Size(14f * s, 6f * s),
                    cornerRadius = CornerRadius(3f * s, 3f * s),
                    style = strokeCharcoal
                )
                drawLine(OnSurfaceCharcoal, Offset(14.5f * s, 21f * s), Offset(14.5f * s, 27f * s), strokeWidth = 1.4f * s)
                drawLine(OnSurfaceCharcoal, Offset(18f * s, 21f * s), Offset(18f * s, 27f * s), strokeWidth = 1.4f * s)
                drawLine(OnSurfaceCharcoal, Offset(21.5f * s, 21f * s), Offset(21.5f * s, 27f * s), strokeWidth = 1.4f * s)
            }

            ComfortMood.TOTALLY_FINE -> {
                drawCircle(
                    color = TagSoftTeal,
                    radius = 15f * s,
                    center = Offset(18f * s, 18f * s)
                )
                drawCircle(
                    color = OnSurfaceCharcoal,
                    radius = 15f * s,
                    center = Offset(18f * s, 18f * s),
                    style = strokeCharcoal
                )
                // Happy closed eyes
                val leftEye = Path().apply {
                    moveTo(10f * s, 14f * s)
                    quadraticTo(13f * s, 10f * s, 16f * s, 14f * s)
                }
                val rightEye = Path().apply {
                    moveTo(20f * s, 14f * s)
                    quadraticTo(23f * s, 10f * s, 26f * s, 14f * s)
                }
                drawPath(leftEye, color = OnSurfaceCharcoal, style = Stroke(width = 2.2f * s, cap = StrokeCap.Round))
                drawPath(rightEye, color = OnSurfaceCharcoal, style = Stroke(width = 2.2f * s, cap = StrokeCap.Round))

                // Rosy cheeks
                drawCircle(color = SecondaryContainerCoral.copy(alpha = 0.45f), radius = 2.6f * s, center = Offset(9.5f * s, 18.5f * s))
                drawCircle(color = SecondaryContainerCoral.copy(alpha = 0.45f), radius = 2.6f * s, center = Offset(26.5f * s, 18.5f * s))

                // Big smile
                val smile = Path().apply {
                    moveTo(11f * s, 20f * s)
                    quadraticTo(18f * s, 29f * s, 25f * s, 20f * s)
                }
                drawPath(smile, color = OnSurfaceCharcoal, style = Stroke(width = 2.2f * s, cap = StrokeCap.Round))
            }
        }
    }
}

@Composable
fun DoodleComfortMessageIcon(
    mood: ComfortMood,
    modifier: Modifier = Modifier.size(24.dp)
) {
    when (mood) {
        ComfortMood.SUPER_ANXIOUS -> {
            Canvas(modifier = modifier) {
                val s = size.width / 24f
                val heart = Path().apply {
                    moveTo(12f * s, 4f * s)
                    cubicTo(10f * s, 2f * s, 6f * s, 2f * s, 4f * s, 5f * s)
                    cubicTo(2f * s, 9f * s, 7f * s, 13f * s, 12f * s, 18f * s)
                    cubicTo(17f * s, 13f * s, 22f * s, 9f * s, 20f * s, 5f * s)
                    cubicTo(18f * s, 2f * s, 14f * s, 2f * s, 12f * s, 4f * s)
                    close()
                }
                drawPath(heart, color = PrimaryFixedDimCyan.copy(alpha = 0.35f))
                drawPath(heart, color = PrimaryTeal, style = Stroke(width = 2f * s, cap = StrokeCap.Round, join = StrokeJoin.Round))
                val wave = Path().apply {
                    moveTo(2f * s, 15f * s)
                    quadraticTo(5.5f * s, 17f * s, 9f * s, 15f * s)
                    quadraticTo(12.5f * s, 13f * s, 16f * s, 15f * s)
                    quadraticTo(19f * s, 17f * s, 22f * s, 15f * s)
                }
                drawPath(
                    wave,
                    color = PrimaryTeal,
                    style = Stroke(
                        width = 1.8f * s,
                        cap = StrokeCap.Round,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(2.5f * s, 2.5f * s), 0f)
                    )
                )
            }
        }
        ComfortMood.A_BIT_NERVOUS -> DoodleHeadphonesIcon(color = PrimaryTeal, modifier = modifier)
        ComfortMood.TOTALLY_FINE -> DoodleSmileFaceIcon(color = PrimaryTeal, modifier = modifier)
    }
}

@Composable
fun DoodleServiceCardIcon(
    iconType: ServiceIconType,
    modifier: Modifier = Modifier.size(28.dp)
) {
    Canvas(modifier = modifier) {
        val s = size.width / 24f
        val strokeCharcoal = Stroke(width = 1.8f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (iconType) {
            ServiceIconType.TOOTH -> {
                val tooth = Path().apply {
                    moveTo(12f * s, 2f * s)
                    cubicTo(9f * s, 2f * s, 7f * s, 4f * s, 7f * s, 7f * s)
                    cubicTo(7f * s, 9.5f * s, 8f * s, 11.5f * s, 8f * s, 14f * s)
                    cubicTo(8f * s, 17f * s, 6f * s, 18f * s, 6f * s, 22f * s)
                    lineTo(10f * s, 22f * s)
                    cubicTo(10.5f * s, 19f * s, 11f * s, 16f * s, 12f * s, 16f * s)
                    cubicTo(13f * s, 16f * s, 13.5f * s, 19f * s, 14f * s, 22f * s)
                    lineTo(18f * s, 22f * s)
                    cubicTo(18f * s, 18f * s, 16f * s, 17f * s, 16f * s, 14f * s)
                    cubicTo(16f * s, 11.5f * s, 17f * s, 9.5f * s, 17f * s, 7f * s)
                    cubicTo(17f * s, 4f * s, 15f * s, 2f * s, 12f * s, 2f * s)
                    close()
                }
                drawPath(tooth, color = PrimaryFixedCyan.copy(alpha = 0.35f))
                drawPath(tooth, color = OnSurfaceCharcoal, style = strokeCharcoal)
                val smileArc = Path().apply {
                    moveTo(9f * s, 7f * s)
                    cubicTo(10f * s, 5f * s, 14f * s, 5f * s, 15f * s, 7f * s)
                }
                drawPath(smileArc, color = PrimaryTeal, style = Stroke(width = 1.6f * s, cap = StrokeCap.Round))
            }

            ServiceIconType.SMILE -> {
                val mainSmile = Path().apply {
                    moveTo(4f * s, 11f * s)
                    cubicTo(8f * s, 19f * s, 16f * s, 19f * s, 20f * s, 11f * s)
                }
                drawPath(mainSmile, color = OnSurfaceCharcoal, style = Stroke(width = 2.4f * s, cap = StrokeCap.Round))
                drawCircle(color = SecondaryContainerCoral, radius = 1.7f * s, center = Offset(6f * s, 7f * s))
                drawCircle(color = SecondaryContainerCoral, radius = 1.7f * s, center = Offset(18f * s, 7f * s))
                val alignerLine = Path().apply {
                    moveTo(7f * s, 14f * s)
                    cubicTo(10f * s, 16f * s, 14f * s, 16f * s, 17f * s, 14f * s)
                }
                drawPath(
                    alignerLine,
                    color = SecondaryCoralDark,
                    style = Stroke(
                        width = 1.6f * s,
                        cap = StrokeCap.Round,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(2f * s, 2f * s), 0f)
                    )
                )
            }

            ServiceIconType.SUNBURST -> {
                drawCircle(color = TertiaryFixedDimSunbeam, radius = 5f * s, center = Offset(12f * s, 12f * s))
                drawCircle(color = OnSurfaceCharcoal, radius = 5f * s, center = Offset(12f * s, 12f * s), style = strokeCharcoal)
                val rays = listOf(
                    Offset(12f * s, 2f * s) to Offset(12f * s, 5f * s),
                    Offset(12f * s, 19f * s) to Offset(12f * s, 22f * s),
                    Offset(2f * s, 12f * s) to Offset(5f * s, 12f * s),
                    Offset(19f * s, 12f * s) to Offset(22f * s, 12f * s),
                    Offset(4.9f * s, 4.9f * s) to Offset(7.1f * s, 7.1f * s),
                    Offset(16.9f * s, 16.9f * s) to Offset(19.1f * s, 19.1f * s),
                    Offset(4.9f * s, 19.1f * s) to Offset(7.1f * s, 16.9f * s),
                    Offset(16.9f * s, 7.1f * s) to Offset(19.1f * s, 4.9f * s)
                )
                rays.forEach { (start, end) ->
                    drawLine(OnSurfaceCharcoal, start, end, strokeWidth = 1.8f * s, cap = StrokeCap.Round)
                }
            }

            ServiceIconType.SHIELD -> {
                val shield = Path().apply {
                    moveTo(12f * s, 2f * s)
                    lineTo(4f * s, 5f * s)
                    lineTo(4f * s, 11f * s)
                    cubicTo(4f * s, 16.5f * s, 7.4f * s, 21.6f * s, 12f * s, 23f * s)
                    cubicTo(16.6f * s, 21.6f * s, 20f * s, 16.5f * s, 20f * s, 11f * s)
                    lineTo(20f * s, 5f * s)
                    close()
                }
                drawPath(shield, color = ErrorContainerRose)
                drawPath(shield, color = OnSurfaceCharcoal, style = strokeCharcoal)
                val check = Path().apply {
                    moveTo(9f * s, 12f * s)
                    lineTo(11f * s, 14f * s)
                    lineTo(15f * s, 10f * s)
                }
                drawPath(
                    check,
                    color = ErrorRed,
                    style = Stroke(width = 2.2f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }
        }
    }
}

@Composable
fun DoodleHandDrawnStar(
    fillColor: Color = SecondaryContainerCoral,
    modifier: Modifier = Modifier.size(20.dp)
) {
    Canvas(modifier = modifier) {
        val s = size.width / 24f
        val star = Path().apply {
            moveTo(12f * s, 2.5f * s)
            lineTo(15.2f * s, 8.6f * s)
            lineTo(21.8f * s, 10.2f * s)
            lineTo(17.2f * s, 15f * s)
            lineTo(17.5f * s, 21.4f * s)
            lineTo(11.8f * s, 18.2f * s)
            lineTo(6.2f * s, 21.2f * s)
            lineTo(6.8f * s, 15f * s)
            lineTo(2.2f * s, 10.2f * s)
            lineTo(8.8f * s, 8.6f * s)
            close()
        }
        drawPath(star, color = fillColor.copy(alpha = 0.92f))
        drawPath(
            star,
            color = OnSurfaceCharcoal,
            style = Stroke(width = 1.8f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

@Composable
fun DoodleMapPinIcon(
    fillColor: Color = SecondaryContainerCoral,
    strokeColor: Color = OnSurfaceCharcoal,
    modifier: Modifier = Modifier.size(20.dp)
) {
    Canvas(modifier = modifier) {
        val s = size.width / 24f
        val pin = Path().apply {
            moveTo(12f * s, 2f * s)
            cubicTo(8.13f * s, 2f * s, 5f * s, 5.13f * s, 5f * s, 9f * s)
            cubicTo(5f * s, 14.25f * s, 12f * s, 22f * s, 12f * s, 22f * s)
            cubicTo(12f * s, 22f * s, 19f * s, 14.25f * s, 19f * s, 9f * s)
            cubicTo(19f * s, 5.13f * s, 15.87f * s, 2f * s, 12f * s, 2f * s)
            close()
        }
        drawPath(pin, color = fillColor)
        drawPath(
            pin,
            color = strokeColor,
            style = Stroke(width = 1.8f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
        drawCircle(color = Color.White, radius = 2.6f * s, center = Offset(12f * s, 9f * s))
        drawCircle(
            color = strokeColor,
            radius = 2.6f * s,
            center = Offset(12f * s, 9f * s),
            style = Stroke(width = 1.4f * s)
        )
    }
}

@Composable
fun DoodleSmsIcon(
    color: Color = PrimaryTeal,
    modifier: Modifier = Modifier.size(20.dp)
) {
    Canvas(modifier = modifier) {
        val s = size.width / 24f
        val bubble = Path().apply {
            moveTo(21f * s, 15f * s)
            cubicTo(21f * s, 16.1f * s, 20.1f * s, 17f * s, 19f * s, 17f * s)
            lineTo(7f * s, 17f * s)
            lineTo(3f * s, 21f * s)
            lineTo(3f * s, 5f * s)
            cubicTo(3f * s, 3.9f * s, 3.9f * s, 3f * s, 5f * s, 3f * s)
            lineTo(19f * s, 3f * s)
            cubicTo(20.1f * s, 3f * s, 21f * s, 3.9f * s, 21f * s, 5f * s)
            close()
        }
        drawPath(
            bubble,
            color = color,
            style = Stroke(width = 2f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
        drawLine(color, Offset(8f * s, 9f * s), Offset(16f * s, 9f * s), strokeWidth = 2f * s, cap = StrokeCap.Round)
        drawLine(color, Offset(8f * s, 13f * s), Offset(13f * s, 13f * s), strokeWidth = 2f * s, cap = StrokeCap.Round)
    }
}

@Composable
fun DoodleNavigationPaperPlaneIcon(
    color: Color = TertiaryGoldDark,
    modifier: Modifier = Modifier.size(20.dp)
) {
    Canvas(modifier = modifier) {
        val s = size.width / 24f
        val plane = Path().apply {
            moveTo(3f * s, 11f * s)
            lineTo(22f * s, 2f * s)
            lineTo(13f * s, 21f * s)
            lineTo(11f * s, 13f * s)
            close()
        }
        drawPath(
            plane,
            color = color,
            style = Stroke(width = 2f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

/**
 * Hand-drawn street, river, and trees map canvas inside Location & Visit section.
 */
@Composable
fun DoodleIllustratedMapCanvas(
    modifier: Modifier = Modifier.fillMaxSize()
) {
    Canvas(modifier = modifier) {
        val sx = size.width / 320f
        val sy = size.height / 180f

        // Sketched streets
        val street1 = Path().apply {
            moveTo(-10f * sx, 60f * sy)
            quadraticTo(80f * sx, 55f * sy, 160f * sx, 62f * sy)
            quadraticTo(240f * sx, 69f * sy, 340f * sx, 58f * sy)
        }
        val street2 = Path().apply {
            moveTo(-10f * sx, 130f * sy)
            quadraticTo(90f * sx, 135f * sy, 180f * sx, 128f * sy)
            quadraticTo(260f * sx, 121f * sy, 340f * sx, 132f * sy)
        }
        val street3 = Path().apply {
            moveTo(120f * sx, -10f * sy)
            quadraticTo(115f * sx, 70f * sy, 125f * sx, 120f * sy)
            quadraticTo(132f * sx, 155f * sy, 118f * sx, 190f * sy)
        }
        val street4 = Path().apply {
            moveTo(220f * sx, -10f * sy)
            quadraticTo(225f * sx, 60f * sy, 215f * sx, 110f * sy)
            quadraticTo(208f * sx, 150f * sy, 225f * sx, 190f * sy)
        }

        drawPath(street1, color = OutlineVariantLight, style = Stroke(width = 12f * sx, cap = StrokeCap.Round))
        drawPath(street2, color = OutlineVariantLight, style = Stroke(width = 10f * sx, cap = StrokeCap.Round))
        drawPath(street3, color = OutlineVariantLight, style = Stroke(width = 12f * sx, cap = StrokeCap.Round))
        drawPath(street4, color = OutlineVariantLight, style = Stroke(width = 8f * sx, cap = StrokeCap.Round))

        // River doodle line
        val river = Path().apply {
            moveTo(0f, 20f * sy)
            quadraticTo(90f * sx, 10f * sy, 170f * sx, 30f * sy)
            quadraticTo(245f * sx, 48f * sy, 320f * sx, 20f * sy)
        }
        drawPath(
            river,
            color = PrimaryFixedDimCyan.copy(alpha = 0.65f),
            style = Stroke(
                width = 6f * sx,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f * sx, 4f * sx), 0f)
            )
        )

        // Little trees doodles
        val treeStroke = 1.5f * sx
        drawCircle(color = MapTreeMint, radius = 9f * sx, center = Offset(60f * sx, 95f * sy))
        drawCircle(color = PrimaryTeal, radius = 9f * sx, center = Offset(60f * sx, 95f * sy), style = Stroke(width = treeStroke))
        drawLine(PrimaryTeal, Offset(60f * sx, 104f * sy), Offset(60f * sx, 112f * sy), strokeWidth = treeStroke)

        drawCircle(color = MapTreeMint, radius = 11f * sx, center = Offset(260f * sx, 90f * sy))
        drawCircle(color = PrimaryTeal, radius = 11f * sx, center = Offset(260f * sx, 90f * sy), style = Stroke(width = treeStroke))
        drawLine(PrimaryTeal, Offset(260f * sx, 101f * sy), Offset(260f * sx, 114f * sy), strokeWidth = treeStroke)
    }
}

@Composable
fun DoodleBottomNavIcon(
    route: String,
    isSelected: Boolean,
    color: Color,
    modifier: Modifier = Modifier.size(24.dp)
) {
    Canvas(modifier = modifier) {
        val s = size.width / 24f
        val stroke = Stroke(width = if (isSelected) 2.1f * s else 1.8f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (route) {
            "home" -> {
                val house = Path().apply {
                    moveTo(3f * s, 10.5f * s)
                    lineTo(12f * s, 3f * s)
                    lineTo(21f * s, 10.5f * s)
                    lineTo(21f * s, 19.5f * s)
                    cubicTo(21f * s, 20.5f * s, 20f * s, 21.5f * s, 19f * s, 21.5f * s)
                    lineTo(5f * s, 21.5f * s)
                    cubicTo(4f * s, 21.5f * s, 3f * s, 20.5f * s, 3f * s, 19.5f * s)
                    close()
                }
                if (isSelected) {
                    drawPath(house, color = PrimaryFixedDimCyan.copy(alpha = 0.35f))
                }
                drawPath(house, color = color, style = stroke)
                val door = Path().apply {
                    moveTo(9f * s, 21.5f * s)
                    lineTo(9f * s, 12.5f * s)
                    lineTo(15f * s, 12.5f * s)
                    lineTo(15f * s, 21.5f * s)
                }
                drawPath(door, color = color, style = stroke)
            }

            "services" -> {
                val tooth = Path().apply {
                    moveTo(12f * s, 2f * s)
                    cubicTo(9f * s, 2f * s, 7f * s, 4f * s, 7f * s, 7f * s)
                    cubicTo(7f * s, 9.5f * s, 8f * s, 11.5f * s, 8f * s, 14f * s)
                    cubicTo(8f * s, 17f * s, 6f * s, 18f * s, 6f * s, 22f * s)
                    lineTo(10f * s, 22f * s)
                    cubicTo(10.5f * s, 19f * s, 11f * s, 16f * s, 12f * s, 16f * s)
                    cubicTo(13f * s, 16f * s, 13.5f * s, 19f * s, 14f * s, 22f * s)
                    lineTo(18f * s, 22f * s)
                    cubicTo(18f * s, 18f * s, 16f * s, 17f * s, 16f * s, 14f * s)
                    cubicTo(16f * s, 11.5f * s, 17f * s, 9.5f * s, 17f * s, 7f * s)
                    cubicTo(17f * s, 4f * s, 15f * s, 2f * s, 12f * s, 2f * s)
                    close()
                }
                if (isSelected) {
                    drawPath(tooth, color = PrimaryFixedDimCyan.copy(alpha = 0.35f))
                }
                drawPath(tooth, color = color, style = stroke)
            }

            "our-team" -> {
                if (isSelected) {
                    drawCircle(color = PrimaryFixedDimCyan.copy(alpha = 0.35f), radius = 4f * s, center = Offset(9f * s, 7f * s))
                }
                drawCircle(color = color, radius = 4f * s, center = Offset(9f * s, 7f * s), style = stroke)
                val body = Path().apply {
                    moveTo(17f * s, 21f * s)
                    lineTo(17f * s, 19f * s)
                    cubicTo(17f * s, 16.8f * s, 15.2f * s, 15f * s, 13f * s, 15f * s)
                    lineTo(5f * s, 15f * s)
                    cubicTo(2.8f * s, 15f * s, 1f * s, 16.8f * s, 1f * s, 19f * s)
                    lineTo(1f * s, 21f * s)
                }
                drawPath(body, color = color, style = stroke)
                val secondHead = Path().apply {
                    moveTo(16f * s, 3.13f * s)
                    cubicTo(19f * s, 4f * s, 19f * s, 10f * s, 16f * s, 10.88f * s)
                }
                val secondBody = Path().apply {
                    moveTo(23f * s, 21f * s)
                    lineTo(23f * s, 19f * s)
                    cubicTo(23f * s, 17.2f * s, 21.8f * s, 15.6f * s, 20f * s, 15.13f * s)
                }
                drawPath(secondHead, color = color, style = stroke)
                drawPath(secondBody, color = color, style = stroke)
            }

            else -> {
                val pin = Path().apply {
                    moveTo(21f * s, 10f * s)
                    cubicTo(21f * s, 17f * s, 12f * s, 23f * s, 12f * s, 23f * s)
                    cubicTo(12f * s, 23f * s, 3f * s, 17f * s, 3f * s, 10f * s)
                    cubicTo(3f * s, 5f * s, 7f * s, 1f * s, 12f * s, 1f * s)
                    cubicTo(17f * s, 1f * s, 21f * s, 5f * s, 21f * s, 10f * s)
                    close()
                }
                if (isSelected) {
                    drawPath(pin, color = PrimaryFixedDimCyan.copy(alpha = 0.35f))
                }
                drawPath(pin, color = color, style = stroke)
                drawCircle(color = color, radius = 3f * s, center = Offset(12f * s, 10f * s), style = stroke)
            }
        }
    }
}
