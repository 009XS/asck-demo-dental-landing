package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.BookedAppointment
import com.example.model.ComfortAmenity
import com.example.model.ComfortMood
import com.example.model.DentalService
import com.example.model.TeamMember
import com.example.ui.components.DashedLineSeparator
import com.example.ui.components.DoodleCalendarIcon
import com.example.ui.components.DoodleHeartIcon
import com.example.ui.components.DoodleMoodFace
import com.example.ui.components.DoodleServiceCardIcon
import com.example.ui.components.DoodleStarSparkleYellow
import com.example.ui.components.DoodleVerifiedBadge
import com.example.ui.components.SketchCard
import com.example.ui.components.SketchPill
import com.example.ui.components.SketchTape
import com.example.ui.components.horizontalScrollDrivenEffect
import com.example.ui.components.scrollDrivenParallaxAndFade
import com.example.ui.components.sketchbookPaperBackground
import com.example.ui.theme.CaveatFontFamily
import com.example.ui.theme.KalamFontFamily
import com.example.ui.theme.LiveStatusMint
import com.example.ui.theme.OnPrimaryWhite
import com.example.ui.theme.OnSecondaryContainerBrown
import com.example.ui.theme.OnSurfaceCharcoal
import com.example.ui.theme.OnSurfaceVariantSlate
import com.example.ui.theme.OnTertiaryFixedDark
import com.example.ui.theme.PatrickHandFontFamily
import com.example.ui.theme.PostItWarmYellow
import com.example.ui.theme.PrimaryFixedDimCyan
import com.example.ui.theme.PrimaryTeal
import com.example.ui.theme.QuotePaperCream
import com.example.ui.theme.SecondaryContainerCoral
import com.example.ui.theme.SecondaryCoralDark
import com.example.ui.theme.SurfaceContainerHigh
import com.example.ui.theme.SurfaceContainerLow
import com.example.ui.theme.SurfaceContainerLowest
import com.example.ui.theme.TagSoftCoral
import com.example.ui.theme.TagSoftTeal
import com.example.ui.theme.TertiaryFixedGold
import com.example.ui.theme.TertiaryGoldDark

@Composable
fun BookAppointmentOverlaySheet(
    services: List<DentalService>,
    teamMembers: List<TeamMember>,
    comfortAmenities: List<ComfortAmenity>,
    preselectedService: DentalService,
    selectedMood: ComfortMood,
    selectedAmenities: Set<String>,
    bookedAppointments: List<BookedAppointment>,
    lastConfirmation: BookedAppointment?,
    onSelectMood: (ComfortMood) -> Unit,
    onToggleAmenity: (String) -> Unit,
    onConfirmBooking: (
        service: DentalService,
        doctorName: String,
        dayLabel: String,
        timeSlot: String,
        patientName: String,
        patientPhone: String,
        includeGiftBox: Boolean
    ) -> Unit,
    onDismiss: () -> Unit
) {
    BackHandler(onBack = onDismiss)

    var chosenService by remember(preselectedService) { mutableStateOf(preselectedService) }
    var chosenSpecialist by remember { mutableStateOf(teamMembers.first().name) }
    var chosenDay by remember { mutableStateOf("Hoy, Mar 20") }
    var chosenTime by remember { mutableStateOf("10:30 AM") }
    var patientName by remember { mutableStateOf("") }
    var patientPhone by remember { mutableStateOf("") }
    var includeGiftBox by remember { mutableStateOf(true) }

    val availableDays = listOf(
        "Hoy, Mar 20",
        "Mañana, Mié 21",
        "Jue 22 Oct",
        "Vie 23 Oct",
        "Sáb 24 Oct",
        "Lun 26 Oct"
    )
    val availableTimes = listOf(
        "09:00 AM",
        "10:30 AM",
        "12:00 PM",
        "02:15 PM",
        "04:00 PM",
        "05:15 PM"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(OnSurfaceCharcoal.copy(alpha = 0.55f))
            .clickable(onClick = onDismiss),
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 36.dp)
                .windowInsetsPadding(WindowInsets.statusBars)
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .border(
                    width = 2.5.dp,
                    color = OnSurfaceCharcoal,
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
                )
                .sketchbookPaperBackground()
                .clickable(enabled = false, onClick = {})
                .verticalScroll(rememberScrollState())
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(18.dp)
                .testTag("booking_sheet_modal")
        ) {
            // Top Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "RESERVA EN 60 SEGUNDOS ✎",
                        fontFamily = PatrickHandFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = PrimaryTeal
                    )
                    Text(
                        text = "Tu Cita Dental Sin Ansiedad",
                        fontFamily = KalamFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                        color = OnSurfaceCharcoal
                    )
                }

                SketchPill(
                    backgroundColor = SurfaceContainerHigh,
                    onClick = onDismiss,
                    modifier = Modifier.testTag("close_booking_sheet_button")
                ) {
                    Text(
                        text = "✕ Cerrar",
                        fontFamily = PatrickHandFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = OnSurfaceCharcoal,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            AnimatedContent(
                targetState = lastConfirmation,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "bookingConfirmationAnim"
            ) { confirmation ->
                if (confirmation != null) {
                    SketchCard(
                        backgroundColor = PostItWarmYellow,
                        shadowColor = PrimaryTeal,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            DoodleStarSparkleYellow(modifier = Modifier.size(36.dp))
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "¡Turno Reservado con Éxito!",
                                fontFamily = KalamFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 22.sp,
                                color = PrimaryTeal,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "Te esperamos con tu menú de confort listo.",
                                fontFamily = CaveatFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 19.sp,
                                color = SecondaryCoralDark
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            DashedLineSeparator()
                            Spacer(modifier = Modifier.height(12.dp))

                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "✦ Servicio: ${confirmation.serviceTitle}",
                                    fontFamily = PatrickHandFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = OnSurfaceCharcoal
                                )
                                Text(
                                    text = "✦ Fecha y Hora: ${confirmation.dayLabel} a las ${confirmation.timeSlot}",
                                    fontFamily = PatrickHandFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = PrimaryTeal
                                )
                                Text(
                                    text = "✦ Especialista: ${confirmation.doctorName}",
                                    fontFamily = PatrickHandFontFamily,
                                    fontSize = 14.5.sp,
                                    color = OnSurfaceCharcoal
                                )
                                Text(
                                    text = "✦ Nivel de Confort: ${confirmation.mood.label}",
                                    fontFamily = PatrickHandFontFamily,
                                    fontSize = 14.5.sp,
                                    color = OnSurfaceCharcoal
                                )
                                if (confirmation.selectedAmenities.isNotEmpty()) {
                                    Text(
                                        text = "✦ Menú de Confort: ${confirmation.selectedAmenities.joinToString(", ")}",
                                        fontFamily = PatrickHandFontFamily,
                                        fontSize = 13.5.sp,
                                        color = OnSurfaceVariantSlate
                                    )
                                }
                                if (confirmation.includeFreeElectricBrushBox) {
                                    SketchPill(
                                        backgroundColor = SecondaryContainerCoral,
                                        modifier = Modifier.padding(top = 4.dp)
                                    ) {
                                        Text(
                                            text = "🎁 Caja de Regalo con Cepillo Eléctrico reservada a tu nombre",
                                            fontFamily = PatrickHandFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.5.sp,
                                            color = OnSecondaryContainerBrown,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            SketchCard(
                                backgroundColor = PrimaryTeal,
                                onClick = onDismiss,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "Volver al Estudio SmileCraft",
                                    fontFamily = PatrickHandFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.5.sp,
                                    color = OnPrimaryWhite
                                )
                            }
                        }
                    }
                } else {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // 1. Horizontal Scrollable Service Selector
                        Text(
                            text = "1. Elige tu cuidado suave (desliza →):",
                            fontFamily = KalamFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.5.sp,
                            color = OnSurfaceCharcoal
                        )
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(services, key = { it.id }) { service ->
                                val isSelected = chosenService.id == service.id
                                SketchCard(
                                    backgroundColor = if (isSelected) TagSoftTeal else SurfaceContainerLowest,
                                    shadowColor = if (isSelected) PrimaryTeal else OnSurfaceCharcoal,
                                    onClick = { chosenService = service },
                                    modifier = Modifier.width(210.dp)
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = service.categoryTag,
                                                fontFamily = PatrickHandFontFamily,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.5.sp,
                                                color = service.tagTextColor
                                            )
                                            Text(
                                                text = service.priceMain.ifEmpty { "Hoy" },
                                                fontFamily = KalamFontFamily,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 16.sp,
                                                color = PrimaryTeal
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = service.title,
                                            fontFamily = KalamFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.5.sp,
                                            lineHeight = 18.sp,
                                            color = OnSurfaceCharcoal,
                                            maxLines = 2
                                        )
                                    }
                                }
                            }
                        }

                        // 2. Horizontal Scrollable Date & Time Slot Picker
                        Text(
                            text = "2. Elige día y horario disponible (desliza →):",
                            fontFamily = KalamFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.5.sp,
                            color = OnSurfaceCharcoal
                        )
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(availableDays) { day ->
                                val isSelected = chosenDay == day
                                SketchPill(
                                    backgroundColor = if (isSelected) PrimaryTeal else SurfaceContainerLowest,
                                    onClick = { chosenDay = day }
                                ) {
                                    Text(
                                        text = day,
                                        fontFamily = PatrickHandFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (isSelected) OnPrimaryWhite else OnSurfaceCharcoal,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                                    )
                                }
                            }
                        }

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(availableTimes) { slot ->
                                val isSelected = chosenTime == slot
                                SketchPill(
                                    backgroundColor = if (isSelected) SecondaryContainerCoral else SurfaceContainerLowest,
                                    onClick = { chosenTime = slot }
                                ) {
                                    Text(
                                        text = "🕒 $slot",
                                        fontFamily = PatrickHandFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (isSelected) OnSecondaryContainerBrown else OnSurfaceCharcoal,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }

                        // 3. Horizontal Scrollable Specialist Selector
                        Text(
                            text = "3. Tu especialista de confort:",
                            fontFamily = KalamFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.5.sp,
                            color = OnSurfaceCharcoal
                        )
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(teamMembers, key = { it.id }) { member ->
                                val isSelected = chosenSpecialist == member.name
                                SketchPill(
                                    backgroundColor = if (isSelected) TagSoftTeal else SurfaceContainerLowest,
                                    onClick = { chosenSpecialist = member.name }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        AsyncImage(
                                            model = member.imageUrl,
                                            contentDescription = member.name,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .size(28.dp)
                                                .clip(CircleShape)
                                                .border(1.5.dp, OnSurfaceCharcoal, CircleShape)
                                        )
                                        Column {
                                            Text(
                                                text = member.name,
                                                fontFamily = PatrickHandFontFamily,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.5.sp,
                                                color = OnSurfaceCharcoal
                                            )
                                            Text(
                                                text = member.role,
                                                fontFamily = PatrickHandFontFamily,
                                                fontSize = 10.5.sp,
                                                color = OnSurfaceVariantSlate
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // 4. Mood & Free Comfort Menu Selector
                        Text(
                            text = "4. Menú de Confort Gratuito incluido:",
                            fontFamily = KalamFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.5.sp,
                            color = OnSurfaceCharcoal
                        )
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(comfortAmenities, key = { it.id }) { amenity ->
                                val isAdded = selectedAmenities.contains(amenity.title)
                                SketchPill(
                                    backgroundColor = if (isAdded) PrimaryFixedDimCyan else SurfaceContainerLowest,
                                    onClick = { onToggleAmenity(amenity.title) }
                                ) {
                                    Text(
                                        text = if (isAdded) "✓ ${amenity.title}" else "+ ${amenity.title}",
                                        fontFamily = PatrickHandFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = OnSurfaceCharcoal,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }

                        // 5. Patient Name & Phone Sketchy Inputs + Free Gift Toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            SketchCard(
                                backgroundColor = SurfaceContainerLowest,
                                shadowOffsetX = 2.dp,
                                shadowOffsetY = 2.dp,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
                                    if (patientName.isEmpty()) {
                                        Text(
                                            text = "Tu nombre (ej. Sofía)",
                                            fontFamily = PatrickHandFontFamily,
                                            fontSize = 14.sp,
                                            color = OnSurfaceVariantSlate.copy(alpha = 0.6f)
                                        )
                                    }
                                    BasicTextField(
                                        value = patientName,
                                        onValueChange = { patientName = it },
                                        textStyle = TextStyle(
                                            fontFamily = PatrickHandFontFamily,
                                            fontSize = 14.5.sp,
                                            color = OnSurfaceCharcoal
                                        ),
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }

                            SketchCard(
                                backgroundColor = SurfaceContainerLowest,
                                shadowOffsetX = 2.dp,
                                shadowOffsetY = 2.dp,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
                                    if (patientPhone.isEmpty()) {
                                        Text(
                                            text = "WhatsApp / Teléfono",
                                            fontFamily = PatrickHandFontFamily,
                                            fontSize = 14.sp,
                                            color = OnSurfaceVariantSlate.copy(alpha = 0.6f)
                                        )
                                    }
                                    BasicTextField(
                                        value = patientPhone,
                                        onValueChange = { patientPhone = it },
                                        textStyle = TextStyle(
                                            fontFamily = PatrickHandFontFamily,
                                            fontSize = 14.5.sp,
                                            color = OnSurfaceCharcoal
                                        ),
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }

                        // Gift box toggle
                        SketchCard(
                            backgroundColor = if (includeGiftBox) PostItWarmYellow else SurfaceContainerLowest,
                            onClick = { includeGiftBox = !includeGiftBox },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                DoodleHeartIcon(modifier = Modifier.size(20.dp))
                                Text(
                                    text = if (includeGiftBox) {
                                        "✓ ¡Incluir mi caja de regalo con cepillo eléctrico gratis! (1ª visita)"
                                    } else {
                                        "Incluir caja de regalo con cepillo eléctrico gratis (1ª visita)"
                                    },
                                    fontFamily = PatrickHandFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = OnSurfaceCharcoal
                                )
                            }
                        }

                        // Submit CTA
                        SketchCard(
                            backgroundColor = PrimaryTeal,
                            onClick = {
                                onConfirmBooking(
                                    chosenService,
                                    chosenSpecialist,
                                    chosenDay,
                                    chosenTime,
                                    patientName,
                                    patientPhone,
                                    includeGiftBox
                                )
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("confirm_booking_submit_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                DoodleCalendarIcon(
                                    color = OnPrimaryWhite,
                                    hasCheckmark = true,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = "Confirmar Cita • $chosenDay ($chosenTime)",
                                    fontFamily = PatrickHandFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = OnPrimaryWhite
                                )
                            }
                        }

                        // Previous bookings list if any
                        if (bookedAppointments.isNotEmpty()) {
                            DashedLineSeparator()
                            Text(
                                text = "Tus Citas Guardadas (${bookedAppointments.size}):",
                                fontFamily = KalamFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = PrimaryTeal
                            )
                            bookedAppointments.forEach { appt ->
                                SketchPill(
                                    backgroundColor = LiveStatusMint,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "✓ ${appt.dayLabel} ${appt.timeSlot} • ${appt.serviceTitle} (${appt.doctorName})",
                                        fontFamily = PatrickHandFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.5.sp,
                                        color = PrimaryTeal,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ServiceDetailOverlaySheet(
    service: DentalService,
    onBookService: (DentalService) -> Unit,
    onDismiss: () -> Unit
) {
    BackHandler(onBack = onDismiss)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(OnSurfaceCharcoal.copy(alpha = 0.55f))
            .clickable(onClick = onDismiss),
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .border(
                    width = 2.5.dp,
                    color = OnSurfaceCharcoal,
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
                )
                .sketchbookPaperBackground()
                .clickable(enabled = false, onClick = {})
                .verticalScroll(rememberScrollState())
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(18.dp)
                .testTag("service_detail_modal")
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SketchPill(backgroundColor = service.tagBgColor) {
                    Text(
                        text = "${service.categoryTag} • ${service.durationNote}",
                        fontFamily = PatrickHandFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.5.sp,
                        color = service.tagTextColor,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                    )
                }

                SketchPill(
                    backgroundColor = SurfaceContainerHigh,
                    onClick = onDismiss
                ) {
                    Text(
                        text = "✕ Cerrar",
                        fontFamily = PatrickHandFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = OnSurfaceCharcoal,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                DoodleServiceCardIcon(iconType = service.iconType, modifier = Modifier.size(34.dp))
                Text(
                    text = service.title,
                    fontFamily = KalamFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                    lineHeight = 27.sp,
                    color = OnSurfaceCharcoal
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = service.description,
                fontFamily = PatrickHandFontFamily,
                fontSize = 15.5.sp,
                lineHeight = 21.sp,
                color = OnSurfaceVariantSlate
            )

            Spacer(modifier = Modifier.height(14.dp))

            SketchCard(
                backgroundColor = SurfaceContainerLowest,
                shadowColor = service.shadowColor,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Paso a paso sin ansiedad ✎",
                        fontFamily = KalamFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = PrimaryTeal
                    )
                    service.steps.forEachIndexed { idx, step ->
                        Row(
                            verticalAlignment = Alignment.Top,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(22.dp)
                                    .background(service.tagBgColor, CircleShape)
                                    .border(1.5.dp, OnSurfaceCharcoal, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${idx + 1}",
                                    fontFamily = KalamFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = service.tagTextColor
                                )
                            }
                            Text(
                                text = step,
                                fontFamily = PatrickHandFontFamily,
                                fontSize = 14.sp,
                                lineHeight = 19.sp,
                                color = OnSurfaceCharcoal,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Horizontal Scrollable Comfort Perks included
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                service.comfortIncluded.forEach { perk ->
                    SketchPill(backgroundColor = PostItWarmYellow) {
                        Text(
                            text = "✦ $perk",
                            fontFamily = PatrickHandFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.5.sp,
                            color = OnSurfaceCharcoal,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            SketchCard(
                backgroundColor = PrimaryTeal,
                onClick = { onBookService(service) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DoodleCalendarIcon(color = OnPrimaryWhite, modifier = Modifier.size(20.dp))
                    Text(
                        text = "Reservar ${service.title.take(24)}...",
                        fontFamily = PatrickHandFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.5.sp,
                        color = OnPrimaryWhite
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TeamMemberDetailOverlaySheet(
    member: TeamMember,
    onBookWithMember: () -> Unit,
    onDismiss: () -> Unit
) {
    BackHandler(onBack = onDismiss)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(OnSurfaceCharcoal.copy(alpha = 0.55f))
            .clickable(onClick = onDismiss),
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .border(
                    width = 2.5.dp,
                    color = OnSurfaceCharcoal,
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
                )
                .sketchbookPaperBackground()
                .clickable(enabled = false, onClick = {})
                .verticalScroll(rememberScrollState())
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(18.dp)
                .testTag("team_member_detail_modal")
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                SketchPill(backgroundColor = TertiaryFixedGold.copy(alpha = 0.5f)) {
                    Text(
                        text = member.badge,
                        fontFamily = CaveatFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = TertiaryGoldDark,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }

                SketchPill(
                    backgroundColor = SurfaceContainerHigh,
                    onClick = onDismiss
                ) {
                    Text(
                        text = "✕ Cerrar",
                        fontFamily = PatrickHandFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = OnSurfaceCharcoal,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                AsyncImage(
                    model = member.imageUrl,
                    contentDescription = member.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(84.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .border(2.dp, OnSurfaceCharcoal, RoundedCornerShape(16.dp))
                )
                Column {
                    Text(
                        text = member.name,
                        fontFamily = KalamFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                        color = OnSurfaceCharcoal
                    )
                    Text(
                        text = member.role,
                        fontFamily = PatrickHandFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = PrimaryTeal
                    )
                    Text(
                        text = "♥ Certificada en Cuidado Suave",
                        fontFamily = CaveatFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = SecondaryCoralDark
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            SketchCard(
                backgroundColor = QuotePaperCream,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = member.quote,
                        fontFamily = PatrickHandFontFamily,
                        fontStyle = FontStyle.Italic,
                        fontSize = 15.sp,
                        lineHeight = 20.sp,
                        color = OnSurfaceCharcoal
                    )
                    DashedLineSeparator()
                    Text(
                        text = "✦ Superpoder en clínica: ${member.superpower}",
                        fontFamily = PatrickHandFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.5.sp,
                        color = PrimaryTeal
                    )
                    Text(
                        text = "🎧 Playlist favorita para pacientes: ${member.favoritePlaylist}",
                        fontFamily = PatrickHandFontFamily,
                        fontSize = 13.5.sp,
                        color = OnSurfaceVariantSlate
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                member.specialties.forEach { spec ->
                    SketchPill(backgroundColor = SurfaceContainerLow) {
                        Text(
                            text = spec,
                            fontFamily = PatrickHandFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = OnSurfaceCharcoal,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            SketchCard(
                backgroundColor = SecondaryContainerCoral,
                onClick = onBookWithMember,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Reservar Cita Tranquila con ${member.name}",
                    fontFamily = PatrickHandFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.5.sp,
                    color = OnSecondaryContainerBrown
                )
            }
        }
    }
}
