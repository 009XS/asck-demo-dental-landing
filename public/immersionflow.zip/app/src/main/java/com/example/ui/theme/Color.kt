package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Exact Warm Sketch Dental palette from HTML & Markdown Design System
val SketchSurface = Color(0xFFFBFAF7)
val SketchSurfaceDim = Color(0xFFD9DADC)
val SketchSurfaceBright = Color(0xFFFBFAF7)
val SurfaceContainerLowest = Color(0xFFFFFFFF)
val SurfaceContainerLow = Color(0xFFF5F3EE)
val SurfaceContainer = Color(0xFFEDEEF0)
val SurfaceContainerHigh = Color(0xFFE8E8EA)
val SurfaceContainerHighest = Color(0xFFE2E2E5)

val OnSurfaceCharcoal = Color(0xFF1A1C1E)
val OnSurfaceVariantSlate = Color(0xFF3E494A)
val OutlineSlate = Color(0xFF6E797B)
val OutlineVariantLight = Color(0xFFBDC9CA)

val PrimaryTeal = Color(0xFF00666F)
val OnPrimaryWhite = Color(0xFFFFFFFF)
val PrimaryContainerTeal = Color(0xFF00818C)
val OnPrimaryContainerIce = Color(0xFFF6FEFF)
val PrimaryFixedCyan = Color(0xFF91F1FD)
val PrimaryFixedDimCyan = Color(0xFF74D5E1)
val OnPrimaryFixedDark = Color(0xFF001F23)
val OnPrimaryFixedVariantTeal = Color(0xFF004F56)

val SecondaryCoralDark = Color(0xFFA9371D)
val OnSecondaryWhite = Color(0xFFFFFFFF)
val SecondaryContainerCoral = Color(0xFFFD7454)
val OnSecondaryContainerBrown = Color(0xFF6B1200)
val SecondaryFixedPeach = Color(0xFFFFDAD2)
val SecondaryFixedDimPeach = Color(0xFFFFB4A3)

val TertiaryGoldDark = Color(0xFF795500)
val OnTertiaryWhite = Color(0xFFFFFFFF)
val TertiaryContainerGold = Color(0xFF996D00)
val TertiaryFixedGold = Color(0xFFFFDEA8)
val TertiaryFixedDimSunbeam = Color(0xFFFABC3F)
val OnTertiaryFixedDark = Color(0xFF271900)

val ErrorRed = Color(0xFFBA1A1A)
val OnErrorWhite = Color(0xFFFFFFFF)
val ErrorContainerRose = Color(0xFFFFDAD6)
val OnErrorContainerDark = Color(0xFF93000A)

// Specific sketchy card & sticker fills from HTML
val PostItWarmYellow = Color(0xFFFFF9EA)
val StickerSoftCyan = Color(0xFFF3F9F9)
val TagSoftTeal = Color(0xFFF0F9F9)
val TagSoftCoral = Color(0xFFFFF4F1)
val TagSoftGold = Color(0xFFFFF9E6)
val QuotePaperCream = Color(0xFFFFFDFA)
val TestimonialNoteCream = Color(0xFFFFFDF8)
val MapCanvasGray = Color(0xFFF4F7F6)
val MapTreeMint = Color(0xFFE2F5F3)
val LiveStatusMint = Color(0xFFE0F5F6)
val TapeAmber = Color(0xBFFABC3F)
