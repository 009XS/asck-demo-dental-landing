package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val WarmSketchColorScheme = lightColorScheme(
    primary = PrimaryTeal,
    onPrimary = OnPrimaryWhite,
    primaryContainer = PrimaryContainerTeal,
    onPrimaryContainer = OnPrimaryContainerIce,
    secondary = SecondaryCoralDark,
    onSecondary = OnSecondaryWhite,
    secondaryContainer = SecondaryContainerCoral,
    onSecondaryContainer = OnSecondaryContainerBrown,
    tertiary = TertiaryGoldDark,
    onTertiary = OnTertiaryWhite,
    tertiaryContainer = TertiaryContainerGold,
    error = ErrorRed,
    onError = OnErrorWhite,
    errorContainer = ErrorContainerRose,
    onErrorContainer = OnErrorContainerDark,
    background = SketchSurface,
    onBackground = OnSurfaceCharcoal,
    surface = SketchSurface,
    onSurface = OnSurfaceCharcoal,
    surfaceVariant = SurfaceContainerHigh,
    onSurfaceVariant = OnSurfaceVariantSlate,
    outline = OutlineSlate,
    outlineVariant = OutlineVariantLight
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = WarmSketchColorScheme,
        typography = Typography,
        content = content
    )
}
