package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.ComfortAmenity
import com.example.model.ComfortMood
import com.example.model.DentalService
import com.example.model.HtmlAssets
import com.example.ui.components.DashedLineSeparator
import com.example.ui.components.DoodleCalendarIcon
import com.example.ui.components.DoodleClockIcon
import com.example.ui.components.DoodleComfortMessageIcon
import com.example.ui.components.DoodleCurvedArrowDownRight
import com.example.ui.components.DoodleHeadphonesIcon
import com.example.ui.components.DoodleHeartIcon
import com.example.ui.components.DoodleMoodFace
import com.example.ui.components.DoodlePencilIcon
import com.example.ui.components.DoodlePhoneIcon
import com.example.ui.components.DoodleServiceCardIcon
import com.example.ui.components.DoodleSmileFaceIcon
import com.example.ui.components.DoodleSparkle
import com.example.ui.components.DoodleStarSparkleYellow
import com.example.ui.components.DoodleStarburstTopRight
import com.example.ui.components.DoodleVerifiedBadge
import com.example.ui.components.SketchCard
import com.example.ui.components.SketchPill
import com.example.ui.components.SketchTape
import com.example.ui.components.horizontalScrollDrivenEffect
import com.example.ui.components.rememberScrollParallaxProgress
import com.example.ui.components.scrollDrivenParallaxAndFade
import com.example.ui.theme.CaveatFontFamily
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.KalamFontFamily
import com.example.ui.theme.OnPrimaryFixedDark
import com.example.ui.theme.OnPrimaryWhite
import com.example.ui.theme.OnSecondaryContainerBrown
import com.example.ui.theme.OnSecondaryWhite
import com.example.ui.theme.OnSurfaceCharcoal
import com.example.ui.theme.OnSurfaceVariantSlate
import com.example.ui.theme.OnTertiaryFixedDark
import com.example.ui.theme.OutlineSlate
import com.example.ui.theme.PatrickHandFontFamily
import com.example.ui.theme.PostItWarmYellow
import com.example.ui.theme.PrimaryFixedDimCyan
import com.example.ui.theme.PrimaryTeal
import com.example.ui.theme.SecondaryContainerCoral
import com.example.ui.theme.SecondaryCoralDark
import com.example.ui.theme.SecondaryFixedPeach
import com.example.ui.theme.SketchSurface
import com.example.ui.theme.StickerSoftCyan
import com.example.ui.theme.SurfaceContainerHigh
import com.example.ui.theme.SurfaceContainerLow
import com.example.ui.theme.SurfaceContainerLowest
import com.example.ui.theme.TagSoftTeal
import com.example.ui.theme.TertiaryFixedDimSunbeam
import com.example.ui.theme.TertiaryFixedGold
import com.example.ui.theme.TertiaryGoldDark
import kotlin.math.abs

@Composable
fun SmileCraftTopBar(
    bookedCount: Int,
    scrollFraction: Float = 0f,
    onBookClick: () -> Unit,
    onProfileClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val animatedScrollFraction by animateFloatAsState(
        targetValue = scrollFraction.coerceIn(0f, 1f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "topBarScrollFraction"
    )
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(SketchSurface.copy(alpha = 0.94f))
            .windowInsetsPadding(WindowInsets.statusBars)
            .drawBehind {
                drawLine(
                    color = OnSurfaceCharcoal.copy(alpha = 0.22f),
                    start = Offset(0f, size.height),
                    end = Offset(size.width, size.height),
                    strokeWidth = 2.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 4.dp.toPx()), 0f)
                )
                // Live hand-drawn coral & teal scroll progress bar along bottom edge
                if (animatedScrollFraction > 0.01f) {
                    val progressWidth = size.width * animatedScrollFraction
                    drawLine(
                        color = SecondaryContainerCoral,
                        start = Offset(0f, size.height - 1.dp.toPx()),
                        end = Offset(progressWidth, size.height - 1.dp.toPx()),
                        strokeWidth = 3.5.dp.toPx(),
                        cap = StrokeCap.Round
                    )
                }
            }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(64.dp)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left Logo + Brand Title
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(modifier = Modifier.size(36.dp)) {
                    AsyncImage(
                        model = HtmlAssets.LOGO_URL,
                        contentDescription = "Toothie Scribble Dental Logo",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                    DoodleSparkle(
                        color = SecondaryCoralDark,
                        modifier = Modifier
                            .size(14.dp)
                            .align(Alignment.TopEnd)
                            .offset(x = 4.dp, y = (-2).dp)
                    )
                }

                Column {
                    Box {
                        Text(
                            text = "SmileCraft",
                            fontFamily = KalamFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 21.sp,
                            color = PrimaryTeal,
                            lineHeight = 22.sp
                        )
                        Canvas(
                            modifier = Modifier
                                .width(86.dp)
                                .height(4.dp)
                                .align(Alignment.BottomStart)
                                .offset(y = 2.dp)
                        ) {
                            val path = Path().apply {
                                moveTo(1f, size.height * 0.5f)
                                cubicTo(
                                    size.width * 0.25f, size.height,
                                    size.width * 0.75f, 0f,
                                    size.width - 1f, size.height * 0.6f
                                )
                            }
                            drawPath(
                                path,
                                color = PrimaryTeal.copy(alpha = 0.4f),
                                style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }
                    }
                    Text(
                        text = "boutique dental acogedora ✎",
                        fontFamily = CaveatFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        color = OnSurfaceVariantSlate,
                        modifier = Modifier
                            .rotate(-2f)
                            .padding(top = 1.dp)
                    )
                }
            }

            // Right Actions: Reservar Pill + Dashed Profile Avatar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SketchPill(
                    backgroundColor = SecondaryContainerCoral,
                    onClick = onBookClick,
                    modifier = Modifier
                        .height(42.dp)
                        .testTag("header_book_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        DoodlePencilIcon(
                            color = OnSecondaryContainerBrown,
                            modifier = Modifier.size(15.dp)
                        )
                        Text(
                            text = "Reservar",
                            fontFamily = PatrickHandFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.5.sp,
                            color = OnSecondaryContainerBrown
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .rotate(3f)
                        .clickable(onClick = onProfileClick)
                        .testTag("header_profile_avatar")
                        .drawBehind {
                            drawCircle(
                                color = OnSurfaceCharcoal,
                                radius = size.minDimension / 2f - 1.dp.toPx(),
                                style = Stroke(
                                    width = 2.dp.toPx(),
                                    pathEffect = PathEffect.dashPathEffect(
                                        floatArrayOf(4.dp.toPx(), 3.dp.toPx()),
                                        0f
                                    )
                                )
                            )
                        }
                        .padding(3.dp)
                ) {
                    AsyncImage(
                        model = HtmlAssets.DR_MAYA_URL,
                        contentDescription = "Perfil de paciente",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                    )
                    if (bookedCount > 0) {
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .align(Alignment.TopEnd)
                                .background(PrimaryTeal, CircleShape)
                                .border(1.5.dp, OnSurfaceCharcoal, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = bookedCount.toString(),
                                color = OnPrimaryWhite,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TopAmbientPostItBanner(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (scrollProgress, trackMod) = rememberScrollParallaxProgress()
    Box(
        modifier = modifier
            .fillMaxWidth()
            .then(trackMod)
            .scrollDrivenParallaxAndFade(
                maxParallaxDp = 12.dp,
                minAlpha = 0.35f,
                minScale = 0.94f,
                indexParity = 0
            )
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        SketchCard(
            backgroundColor = PostItWarmYellow,
            rotationDegrees = -0.5f,
            onClick = onClick,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("first_visit_banner")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 14.dp, end = 14.dp, top = 16.dp, bottom = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    DoodleHeartIcon(
                        modifier = Modifier
                            .size(21.dp)
                            .graphicsLayer {
                                val p = scrollProgress.value
                                translationY = -p * 6.dp.toPx()
                                rotationZ = p * 14f
                            }
                    )
                    Text(
                        text = "¿Primera visita? ¡Caja de regalo con cepillo eléctrico gratis!",
                        fontFamily = PatrickHandFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 14.sp,
                        lineHeight = 18.sp,
                        color = OnSurfaceCharcoal
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                SketchPill(
                    backgroundColor = SecondaryContainerCoral,
                    rotationDegrees = 1.5f,
                    modifier = Modifier.graphicsLayer {
                        translationX = scrollProgress.value * 5.dp.toPx()
                    }
                ) {
                    Text(
                        text = "Nuevo Paciente",
                        fontFamily = PatrickHandFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.5.sp,
                        color = OnSecondaryContainerBrown,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // Tape sticker doodle top center with counter-parallax
        SketchTape(
            rotationDegrees = -2f,
            modifier = Modifier
                .width(80.dp)
                .height(22.dp)
                .align(Alignment.TopCenter)
                .offset(y = (-8).dp)
                .graphicsLayer {
                    translationX = -scrollProgress.value * 8.dp.toPx()
                }
        ) {
            Box(
                modifier = Modifier
                    .width(46.dp)
                    .height(2.dp)
                    .background(OnTertiaryFixedDark.copy(alpha = 0.3f), CircleShape)
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HeroSection(
    comfortAmenities: List<ComfortAmenity>,
    selectedAmenities: Set<String>,
    onToggleAmenity: (String) -> Unit,
    onBookClick: () -> Unit,
    onCallClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "heroAnimations")
    val arrowBounce by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 4f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "arrowBounce"
    )
    val (heroScrollProgress, heroTrackMod) = rememberScrollParallaxProgress()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .then(heroTrackMod)
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .graphicsLayer {
                    val p = heroScrollProgress.value
                    translationY = p * 10.dp.toPx()
                    alpha = (1f - abs(p) * 0.25f).coerceIn(0.45f, 1f)
                }
        ) {
            // Top right starburst doodle with scroll-driven rotation & parallax
            DoodleStarburstTopRight(
                modifier = Modifier
                    .size(44.dp)
                    .align(Alignment.TopEnd)
                    .offset(x = (-4).dp, y = (-4).dp)
                    .graphicsLayer {
                        val p = heroScrollProgress.value
                        translationY = -p * 18.dp.toPx()
                        rotationZ = p * 35f
                    }
            )

            Column(modifier = Modifier.fillMaxWidth()) {
                // Sticker Pill: ODONTOLOGÍA BOUTIQUE SIN ANSIEDAD
                SketchPill(
                    backgroundColor = StickerSoftCyan,
                    rotationDegrees = -1f,
                    modifier = Modifier
                        .padding(bottom = 14.dp)
                        .graphicsLayer {
                            translationX = -heroScrollProgress.value * 6.dp.toPx()
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        DoodleVerifiedBadge(modifier = Modifier.size(16.dp))
                        Text(
                            text = "ODONTOLOGÍA BOUTIQUE SIN ANSIEDAD",
                            fontFamily = PatrickHandFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.5.sp,
                            letterSpacing = 0.6.sp,
                            color = PrimaryTeal
                        )
                    }
                }

                // Main Headline with Hand-drawn Highlighter Swash and Underlines
                HeadlineWithDoodles(scrollProgress = heroScrollProgress.value)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = "Dile adiós al miedo al dentista. Disfruta de un cuidado dental tranquilo, cómodo y verdaderamente sin dolor en nuestro acogedor estudio bañado de sol.",
            fontFamily = PatrickHandFontFamily,
            fontSize = 16.sp,
            lineHeight = 22.5.sp,
            color = OnSurfaceVariantSlate,
            modifier = Modifier.graphicsLayer {
                val p = heroScrollProgress.value
                translationY = p * 6.dp.toPx()
                alpha = (1f - abs(p) * 0.3f).coerceIn(0.4f, 1f)
            }
        )

        Spacer(modifier = Modifier.height(26.dp))

        // CTAs with Doodle pointer "¡Reserva en 60s! ↘"
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .scrollDrivenParallaxAndFade(
                    maxParallaxDp = 10.dp,
                    minAlpha = 0.45f,
                    minScale = 0.95f,
                    indexParity = 1
                )
        ) {
            Row(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(y = (-28).dp, x = (-4).dp)
                    .graphicsLayer {
                        translationY = arrowBounce - heroScrollProgress.value * 8.dp.toPx()
                    },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    text = "¡Reserva en 60s! ↘",
                    fontFamily = CaveatFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = SecondaryCoralDark,
                    modifier = Modifier.rotate(6f)
                )
                DoodleCurvedArrowDownRight(
                    color = SecondaryCoralDark,
                    modifier = Modifier
                        .size(26.dp)
                        .rotate(6f)
                )
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Primary CTA
                SketchCard(
                    backgroundColor = PrimaryTeal,
                    onClick = onBookClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("hero_book_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        DoodleCalendarIcon(color = OnPrimaryWhite, modifier = Modifier.size(20.dp))
                        Text(
                            text = "Reservar tu Cita Tranquila",
                            fontFamily = PatrickHandFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            letterSpacing = 0.4.sp,
                            color = OnPrimaryWhite
                        )
                    }
                }

                // Secondary Call CTA
                SketchCard(
                    backgroundColor = SurfaceContainerLowest,
                    onClick = onCallClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("hero_call_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        DoodlePhoneIcon(color = PrimaryTeal, modifier = Modifier.size(18.dp))
                        Text(
                            text = "Llamar o escribir: (305) 234-SMILE",
                            fontFamily = PatrickHandFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.5.sp,
                            color = OnSurfaceCharcoal
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(26.dp))

        // Trust Stats in Sketchy Cards with staggered scroll-driven graphicsLayer parallax
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .scrollDrivenParallaxAndFade(
                    maxParallaxDp = 14.dp,
                    minAlpha = 0.35f,
                    minScale = 0.93f,
                    indexParity = 2
                ),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Stat 1: 10k+
            SketchPill(
                backgroundColor = SurfaceContainerLowest,
                modifier = Modifier
                    .weight(1f)
                    .graphicsLayer {
                        translationY = -heroScrollProgress.value * 5.dp.toPx()
                    }
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp, horizontal = 6.dp)
                        .drawBehind {
                            drawOval(
                                color = PrimaryTeal.copy(alpha = 0.65f),
                                topLeft = Offset(size.width * 0.08f, size.height * 0.08f),
                                size = Size(size.width * 0.84f, size.height * 0.84f),
                                style = Stroke(
                                    width = 1.5.dp.toPx(),
                                    pathEffect = PathEffect.dashPathEffect(
                                        floatArrayOf(3.dp.toPx(), 3.dp.toPx()),
                                        0f
                                    )
                                )
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "10k+",
                            fontFamily = KalamFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 21.sp,
                            color = PrimaryTeal
                        )
                        Text(
                            text = "Sonrisas Felices",
                            fontFamily = PatrickHandFontFamily,
                            fontSize = 11.5.sp,
                            color = OnSurfaceVariantSlate,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            // Stat 2: 4.9 ★
            SketchPill(
                backgroundColor = SurfaceContainerLowest,
                modifier = Modifier
                    .weight(1f)
                    .graphicsLayer {
                        translationY = heroScrollProgress.value * 4.dp.toPx()
                    }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp, horizontal = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Text(
                            text = "4.9",
                            fontFamily = KalamFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 21.sp,
                            color = SecondaryCoralDark
                        )
                        Canvas(modifier = Modifier.size(16.dp)) {
                            val s = size.width / 24f
                            val star = Path().apply {
                                moveTo(12f * s, 2f * s)
                                lineTo(15.09f * s, 8.26f * s)
                                lineTo(22f * s, 9.27f * s)
                                lineTo(17f * s, 14.14f * s)
                                lineTo(18.18f * s, 21.02f * s)
                                lineTo(12f * s, 17.77f * s)
                                lineTo(5.82f * s, 21.02f * s)
                                lineTo(7f * s, 14.14f * s)
                                lineTo(2f * s, 9.27f * s)
                                lineTo(8.91f * s, 8.26f * s)
                                close()
                            }
                            drawPath(star, color = TertiaryFixedDimSunbeam)
                            drawPath(star, color = OnSurfaceCharcoal, style = Stroke(width = 1.8f * s))
                        }
                    }
                    Text(
                        text = "+500 Reseñas",
                        fontFamily = PatrickHandFontFamily,
                        fontSize = 11.5.sp,
                        color = OnSurfaceVariantSlate,
                        textAlign = TextAlign.Center
                    )
                }
            }

            // Stat 3: 100% ✓
            SketchPill(
                backgroundColor = SurfaceContainerLowest,
                modifier = Modifier
                    .weight(1f)
                    .graphicsLayer {
                        translationY = -heroScrollProgress.value * 7.dp.toPx()
                    }
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp, horizontal = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box {
                        Text(
                            text = "100%",
                            fontFamily = KalamFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 21.sp,
                            color = TertiaryGoldDark
                        )
                        Canvas(
                            modifier = Modifier
                                .size(14.dp)
                                .align(Alignment.TopEnd)
                                .offset(x = 12.dp, y = (-2).dp)
                        ) {
                            val s = size.width / 16f
                            val check = Path().apply {
                                moveTo(3f * s, 8.5f * s)
                                lineTo(6.5f * s, 12f * s)
                                lineTo(13f * s, 4f * s)
                            }
                            drawPath(
                                check,
                                color = PrimaryTeal,
                                style = Stroke(width = 2.5f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
                            )
                        }
                    }
                    Text(
                        text = "Sin Miedos",
                        fontFamily = PatrickHandFontFamily,
                        fontSize = 11.5.sp,
                        color = OnSurfaceVariantSlate,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Comfort Ticker Tags with Wobbly Borders & Doodle Icons
        FlowRow(
            modifier = Modifier
                .fillMaxWidth()
                .scrollDrivenParallaxAndFade(
                    maxParallaxDp = 10.dp,
                    minAlpha = 0.4f,
                    minScale = 0.95f,
                    indexParity = 3
                ),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SketchPill(
                backgroundColor = if (selectedAmenities.contains("Auriculares Bose + Netflix")) TagSoftTeal else SurfaceContainerLowest,
                onClick = { onToggleAmenity("Auriculares Bose + Netflix") }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    DoodleHeadphonesIcon(color = PrimaryTeal, modifier = Modifier.size(16.dp))
                    Text(
                        text = "Auriculares con cancelación de ruido y Netflix",
                        fontFamily = PatrickHandFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.5.sp,
                        color = OnSurfaceCharcoal
                    )
                }
            }

            SketchPill(
                backgroundColor = if (selectedAmenities.contains("Garantía cero juicios")) TagSoftTeal else SurfaceContainerLowest,
                onClick = { onToggleAmenity("Garantía cero juicios") }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    DoodleSmileFaceIcon(color = SecondaryCoralDark, modifier = Modifier.size(16.dp))
                    Text(
                        text = "Garantía cero juicios",
                        fontFamily = PatrickHandFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.5.sp,
                        color = OnSurfaceCharcoal
                    )
                }
            }

            SketchPill(
                backgroundColor = if (selectedAmenities.contains("Urgencias el mismo día")) TagSoftTeal else SurfaceContainerLowest,
                onClick = { onToggleAmenity("Urgencias el mismo día") }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    DoodleClockIcon(color = TertiaryGoldDark, modifier = Modifier.size(16.dp))
                    Text(
                        text = "Urgencias el mismo día",
                        fontFamily = PatrickHandFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.5.sp,
                        color = OnSurfaceCharcoal
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Horizontal Scrollable Bar of Comfort Menu Perks with horizontalScrollDrivenEffect
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("hero_comfort_horizontal_scroll"),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 2.dp)
        ) {
            items(comfortAmenities, key = { it.id }) { amenity ->
                val isSelected = selectedAmenities.contains(amenity.title)
                SketchPill(
                    backgroundColor = if (isSelected) PrimaryFixedDimCyan.copy(alpha = 0.45f) else SurfaceContainerLowest,
                    onClick = { onToggleAmenity(amenity.title) },
                    modifier = Modifier.horizontalScrollDrivenEffect()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = if (isSelected) "✓" else "✦",
                            fontFamily = KalamFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = PrimaryTeal
                        )
                        Column {
                            Text(
                                text = amenity.title,
                                fontFamily = PatrickHandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = OnSurfaceCharcoal
                            )
                            Text(
                                text = "${amenity.subtitle} • ${amenity.tag}",
                                fontFamily = PatrickHandFontFamily,
                                fontSize = 10.5.sp,
                                color = OnSurfaceVariantSlate
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun HeadlineWithDoodles(scrollProgress: Float = 0f) {
    Column(modifier = Modifier.fillMaxWidth()) {
        FlowRow(
            verticalArrangement = Arrangement.spacedBy(2.dp),
            horizontalArrangement = Arrangement.Start
        ) {
            Text(
                text = "Odontología con ",
                fontFamily = KalamFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 29.sp,
                lineHeight = 36.sp,
                color = OnSurfaceCharcoal
            )

            // "manos suaves" with cyan highlighter swash & coral squiggly underline
            Box(
                modifier = Modifier
                    .padding(horizontal = 2.dp)
                    .graphicsLayer {
                        translationX = -scrollProgress * 4.dp.toPx()
                    }
            ) {
                Canvas(
                    modifier = Modifier
                        .matchParentSize()
                        .padding(vertical = 3.dp)
                ) {
                    val swash = Path().apply {
                        moveTo(0f, size.height * 0.2f)
                        cubicTo(
                            size.width * 0.2f, 0f,
                            size.width * 0.8f, size.height * 0.1f,
                            size.width, size.height * 0.25f
                        )
                        lineTo(size.width * 0.96f, size.height * 0.92f)
                        cubicTo(
                            size.width * 0.75f, size.height * 0.88f,
                            size.width * 0.2f, size.height * 0.96f,
                            0f, size.height * 0.8f
                        )
                        close()
                    }
                    drawPath(swash, color = PrimaryFixedDimCyan.copy(alpha = 0.42f))
                }

                Text(
                    text = "manos suaves",
                    fontFamily = KalamFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 29.sp,
                    lineHeight = 36.sp,
                    color = PrimaryTeal,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )

                // Coral squiggly doodle underline
                Canvas(
                    modifier = Modifier
                        .matchParentSize()
                ) {
                    val y = size.height - 2.dp.toPx()
                    val squiggle = Path().apply {
                        moveTo(2f, y)
                        cubicTo(
                            size.width * 0.25f, y - 4.dp.toPx(),
                            size.width * 0.5f, y + 4.dp.toPx(),
                            size.width * 0.75f, y - 2.dp.toPx()
                        )
                        quadraticTo(size.width * 0.9f, y + 2.dp.toPx(), size.width - 2f, y - 1.dp.toPx())
                    }
                    drawPath(
                        squiggle,
                        color = SecondaryContainerCoral,
                        style = Stroke(width = 3.2.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }

            Text(
                text = " y ",
                fontFamily = KalamFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 29.sp,
                lineHeight = 36.sp,
                color = OnSurfaceCharcoal
            )

            // "buena vibra." with yellow highlighter swash and yellow star sparkle
            Box(
                modifier = Modifier.graphicsLayer {
                    translationX = scrollProgress * 5.dp.toPx()
                }
            ) {
                Canvas(
                    modifier = Modifier.matchParentSize()
                ) {
                    val y = size.height - 6.dp.toPx()
                    val path = Path().apply {
                        moveTo(2f, y)
                        quadraticTo(size.width * 0.5f, y - 4.dp.toPx(), size.width - 2f, y + 1.dp.toPx())
                    }
                    drawPath(
                        path,
                        color = TertiaryFixedGold.copy(alpha = 0.65f),
                        style = Stroke(width = 7.dp.toPx(), cap = StrokeCap.Round)
                    )
                }

                Text(
                    text = "buena vibra.",
                    fontFamily = KalamFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 29.sp,
                    lineHeight = 36.sp,
                    color = OnSurfaceCharcoal
                )

                DoodleStarSparkleYellow(
                    modifier = Modifier
                        .size(26.dp)
                        .align(Alignment.TopEnd)
                        .offset(x = 18.dp, y = (-8).dp)
                        .graphicsLayer {
                            rotationZ = -scrollProgress * 28f
                            translationY = -scrollProgress * 10.dp.toPx()
                        }
                )
            }
        }
    }
}

@Composable
fun ComfortScaleQuizSection(
    selectedMood: ComfortMood,
    selectedAmenities: Set<String>,
    onSelectMood: (ComfortMood) -> Unit,
    onToggleAmenity: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val (quizScrollProgress, quizTrackMod) = rememberScrollParallaxProgress()
    Box(
        modifier = modifier
            .fillMaxWidth()
            .then(quizTrackMod)
            .scrollDrivenParallaxAndFade(
                maxParallaxDp = 18.dp,
                minAlpha = 0.3f,
                minScale = 0.92f,
                maxTiltDegrees = 1.4f,
                indexParity = 1
            )
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        SketchCard(
            backgroundColor = SurfaceContainerLow,
            shadowColor = PrimaryTeal,
            wobbleSeed = 2,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                // Sketchy star in top-right corner with scroll-driven rotation & parallax
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .align(Alignment.TopEnd)
                        .offset(x = 10.dp, y = (-10).dp)
                        .graphicsLayer {
                            val p = quizScrollProgress.value
                            rotationZ = -12f + p * 42f
                            translationY = -p * 12.dp.toPx()
                        }
                        .drawBehind {
                            drawCircle(
                                color = OnSurfaceCharcoal,
                                radius = size.minDimension / 2f,
                                center = center + Offset(2.dp.toPx(), 2.dp.toPx())
                            )
                            drawCircle(
                                color = SecondaryFixedPeach.copy(alpha = 0.85f),
                                radius = size.minDimension / 2f
                            )
                            drawCircle(
                                color = OnSurfaceCharcoal,
                                radius = size.minDimension / 2f,
                                style = Stroke(width = 2.dp.toPx())
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.size(22.dp)) {
                        val s = size.width / 24f
                        val st = 2f * s
                        drawLine(SecondaryCoralDark, Offset(12f * s, 3f * s), Offset(12f * s, 21f * s), strokeWidth = st, cap = StrokeCap.Round)
                        drawLine(SecondaryCoralDark, Offset(3f * s, 12f * s), Offset(21f * s, 12f * s), strokeWidth = st, cap = StrokeCap.Round)
                        drawLine(SecondaryCoralDark, Offset(6.3f * s, 6.3f * s), Offset(17.7f * s, 17.7f * s), strokeWidth = st, cap = StrokeCap.Round)
                        drawLine(SecondaryCoralDark, Offset(6.3f * s, 17.7f * s), Offset(17.7f * s, 6.3f * s), strokeWidth = st, cap = StrokeCap.Round)
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "ESCALA DE CONFORT SUAVE",
                            fontFamily = PatrickHandFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.5.sp,
                            letterSpacing = 0.6.sp,
                            color = PrimaryTeal
                        )
                        Canvas(modifier = Modifier.size(width = 24.dp, height = 6.dp)) {
                            val path = Path().apply {
                                moveTo(1f, size.height * 0.5f)
                                quadraticTo(size.width * 0.25f, 0f, size.width * 0.5f, size.height * 0.5f)
                                quadraticTo(size.width * 0.75f, size.height, size.width - 1f, size.height * 0.5f)
                            }
                            drawPath(
                                path,
                                color = SecondaryContainerCoral,
                                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "¿Cómo te sientes respecto al dentista?",
                        fontFamily = KalamFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 19.sp,
                        color = OnSurfaceCharcoal
                    )

                    Text(
                        text = "Elige una opción y adaptaremos tu menú de atención al instante:",
                        fontFamily = PatrickHandFontFamily,
                        fontSize = 13.5.sp,
                        color = OnSurfaceVariantSlate
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // 3 Mood Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ComfortMood.entries.forEachIndexed { idx, mood ->
                            val isSelected = selectedMood == mood
                            val itemScale by animateFloatAsState(
                                targetValue = if (isSelected) 1.04f else 1f,
                                animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                                label = "moodScale"
                            )
                            SketchPill(
                                backgroundColor = if (isSelected) PrimaryFixedDimCyan else SurfaceContainerLowest,
                                onClick = { onSelectMood(mood) },
                                modifier = Modifier
                                    .weight(1f)
                                    .graphicsLayer {
                                        scaleX = itemScale
                                        scaleY = itemScale
                                        val stagger = (idx - 1) * 4.dp.toPx()
                                        translationY = quizScrollProgress.value * stagger
                                    }
                                    .testTag("mood_button_${mood.id}")
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 10.dp, horizontal = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    DoodleMoodFace(mood = mood, modifier = Modifier.size(34.dp))
                                    Text(
                                        text = mood.label,
                                        fontFamily = PatrickHandFontFamily,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 12.sp,
                                        lineHeight = 14.sp,
                                        color = if (isSelected) OnPrimaryFixedDark else OnSurfaceCharcoal,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Dynamic Reassurance Message Card
                    AnimatedContent(
                        targetState = selectedMood,
                        transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(180)) },
                        label = "comfortMessageAnim"
                    ) { mood ->
                        SketchCard(
                            backgroundColor = SurfaceContainerLowest,
                            modifier = Modifier
                                .fillMaxWidth()
                                .graphicsLayer {
                                    translationY = -quizScrollProgress.value * 5.dp.toPx()
                                }
                                .testTag("comfort_message_box")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.Top,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                DoodleComfortMessageIcon(
                                    mood = mood,
                                    modifier = Modifier
                                        .size(24.dp)
                                        .padding(top = 2.dp)
                                )
                                Text(
                                    text = buildAnnotatedString {
                                        withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                                            append("${mood.boldIntro} ")
                                        }
                                        append(mood.message)
                                    },
                                    fontFamily = PatrickHandFontFamily,
                                    fontSize = 14.sp,
                                    lineHeight = 19.sp,
                                    color = OnSurfaceCharcoal
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Horizontal Scrollable Personalized Comfort Menu Pills with horizontalScrollDrivenEffect
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(selectedMood.recommendedPerks) { perk ->
                            val isAdded = selectedAmenities.contains(perk)
                            SketchPill(
                                backgroundColor = if (isAdded) TagSoftTeal else SurfaceContainerLowest,
                                onClick = { onToggleAmenity(perk) },
                                modifier = Modifier.horizontalScrollDrivenEffect()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = if (isAdded) "✓ Incluido:" else "+ Añadir:",
                                        fontFamily = PatrickHandFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.5.sp,
                                        color = PrimaryTeal
                                    )
                                    Text(
                                        text = perk,
                                        fontFamily = PatrickHandFontFamily,
                                        fontSize = 12.sp,
                                        color = OnSurfaceCharcoal
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ServicesHeaderAndFilters(
    services: List<DentalService>,
    selectedCategory: String,
    onSelectCategory: (String) -> Unit,
    onServiceDetailsClick: (DentalService) -> Unit,
    onSeeAllClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val categories = listOf(
        "Todos",
        "Rutina y Prevención",
        "Ortodoncia",
        "Brillo y Resplandor",
        "Alivio Inmediato"
    )
    val (headerProgress, headerTrackMod) = rememberScrollParallaxProgress()

    Column(
        modifier = modifier
            .fillMaxWidth()
            .then(headerTrackMod)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        // Section Header with scroll-driven parallax & fade
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .graphicsLayer {
                    val p = headerProgress.value
                    translationY = p * 8.dp.toPx()
                    alpha = (1f - abs(p) * 0.35f).coerceIn(0.35f, 1f)
                },
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "MENÚ DE CUIDADOS",
                        fontFamily = PatrickHandFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 0.6.sp,
                        color = SecondaryCoralDark
                    )
                    Canvas(modifier = Modifier.size(width = 20.dp, height = 8.dp)) {
                        val path = Path().apply {
                            moveTo(1f, size.height * 0.5f)
                            cubicTo(
                                size.width * 0.25f, size.height * 0.2f,
                                size.width * 0.6f, size.height * 0.9f,
                                size.width - 1f, size.height * 0.5f
                            )
                        }
                        drawPath(
                            path,
                            color = SecondaryCoralDark,
                            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }
                }

                Box {
                    Text(
                        text = "Servicios Suaves a tu Medida",
                        fontFamily = KalamFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 21.sp,
                        color = OnSurfaceCharcoal
                    )
                }
                Canvas(
                    modifier = Modifier
                        .width(240.dp)
                        .height(6.dp)
                ) {
                    val path = Path().apply {
                        moveTo(2f, 3.dp.toPx())
                        quadraticTo(size.width * 0.125f, 1.dp.toPx(), size.width * 0.25f, 3.dp.toPx())
                        quadraticTo(size.width * 0.375f, 5.dp.toPx(), size.width * 0.5f, 3.dp.toPx())
                        quadraticTo(size.width * 0.625f, 1.dp.toPx(), size.width * 0.75f, 3.dp.toPx())
                        quadraticTo(size.width * 0.875f, 5.dp.toPx(), size.width - 2f, 3.dp.toPx())
                    }
                    drawPath(
                        path,
                        color = PrimaryTeal.copy(alpha = 0.4f),
                        style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }

            Row(
                modifier = Modifier
                    .clickable(onClick = onSeeAllClick)
                    .padding(bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text(
                    text = "Ver todos",
                    fontFamily = PatrickHandFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = PrimaryTeal
                )
                Text(
                    text = "→",
                    fontFamily = KalamFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = PrimaryTeal
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Horizontal Scrollable Category Filter Pills with horizontalScrollDrivenEffect
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("services_category_scroll"),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(categories) { category ->
                val isSelected = selectedCategory == category
                SketchPill(
                    backgroundColor = if (isSelected) PrimaryTeal else SurfaceContainerLowest,
                    onClick = { onSelectCategory(category) },
                    modifier = Modifier.horizontalScrollDrivenEffect()
                ) {
                    Text(
                        text = category,
                        fontFamily = PatrickHandFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.5.sp,
                        color = if (isSelected) OnPrimaryWhite else OnSurfaceCharcoal,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Interactive Horizontal Peek Strip of Quick-Compare Service Cards ("scrolls interactivos e intuitivos")
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("services_quick_compare_scroll"),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            itemsIndexed(services, key = { _, s -> "quick_${s.id}" }) { idx, service ->
                val isHighlighted = selectedCategory == service.categoryTag
                SketchPill(
                    backgroundColor = if (isHighlighted) service.tagBgColor else SurfaceContainerLow,
                    onClick = { onServiceDetailsClick(service) },
                    modifier = Modifier.horizontalScrollDrivenEffect(
                        maxParallaxDp = 14.dp,
                        minAlpha = 0.5f,
                        minScale = 0.92f
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        DoodleServiceCardIcon(
                            iconType = service.iconType,
                            modifier = Modifier.size(18.dp)
                        )
                        Column {
                            Text(
                                text = "${idx + 1}. ${service.categoryTag}",
                                fontFamily = PatrickHandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp,
                                color = service.tagTextColor
                            )
                            Text(
                                text = "${service.pricePrefix} ${service.priceMain}${service.priceSuffix} • ${service.durationNote}",
                                fontFamily = PatrickHandFontFamily,
                                fontSize = 11.sp,
                                color = OnSurfaceVariantSlate
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Individual Service Box with multi-layered Modifier.graphicsLayer scroll-driven
 * parallax, fade, 3D tilt, and internal horizontal interactive step/comfort scroll.
 */
@Composable
fun ServiceSketchCard(
    service: DentalService,
    wobbleSeed: Int,
    onDetailsClick: () -> Unit,
    onUrgentCallClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "urgentPulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(750),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    // Track this specific service card's position in viewport to drive internal multi-layer parallax
    val (cardScrollProgress, cardTrackMod) = rememberScrollParallaxProgress()

    Box(
        modifier = modifier
            .fillMaxWidth()
            .then(cardTrackMod)
            .scrollDrivenParallaxAndFade(
                maxParallaxDp = 22.dp,
                minAlpha = 0.22f,
                minScale = 0.90f,
                maxTiltDegrees = 2.0f,
                maxRotationX = 6.5f,
                indexParity = wobbleSeed
            )
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        SketchCard(
            backgroundColor = SurfaceContainerLowest,
            shadowColor = service.shadowColor,
            wobbleSeed = wobbleSeed,
            onClick = onDetailsClick,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("service_card_${service.id}")
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Top right hand-sketched doodle icon with strong counter-parallax & scroll-driven rotation
                DoodleServiceCardIcon(
                    iconType = service.iconType,
                    modifier = Modifier
                        .size(30.dp)
                        .align(Alignment.TopEnd)
                        .graphicsLayer {
                            val p = cardScrollProgress.value
                            translationY = -p * 18.dp.toPx()
                            translationX = p * 8.dp.toPx()
                            rotationZ = p * 26f
                            val iconScale = (1f + (1f - abs(p).coerceIn(0f, 1f)) * 0.14f)
                            scaleX = iconScale
                            scaleY = iconScale
                        }
                )

                Column(modifier = Modifier.fillMaxWidth()) {
                    // Category tag + duration with subtle horizontal parallax shift
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .padding(end = 34.dp)
                            .graphicsLayer {
                                val p = cardScrollProgress.value
                                translationX = -p * 7.dp.toPx()
                            }
                    ) {
                        SketchPill(
                            backgroundColor = service.tagBgColor,
                            shadowOffset = 1.5.dp
                        ) {
                            Text(
                                text = service.categoryTag,
                                fontFamily = PatrickHandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp,
                                color = service.tagTextColor,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                            )
                        }
                        Text(
                            text = service.durationNote,
                            fontFamily = PatrickHandFontFamily,
                            fontSize = 12.sp,
                            color = OnSurfaceVariantSlate
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = service.title,
                        fontFamily = KalamFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.5.sp,
                        lineHeight = 23.sp,
                        color = OnSurfaceCharcoal,
                        modifier = Modifier.graphicsLayer {
                            val p = cardScrollProgress.value
                            translationY = -p * 4.dp.toPx()
                        }
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = service.description,
                        fontFamily = PatrickHandFontFamily,
                        fontSize = 14.sp,
                        lineHeight = 19.sp,
                        color = OnSurfaceVariantSlate,
                        modifier = Modifier.graphicsLayer {
                            val p = cardScrollProgress.value
                            alpha = (1f - abs(p) * 0.25f).coerceIn(0.6f, 1f)
                        }
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Interactive Horizontal Scroll of Comfort & Protocol Steps inside every Service Card
                    // Each chip uses horizontalScrollDrivenEffect (Modifier.graphicsLayer parallax + fade)
                    LazyRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("service_inner_scroll_${service.id}"),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(vertical = 2.dp)
                    ) {
                        items(service.comfortIncluded) { item ->
                            Box(
                                modifier = Modifier
                                    .horizontalScrollDrivenEffect(
                                        maxParallaxDp = 10.dp,
                                        minAlpha = 0.5f,
                                        minScale = 0.9f
                                    )
                                    .background( service.tagBgColor.copy(alpha = 0.55f), CircleShape)
                                    .border(1.dp, OnSurfaceCharcoal.copy(alpha = 0.25f), CircleShape)
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "✦ $item",
                                    fontFamily = PatrickHandFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.5.sp,
                                    color = OnSurfaceCharcoal
                                )
                            }
                        }
                        itemsIndexed(service.steps) { stepIdx, stepText ->
                            Box(
                                modifier = Modifier
                                    .horizontalScrollDrivenEffect(
                                        maxParallaxDp = 10.dp,
                                        minAlpha = 0.5f,
                                        minScale = 0.9f
                                    )
                                    .background(SurfaceContainerLow, CircleShape)
                                    .border(1.dp, OnSurfaceCharcoal.copy(alpha = 0.2f), CircleShape)
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "Paso ${stepIdx + 1}: ${stepText.take(36)}…",
                                    fontFamily = PatrickHandFontFamily,
                                    fontSize = 11.5.sp,
                                    color = OnSurfaceVariantSlate
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    DashedLineSeparator()
                    Spacer(modifier = Modifier.height(10.dp))

                    // Bottom Price & Action Row with scroll-driven parallax
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .graphicsLayer {
                                val p = cardScrollProgress.value
                                translationY = p * 5.dp.toPx()
                            },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        if (service.isUrgent) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(ErrorRed.copy(alpha = pulseAlpha), CircleShape)
                                )
                                Text(
                                    text = service.pricePrefix,
                                    fontFamily = PatrickHandFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = ErrorRed
                                )
                            }

                            SketchPill(
                                backgroundColor = SecondaryCoralDark,
                                onClick = onUrgentCallClick,
                                modifier = Modifier.height(42.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(
                                        text = "Llamar Urgencias",
                                        fontFamily = PatrickHandFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = OnSecondaryWhite
                                    )
                                    DoodlePhoneIcon(color = OnSecondaryWhite, modifier = Modifier.size(14.dp))
                                }
                            }
                        } else {
                            Row(
                                verticalAlignment = Alignment.Bottom,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = service.pricePrefix,
                                    fontFamily = PatrickHandFontFamily,
                                    fontSize = 12.5.sp,
                                    color = OnSurfaceVariantSlate
                                )
                                Box {
                                    Text(
                                        text = buildAnnotatedString {
                                            append(service.priceMain)
                                            if (service.priceSuffix == "/mes") {
                                                withStyle(SpanStyle(fontSize = 12.sp, fontWeight = FontWeight.Normal)) {
                                                    append("/mes")
                                                }
                                            }
                                        },
                                        fontFamily = KalamFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 19.sp,
                                        color = service.tagTextColor
                                    )
                                    Canvas(
                                        modifier = Modifier
                                            .width(34.dp)
                                            .height(4.dp)
                                            .align(Alignment.BottomStart)
                                    ) {
                                        val path = Path().apply {
                                            moveTo(1f, 2.dp.toPx())
                                            cubicTo(
                                                size.width * 0.3f, 3.5.dp.toPx(),
                                                size.width * 0.7f, 0.5.dp.toPx(),
                                                size.width - 1f, 2.dp.toPx()
                                            )
                                        }
                                        drawPath(
                                            path,
                                            color = service.tagTextColor.copy(alpha = 0.45f),
                                            style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round)
                                        )
                                    }
                                }
                                if (service.priceSuffix.isNotEmpty() && service.priceSuffix != "/mes") {
                                    Text(
                                        text = service.priceSuffix,
                                        fontFamily = PatrickHandFontFamily,
                                        fontSize = 13.sp,
                                        color = OnSurfaceVariantSlate
                                    )
                                }
                                if (service.strikethroughPrice != null) {
                                    Text(
                                        text = service.strikethroughPrice,
                                        fontFamily = PatrickHandFontFamily,
                                        fontSize = 13.5.sp,
                                        color = OutlineSlate,
                                        textDecoration = TextDecoration.LineThrough
                                    )
                                }
                            }

                            SketchPill(
                                backgroundColor = SurfaceContainerHigh,
                                onClick = onDetailsClick,
                                modifier = Modifier.height(42.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = "Detalles",
                                        fontFamily = PatrickHandFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = OnSurfaceCharcoal
                                    )
                                    Text(
                                        text = "›",
                                        fontFamily = KalamFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 17.sp,
                                        color = OnSurfaceCharcoal
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
