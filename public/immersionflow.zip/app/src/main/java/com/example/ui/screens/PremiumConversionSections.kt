package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.DashedLineSeparator
import com.example.ui.components.DoodleCalendarIcon
import com.example.ui.components.DoodleSparkle
import com.example.ui.components.DoodleStarSparkleYellow
import com.example.ui.components.DoodleVerifiedBadge
import com.example.ui.components.SketchCard
import com.example.ui.components.SketchPill
import com.example.ui.components.SketchTape
import com.example.ui.components.horizontalScrollDrivenEffect
import com.example.ui.components.rememberScrollParallaxProgress
import com.example.ui.components.scrollDrivenParallaxAndFade
import com.example.ui.theme.CaveatFontFamily
import com.example.ui.theme.KalamFontFamily
import com.example.ui.theme.LiveStatusMint
import com.example.ui.theme.OnPrimaryWhite
import com.example.ui.theme.OnSecondaryContainerBrown
import com.example.ui.theme.OnSurfaceCharcoal
import com.example.ui.theme.OnSurfaceVariantSlate
import com.example.ui.theme.OnTertiaryFixedDark
import com.example.ui.theme.OutlineSlate
import com.example.ui.theme.PatrickHandFontFamily
import com.example.ui.theme.PostItWarmYellow
import com.example.ui.theme.PrimaryFixedCyan
import com.example.ui.theme.PrimaryFixedDimCyan
import com.example.ui.theme.PrimaryTeal
import com.example.ui.theme.QuotePaperCream
import com.example.ui.theme.SecondaryContainerCoral
import com.example.ui.theme.SecondaryCoralDark
import com.example.ui.theme.SurfaceContainerHigh
import com.example.ui.theme.SurfaceContainerLow
import com.example.ui.theme.SurfaceContainerLowest
import com.example.ui.theme.TagSoftCoral
import com.example.ui.theme.TagSoftGold
import com.example.ui.theme.TagSoftTeal
import com.example.ui.theme.TertiaryFixedDimSunbeam
import com.example.ui.theme.TertiaryFixedGold
import com.example.ui.theme.TertiaryGoldDark
import kotlin.math.roundToInt

private data class SmileCaseStudy(
    val title: String,
    val badge: String,
    val duration: String,
    val monthlyCost: String,
    val patientQuote: String,
    val beforeNote: String,
    val afterNote: String
)

/**
 * High-converting Interactive Before & After Smile Transformation Slider
 * with touch-drag comparison and horizontal case-study scroll.
 */
@Composable
fun SmileTransformationSection(
    onBookCaseClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cases = remember {
        listOf(
            SmileCaseStudy(
                title = "Alineadores Invisibles 3D",
                badge = "Sin moldes de pasta",
                duration = "5 meses",
                monthlyCost = "$85/mes",
                patientQuote = "«Nadie notó que los llevaba puestos y vi mi resultado en 3D desde el día 1.»",
                beforeNote = "Antes: Apiñamiento leve y espacio central",
                afterNote = "Después: Arco alineado y simétrico"
            ),
            SmileCaseStudy(
                title = "Aclaramiento Láser + 4 Carillas",
                badge = "0% Sensibilidad",
                duration = "2 sesiones",
                monthlyCost = "$199 esp.",
                patientQuote = "«Tenía pánico al dolor por sensibilidad. No sentí ni un cosquilleo.»",
                beforeNote = "Antes: Desgaste y manchas por café",
                afterNote = "Después: Blanco natural orgánico (+5 tonos)"
            ),
            SmileCaseStudy(
                title = "Restauración Biomimética Express",
                badge = "En 45 minutos",
                duration = "1 visita",
                monthlyCost = "Cubierto 80%",
                patientQuote = "«Llegué con un diente astillado de urgencia y salí sonriendo el mismo día.»",
                beforeNote = "Antes: Fractura en borde incisivo",
                afterNote = "Después: Unión invisible de porcelana"
            )
        )
    }

    var selectedCaseIdx by remember { mutableIntStateOf(0) }
    var sliderFraction by remember { mutableFloatStateOf(0.52f) }
    val activeCase = cases[selectedCaseIdx]
    val (scrollProgress, trackMod) = rememberScrollParallaxProgress()

    Box(
        modifier = modifier
            .fillMaxWidth()
            .then(trackMod)
            .scrollDrivenParallaxAndFade(
                maxParallaxDp = 20.dp,
                minAlpha = 0.25f,
                minScale = 0.91f,
                maxTiltDegrees = 1.6f,
                indexParity = 0
            )
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        SketchCard(
            backgroundColor = SurfaceContainerLowest,
            shadowColor = PrimaryTeal,
            wobbleSeed = 5,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("smile_transformation_card")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "RESULTADOS REALES INTERACTIVOS",
                        fontFamily = PatrickHandFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 0.6.sp,
                        color = PrimaryTeal
                    )
                    SketchPill(
                        backgroundColor = TagSoftGold,
                        rotationDegrees = 2f
                    ) {
                        Text(
                            text = "↔ Desliza el comparador",
                            fontFamily = CaveatFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TertiaryGoldDark,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Transformaciones Suaves Antes y Después",
                    fontFamily = KalamFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = OnSurfaceCharcoal
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Horizontal scrollable Case Study Selector with horizontalScrollDrivenEffect
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(cases) { idx, item ->
                        val isSelected = idx == selectedCaseIdx
                        SketchPill(
                            backgroundColor = if (isSelected) PrimaryTeal else SurfaceContainerLow,
                            onClick = { selectedCaseIdx = idx },
                            modifier = Modifier.horizontalScrollDrivenEffect()
                        ) {
                            Text(
                                text = "${idx + 1}. ${item.title}",
                                fontFamily = PatrickHandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.5.sp,
                                color = if (isSelected) OnPrimaryWhite else OnSurfaceCharcoal,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Interactive Before / After Drag Canvas
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(172.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .border(2.dp, OnSurfaceCharcoal, RoundedCornerShape(14.dp))
                        .pointerInput(Unit) {
                            detectHorizontalDragGestures { change, _ ->
                                change.consume()
                                val newFraction = (change.position.x / size.width.toFloat()).coerceIn(0.12f, 0.88f)
                                sliderFraction = newFraction
                            }
                        }
                        .testTag("before_after_slider_box")
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        val splitX = w * sliderFraction

                        // Background AFTER (Full width warm mint/radiant smile illustration)
                        drawRect(color = Color(0xFFE9F8F9))
                        drawSmileArchIllustration(
                            width = w,
                            height = h,
                            isAfter = true,
                            caseIndex = selectedCaseIdx
                        )

                        // Clipped BEFORE on the left side
                        clipRect(left = 0f, top = 0f, right = splitX, bottom = h) {
                            drawRect(color = PostItWarmYellow)
                            drawSmileArchIllustration(
                                width = w,
                                height = h,
                                isAfter = false,
                                caseIndex = selectedCaseIdx
                            )
                        }

                        // Vertical divider line
                        drawLine(
                            color = OnSurfaceCharcoal,
                            start = Offset(splitX, 0f),
                            end = Offset(splitX, h),
                            strokeWidth = 3.dp.toPx()
                        )

                        // Center handle circle
                        val handleCenter = Offset(splitX, h * 0.5f)
                        drawCircle(
                            color = OnSurfaceCharcoal,
                            radius = 19.dp.toPx(),
                            center = handleCenter + Offset(2.dp.toPx(), 2.dp.toPx())
                        )
                        drawCircle(
                            color = SecondaryContainerCoral,
                            radius = 19.dp.toPx(),
                            center = handleCenter
                        )
                        drawCircle(
                            color = OnSurfaceCharcoal,
                            radius = 19.dp.toPx(),
                            center = handleCenter,
                            style = Stroke(width = 2.dp.toPx())
                        )
                    }

                    // Top-left "ANTES" pill
                    SketchPill(
                        backgroundColor = SurfaceContainerLowest.copy(alpha = 0.94f),
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "ANTES",
                            fontFamily = PatrickHandFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = SecondaryCoralDark,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    // Top-right "DESPUÉS ★" pill
                    SketchPill(
                        backgroundColor = PrimaryTeal,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "DESPUÉS ★",
                            fontFamily = PatrickHandFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = OnPrimaryWhite,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    // Bottom labels
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .background(OnSurfaceCharcoal.copy(alpha = 0.72f))
                            .padding(horizontal = 12.dp, vertical = 5.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = activeCase.beforeNote,
                            fontFamily = PatrickHandFontFamily,
                            fontSize = 11.sp,
                            color = Color.White
                        )
                        Text(
                            text = activeCase.afterNote,
                            fontFamily = PatrickHandFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = PrimaryFixedCyan
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Metrics + Quote Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .graphicsLayer {
                            translationY = -scrollProgress.value * 4.dp.toPx()
                        },
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SketchPill(backgroundColor = TagSoftTeal) {
                        Text(
                            text = "⏱ ${activeCase.duration}",
                            fontFamily = PatrickHandFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = PrimaryTeal,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                    SketchPill(backgroundColor = TagSoftCoral) {
                        Text(
                            text = "✦ ${activeCase.badge}",
                            fontFamily = PatrickHandFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = SecondaryCoralDark,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                    SketchPill(backgroundColor = PostItWarmYellow) {
                        Text(
                            text = activeCase.monthlyCost,
                            fontFamily = KalamFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = TertiaryGoldDark,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = activeCase.patientQuote,
                    fontFamily = PatrickHandFontFamily,
                    fontSize = 13.5.sp,
                    color = OnSurfaceVariantSlate
                )

                Spacer(modifier = Modifier.height(10.dp))

                SketchCard(
                    backgroundColor = PrimaryTeal,
                    onClick = onBookCaseClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Quiero Previsualizar mi Sonrisa 3D Gratis →",
                        fontFamily = PatrickHandFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = OnPrimaryWhite
                    )
                }
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawSmileArchIllustration(
    width: Float,
    height: Float,
    isAfter: Boolean,
    caseIndex: Int
) {
    val cx = width * 0.5f
    val cy = height * 0.46f
    val archW = width * 0.64f
    val archH = height * 0.42f

    // Soft gum / lip contour
    val lipPath = Path().apply {
        moveTo(cx - archW * 0.55f, cy)
        quadraticTo(cx, cy - archH * 0.65f, cx + archW * 0.55f, cy)
        quadraticTo(cx, cy + archH * 0.95f, cx - archW * 0.55f, cy)
        close()
    }
    drawPath(
        path = lipPath,
        color = if (isAfter) SecondaryContainerCoral.copy(alpha = 0.25f) else SecondaryCoralDark.copy(alpha = 0.18f)
    )

    // Draw 6 stylized upper front teeth
    val toothCount = 6
    val totalTeethW = archW * 0.82f
    val startX = cx - totalTeethW / 2f
    val baseToothW = totalTeethW / toothCount

    for (i in 0 until toothCount) {
        val tx = startX + i * baseToothW
        val isCenter = i == 2 || i == 3
        val toothH = if (isCenter) archH * 0.56f else archH * 0.48f

        // Before imperfections vs After harmony
        val yJitter = if (!isAfter && caseIndex == 0) {
            if (i % 2 == 0) -4.dp.toPx() else 4.dp.toPx()
        } else 0f
        val gapX = if (!isAfter && caseIndex == 0 && i >= 3) 4.dp.toPx() else 0f

        val toothColor = when {
            isAfter -> Color.White
            caseIndex == 1 -> Color(0xFFF6E7C1) // Warm stained before whitening
            else -> Color(0xFFFAF5E8)
        }

        val rectTopLeft = Offset(tx + gapX + 2.dp.toPx(), cy - toothH * 0.45f + yJitter)
        val rectSize = Size(baseToothW - 4.dp.toPx(), toothH)

        drawRoundRect(
            color = toothColor,
            topLeft = rectTopLeft,
            size = rectSize,
            cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
        )
        drawRoundRect(
            color = OnSurfaceCharcoal,
            topLeft = rectTopLeft,
            size = rectSize,
            cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx()),
            style = Stroke(width = 1.8.dp.toPx())
        )

        // Chipped edge in Before for Case 2 (Emergency restoration)
        if (!isAfter && caseIndex == 2 && i == 2) {
            drawLine(
                color = SecondaryCoralDark,
                start = Offset(rectTopLeft.x + rectSize.width * 0.4f, rectTopLeft.y + rectSize.height),
                end = Offset(rectTopLeft.x + rectSize.width, rectTopLeft.y + rectSize.height * 0.72f),
                strokeWidth = 2.5.dp.toPx()
            )
        }
    }

    // Sparkles on the After side
    if (isAfter) {
        drawCircle(
            color = TertiaryFixedDimSunbeam,
            radius = 5.dp.toPx(),
            center = Offset(cx + archW * 0.36f, cy - archH * 0.25f)
        )
        drawCircle(
            color = PrimaryTeal,
            radius = 3.5.dp.toPx(),
            center = Offset(cx - archW * 0.34f, cy - archH * 0.2f)
        )
    }
}

/**
 * Interactive Insurance & Instant Savings Calculator Section ("para vender").
 */
@Composable
fun InsuranceAndSavingsSection(
    onVerifyInsuranceClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val providers = remember {
        listOf(
            Triple("Delta Dental", "100% Cubierto", "$0 en Limpieza y Examen"),
            Triple("MetLife", "100% Preventivo", "$0 en Limpieza + 80% en Urgencias"),
            Triple("Cigna / Aetna", "Red Preferente", "$0 en Visita Inicial + Rayos X 3D"),
            Triple("BlueCross", "100% Cubierto", "$0 en Limpieza + $500 Bono Alineadores"),
            Triple("Sin Seguro (Plan SmileCraft)", "Ahorra 40%", "$89 Todo Incluido + Caja Regalo")
        )
    }

    var selectedIdx by remember { mutableIntStateOf(0) }
    val selected = providers[selectedIdx]
    val (scrollProgress, trackMod) = rememberScrollParallaxProgress()

    Box(
        modifier = modifier
            .fillMaxWidth()
            .then(trackMod)
            .scrollDrivenParallaxAndFade(
                maxParallaxDp = 18.dp,
                minAlpha = 0.26f,
                minScale = 0.91f,
                indexParity = 1
            )
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        SketchCard(
            backgroundColor = QuotePaperCream,
            shadowColor = TertiaryGoldDark,
            wobbleSeed = 7,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("insurance_calculator_card")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    DoodleVerifiedBadge(modifier = Modifier.size(16.dp))
                    Text(
                        text = "TRANSPARENCIA 100% • CERO SORPRESAS",
                        fontFamily = PatrickHandFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 0.5.sp,
                        color = TertiaryGoldDark
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Calculadora de Seguro y Ahorro Instantáneo",
                    fontFamily = KalamFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = OnSurfaceCharcoal
                )

                Text(
                    text = "Selecciona tu cobertura deslizando horizontalmente para ver tu costo estimado hoy:",
                    fontFamily = PatrickHandFontFamily,
                    fontSize = 13.5.sp,
                    color = OnSurfaceVariantSlate
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Horizontal Scrollable Insurance Providers with horizontalScrollDrivenEffect
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(providers) { idx, (name, badge, _) ->
                        val isSelected = idx == selectedIdx
                        SketchPill(
                            backgroundColor = if (isSelected) PrimaryTeal else SurfaceContainerLowest,
                            onClick = { selectedIdx = idx },
                            modifier = Modifier.horizontalScrollDrivenEffect()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = if (isSelected) "✓ $name" else name,
                                    fontFamily = PatrickHandFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.5.sp,
                                    color = if (isSelected) OnPrimaryWhite else OnSurfaceCharcoal
                                )
                                Box(
                                    modifier = Modifier
                                        .background(
                                            if (isSelected) TertiaryFixedDimSunbeam else SurfaceContainerLow,
                                            CircleShape
                                        )
                                        .padding(horizontal = 6.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = badge,
                                        fontFamily = PatrickHandFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.5.sp,
                                        color = OnSurfaceCharcoal
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Live Estimate Output Box
                SketchCard(
                    backgroundColor = LiveStatusMint,
                    shadowOffsetX = 2.dp,
                    shadowOffsetY = 2.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .graphicsLayer {
                            translationY = -scrollProgress.value * 5.dp.toPx()
                        }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Con ${selected.first}:",
                                fontFamily = PatrickHandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = PrimaryTeal
                            )
                            Text(
                                text = selected.third,
                                fontFamily = KalamFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = OnSurfaceCharcoal
                            )
                            Text(
                                text = "+ Caja de regalo con cepillo eléctrico ($120 valor) GRATIS",
                                fontFamily = CaveatFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = SecondaryCoralDark
                            )
                        }

                        SketchPill(
                            backgroundColor = SecondaryContainerCoral,
                            onClick = onVerifyInsuranceClick
                        ) {
                            Text(
                                text = "Aplicar →",
                                fontFamily = PatrickHandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = OnSecondaryContainerBrown,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Interactive Sketchbook FAQ Accordion overcoming buyer anxiety & objections.
 */
@Composable
fun FaqAccordionSection(
    modifier: Modifier = Modifier
) {
    val faqs = remember {
        listOf(
            "¿De verdad no sentiré dolor durante mi limpieza o tratamiento?" to
                "100% garantizado. Usamos gel adormecedor natural sabor menta, agua tibia temperada, ultrasonido silencioso sin raspado metálico y anestesia computarizada sin aguja (The Wand).",
            "No he ido al dentista en más de 5 años y me da vergüenza, ¿qué hago?" to
                "¡Estás en el lugar correcto! Nuestra «Garantía Cero Juicios» es sagrada: nunca te regañaremos. Celebramos que hayas dado el primer paso hoy y avanzamos a tu propio ritmo.",
            "¿El menú de confort (Netflix, manta con peso, óxido) tiene costo extra?" to
                "¡Todo nuestro Menú de Confort es 100% gratuito! Desde auriculares Bose con cancelación de ruido y pantallas en el techo hasta almohadas térmicas y té de lavanda.",
            "¿Puedo cancelar o reprogramar si me siento nervioso el día de mi cita?" to
                "Por supuesto. Puedes reprogramar desde tu teléfono en 10 segundos sin cargos ocultos ni penalizaciones."
        )
    }

    var expandedIdx by remember { mutableIntStateOf(0) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .scrollDrivenParallaxAndFade(
                maxParallaxDp = 16.dp,
                minAlpha = 0.28f,
                minScale = 0.92f,
                indexParity = 0
            )
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = "RESPUESTAS CLARAS SIN MIEDO",
                fontFamily = PatrickHandFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                letterSpacing = 0.6.sp,
                color = PrimaryTeal
            )
            Text(
                text = "✎ toca cualquier pregunta",
                fontFamily = CaveatFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = SecondaryCoralDark
            )
        }

        Text(
            text = "Preguntas Frecuentes de Pacientes Nerviosos",
            fontFamily = KalamFontFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            color = OnSurfaceCharcoal
        )

        faqs.forEachIndexed { idx, (question, answer) ->
            val isExpanded = expandedIdx == idx
            SketchCard(
                backgroundColor = if (isExpanded) PostItWarmYellow else SurfaceContainerLowest,
                shadowColor = if (isExpanded) PrimaryTeal else OnSurfaceCharcoal,
                wobbleSeed = idx + 1,
                onClick = { expandedIdx = if (isExpanded) -1 else idx },
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = question,
                            fontFamily = KalamFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            lineHeight = 21.sp,
                            color = OnSurfaceCharcoal,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        SketchPill(
                            backgroundColor = if (isExpanded) PrimaryTeal else SurfaceContainerHigh,
                            shadowOffset = 1.dp
                        ) {
                            Text(
                                text = if (isExpanded) "−" else "+",
                                fontFamily = KalamFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = if (isExpanded) OnPrimaryWhite else OnSurfaceCharcoal,
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 2.dp)
                            )
                        }
                    }

                    AnimatedVisibility(
                        visible = isExpanded,
                        enter = expandVertically(spring(stiffness = Spring.StiffnessMediumLow)) + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Column {
                            Spacer(modifier = Modifier.height(8.dp))
                            DashedLineSeparator()
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = answer,
                                fontFamily = PatrickHandFontFamily,
                                fontSize = 14.5.sp,
                                lineHeight = 20.sp,
                                color = OnSurfaceVariantSlate
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Floating Sticky Conversion Bar that appears as the user scrolls through the page.
 */
@Composable
fun FloatingQuickConversionPill(
    visible: Boolean,
    onBookNowClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically(),
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            SketchCard(
                backgroundColor = PostItWarmYellow,
                shadowColor = OnSurfaceCharcoal,
                shadowOffsetX = 3.dp,
                shadowOffsetY = 3.5.dp,
                onClick = onBookNowClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("floating_conversion_bar")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .background(PrimaryTeal, CircleShape)
                            )
                            Text(
                                text = "⚡ 2 turnos tranquilos hoy + Cepillo Gratis",
                                fontFamily = PatrickHandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.5.sp,
                                color = OnSurfaceCharcoal
                            )
                        }
                        Text(
                            text = "Sin tarjeta de crédito • Reserva en 60s",
                            fontFamily = CaveatFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = SecondaryCoralDark
                        )
                    }

                    SketchPill(
                        backgroundColor = PrimaryTeal,
                        onClick = onBookNowClick
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            DoodleCalendarIcon(color = OnPrimaryWhite, modifier = Modifier.size(15.dp))
                            Text(
                                text = "Reservar Ya",
                                fontFamily = PatrickHandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = OnPrimaryWhite
                            )
                        }
                    }
                }
            }
        }
    }
}
