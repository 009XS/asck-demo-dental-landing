package com.example.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.OnSurfaceCharcoal
import com.example.ui.theme.PrimaryTeal
import com.example.ui.theme.SketchSurface
import com.example.ui.theme.SurfaceContainerLowest
import com.example.ui.theme.TapeAmber
import kotlin.math.abs

/**
 * Tracks a composable's normalized vertical position in the window:
 * -1f = top edge of screen, 0f = center of screen, +1f = bottom edge of screen.
 * Can be used to drive internal child parallax layers via Modifier.graphicsLayer.
 */
@Composable
fun rememberScrollParallaxProgress(): Pair<State<Float>, Modifier> {
    val progressState = remember { mutableFloatStateOf(0f) }
    val view = LocalView.current
    val modifier = Modifier.onGloballyPositioned { coordinates ->
        if (!coordinates.isAttached) return@onGloballyPositioned
        val viewportHeight = view.height.toFloat().coerceAtLeast(1f)
        val itemCenterY = coordinates.positionInWindow().y + coordinates.size.height / 2f
        val normalized = ((itemCenterY - viewportHeight / 2f) / (viewportHeight / 2f)).coerceIn(-1.3f, 1.3f)
        progressState.floatValue = normalized
    }
    return progressState to modifier
}

/**
 * Scroll-driven vertical parallax, fade, scale, and 3D sketchbook tilt effect using Modifier.graphicsLayer.
 * Smoothly animates items as they enter, pass through, and exit the vertical viewport.
 */
fun Modifier.scrollDrivenParallaxAndFade(
    maxParallaxDp: Dp = 18.dp,
    minAlpha: Float = 0.28f,
    minScale: Float = 0.92f,
    maxTiltDegrees: Float = 1.6f,
    maxRotationX: Float = 5f,
    indexParity: Int = 0
): Modifier = composed {
    val normalizedOffset = remember { mutableFloatStateOf(0f) }
    val view = LocalView.current
    val density = LocalDensity.current
    val maxParallaxPx = with(density) { maxParallaxDp.toPx() }
    val tiltDirection = if (indexParity % 2 == 0) 1f else -1f

    this
        .onGloballyPositioned { coordinates ->
            if (!coordinates.isAttached) return@onGloballyPositioned
            val viewportHeight = view.height.toFloat().coerceAtLeast(1f)
            val pos = coordinates.positionInWindow()
            val itemCenterY = pos.y + coordinates.size.height / 2f
            val rawNormalized = (itemCenterY - viewportHeight / 2f) / (viewportHeight * 0.52f)
            normalizedOffset.floatValue = rawNormalized.coerceIn(-1.25f, 1.25f)
        }
        .graphicsLayer {
            val offset = normalizedOffset.floatValue
            val absOffset = abs(offset).coerceIn(0f, 1.2f)
            // Keep center zone (0..0.35) crisp at 1f, then smoothly fade/scale toward edges
            val edgeProgress = ((absOffset - 0.25f) / 0.85f).coerceIn(0f, 1f)
            val smoothEdge = edgeProgress * edgeProgress * (3f - 2f * edgeProgress)

            alpha = 1f - smoothEdge * (1f - minAlpha)
            val scale = 1f - smoothEdge * (1f - minScale)
            scaleX = scale
            scaleY = scale

            // Parallax translation opposing or following scroll
            translationY = offset * maxParallaxPx
            // Subtle 3D sketchbook perspective tilt
            rotationX = -offset * maxRotationX * smoothEdge
            rotationZ = offset * maxTiltDegrees * tiltDirection * smoothEdge
            cameraDistance = 14f * density.density
        }
}

/**
 * Scroll-driven horizontal parallax, fade, and scale effect using Modifier.graphicsLayer
 * for items inside horizontal carousels (LazyRow / horizontalScroll).
 */
fun Modifier.horizontalScrollDrivenEffect(
    maxParallaxDp: Dp = 12.dp,
    minAlpha: Float = 0.45f,
    minScale: Float = 0.91f,
    maxRotationZ: Float = 2.2f
): Modifier = composed {
    val normalizedX = remember { mutableFloatStateOf(0f) }
    val view = LocalView.current
    val density = LocalDensity.current
    val maxParallaxPx = with(density) { maxParallaxDp.toPx() }

    this
        .onGloballyPositioned { coordinates ->
            if (!coordinates.isAttached) return@onGloballyPositioned
            val viewportWidth = view.width.toFloat().coerceAtLeast(1f)
            val itemCenterX = coordinates.positionInWindow().x + coordinates.size.width / 2f
            val rawNormalized = (itemCenterX - viewportWidth / 2f) / (viewportWidth * 0.55f)
            normalizedX.floatValue = rawNormalized.coerceIn(-1.3f, 1.3f)
        }
        .graphicsLayer {
            val offset = normalizedX.floatValue
            val absOffset = abs(offset).coerceIn(0f, 1.2f)
            val edgeProgress = ((absOffset - 0.2f) / 0.9f).coerceIn(0f, 1f)
            val smoothEdge = edgeProgress * edgeProgress * (3f - 2f * edgeProgress)

            alpha = 1f - smoothEdge * (1f - minAlpha)
            val scale = 1f - smoothEdge * (1f - minScale)
            scaleX = scale
            scaleY = scale
            translationX = -offset * maxParallaxPx * 0.5f
            rotationZ = offset * maxRotationZ * smoothEdge
        }
}

/**
 * Authentic notebook graph/sketchbook paper grid background with subtle parallax shift.
 */
fun Modifier.sketchbookPaperBackground(scrollOffsetPx: Float = 0f): Modifier = this.drawBehind {
    drawRect(color = SketchSurface)
    val gridStep = 22.dp.toPx()
    val lineColor = PrimaryTeal.copy(alpha = 0.045f)
    val strokeWidth = 1.dp.toPx()

    val parallaxY = -(scrollOffsetPx * 0.18f) % gridStep

    var x = 0f
    while (x <= size.width) {
        drawLine(
            color = lineColor,
            start = Offset(x, 0f),
            end = Offset(x, size.height),
            strokeWidth = strokeWidth
        )
        x += gridStep
    }

    var y = parallaxY
    if (y < 0f) y += gridStep
    while (y <= size.height) {
        drawLine(
            color = lineColor,
            start = Offset(0f, y),
            end = Offset(size.width, y),
            strokeWidth = strokeWidth
        )
        y += gridStep
    }
}

/**
 * Creates a slightly asymmetric hand-drawn rounded path for the sketchy border aesthetic.
 */
private fun buildWobblyRectPath(
    width: Float,
    height: Float,
    topLeftRadius: Float,
    topRightRadius: Float,
    bottomRightRadius: Float,
    bottomLeftRadius: Float,
    wobbleSeed: Int = 0
): Path {
    val path = Path()
    val w = width
    val h = height
    val wobble1 = if (wobbleSeed % 2 == 0) 1.4f else -1.4f
    val wobble2 = if (wobbleSeed % 3 == 0) -1.2f else 1.2f

    path.moveTo(topLeftRadius, 0f)
    // Top edge with subtle hand-drawn bow
    path.quadraticTo(w * 0.5f, wobble1, w - topRightRadius, 0f)
    path.quadraticTo(w, 0f, w, topRightRadius)
    // Right edge
    path.quadraticTo(w - wobble2, h * 0.5f, w, h - bottomRightRadius)
    path.quadraticTo(w, h, w - bottomRightRadius, h)
    // Bottom edge
    path.quadraticTo(w * 0.5f, h - wobble1, bottomLeftRadius, h)
    path.quadraticTo(0f, h, 0f, h - bottomLeftRadius)
    // Left edge
    path.quadraticTo(wobble2, h * 0.5f, 0f, topLeftRadius)
    path.quadraticTo(0f, 0f, topLeftRadius, 0f)
    path.close()
    return path
}

/**
 * Wobbly hand-drawn pencil border card (.sketch-card / .sketch-card-teal / .sketch-card-coral)
 * with tactile offset shadow and press-in spring animation.
 */
@Composable
fun SketchCard(
    modifier: Modifier = Modifier,
    backgroundColor: Color = SurfaceContainerLowest,
    borderColor: Color = OnSurfaceCharcoal,
    shadowColor: Color = OnSurfaceCharcoal,
    borderWidth: Dp = 2.dp,
    shadowOffsetX: Dp = 3.dp,
    shadowOffsetY: Dp = 3.5.dp,
    cornerRadius: Dp = 15.dp,
    rotationDegrees: Float = 0f,
    wobbleSeed: Int = 1,
    onClick: (() -> Unit)? = null,
    contentAlignment: Alignment = Alignment.TopStart,
    content: @Composable BoxScope.() -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val pressTranslateX by animateDpAsState(
        targetValue = if (isPressed && onClick != null) 2.dp else 0.dp,
        animationSpec = spring(stiffness = Spring.StiffnessHigh),
        label = "pressTranslateX"
    )
    val pressTranslateY by animateDpAsState(
        targetValue = if (isPressed && onClick != null) 2.dp else 0.dp,
        animationSpec = spring(stiffness = Spring.StiffnessHigh),
        label = "pressTranslateY"
    )
    val activeShadowX by animateDpAsState(
        targetValue = if (isPressed && onClick != null) 1.dp else shadowOffsetX,
        animationSpec = spring(stiffness = Spring.StiffnessHigh),
        label = "activeShadowX"
    )
    val activeShadowY by animateDpAsState(
        targetValue = if (isPressed && onClick != null) 1.dp else shadowOffsetY,
        animationSpec = spring(stiffness = Spring.StiffnessHigh),
        label = "activeShadowY"
    )
    val scale by animateFloatAsState(
        targetValue = if (isPressed && onClick != null) 0.988f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "cardScale"
    )

    val clickModifier = if (onClick != null) {
        Modifier.clickable(
            interactionSource = interactionSource,
            indication = null,
            onClick = onClick
        )
    } else {
        Modifier
    }

    val shape = remember(cornerRadius, wobbleSeed) {
        GenericShape { size, _ ->
            val r = cornerRadius.value * 2.6f
            addPath(
                buildWobblyRectPath(
                    width = size.width,
                    height = size.height,
                    topLeftRadius = r.coerceAtMost(size.width * 0.2f),
                    topRightRadius = (r * 0.85f).coerceAtMost(size.width * 0.2f),
                    bottomRightRadius = (r * 1.05f).coerceAtMost(size.width * 0.2f),
                    bottomLeftRadius = (r * 0.9f).coerceAtMost(size.width * 0.2f),
                    wobbleSeed = wobbleSeed
                )
            )
        }
    }

    Box(
        modifier = modifier
            .graphicsLayer {
                rotationZ = rotationDegrees
                scaleX = scale
                scaleY = scale
            }
            .offset(x = pressTranslateX, y = pressTranslateY)
            .then(clickModifier)
            .drawBehind {
                val rTopLeft = cornerRadius.toPx() * 1.05f
                val rTopRight = cornerRadius.toPx() * 0.85f
                val rBotRight = cornerRadius.toPx() * 1.1f
                val rBotLeft = cornerRadius.toPx() * 0.92f

                val shadowPath = buildWobblyRectPath(
                    width = size.width,
                    height = size.height,
                    topLeftRadius = rTopLeft,
                    topRightRadius = rTopRight,
                    bottomRightRadius = rBotRight,
                    bottomLeftRadius = rBotLeft,
                    wobbleSeed = wobbleSeed
                )
                // Draw solid offset shadow
                drawContext.canvas.save()
                drawContext.canvas.translate(activeShadowX.toPx(), activeShadowY.toPx())
                drawPath(path = shadowPath, color = shadowColor)
                drawContext.canvas.restore()

                // Draw card fill
                val cardPath = buildWobblyRectPath(
                    width = size.width,
                    height = size.height,
                    topLeftRadius = rTopLeft,
                    topRightRadius = rTopRight,
                    bottomRightRadius = rBotRight,
                    bottomLeftRadius = rBotLeft,
                    wobbleSeed = wobbleSeed
                )
                drawPath(path = cardPath, color = backgroundColor)

                // Draw wobbly charcoal border
                drawPath(
                    path = cardPath,
                    color = borderColor,
                    style = Stroke(
                        width = borderWidth.toPx(),
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )
            }
            .clip(shape),
        contentAlignment = contentAlignment,
        content = content
    )
}

/**
 * Wobbly hand-drawn pill (.sketch-pill) with 1.5dp border and 2dp solid offset shadow.
 */
@Composable
fun SketchPill(
    modifier: Modifier = Modifier,
    backgroundColor: Color = SurfaceContainerLowest,
    borderColor: Color = OnSurfaceCharcoal,
    shadowColor: Color = OnSurfaceCharcoal,
    borderWidth: Dp = 1.5.dp,
    shadowOffset: Dp = 2.dp,
    rotationDegrees: Float = 0f,
    onClick: (() -> Unit)? = null,
    contentAlignment: Alignment = Alignment.Center,
    content: @Composable BoxScope.() -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    val pressTranslate by animateDpAsState(
        targetValue = if (isPressed && onClick != null) 1.5.dp else 0.dp,
        animationSpec = spring(stiffness = Spring.StiffnessHigh),
        label = "pillPressTranslate"
    )
    val activeShadow by animateDpAsState(
        targetValue = if (isPressed && onClick != null) 0.5.dp else shadowOffset,
        animationSpec = spring(stiffness = Spring.StiffnessHigh),
        label = "pillShadow"
    )
    val scale by animateFloatAsState(
        targetValue = if (isPressed && onClick != null) 0.96f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "pillScale"
    )

    val clickModifier = if (onClick != null) {
        Modifier.clickable(
            interactionSource = interactionSource,
            indication = null,
            onClick = onClick
        )
    } else {
        Modifier
    }

    Box(
        modifier = modifier
            .graphicsLayer {
                rotationZ = rotationDegrees
                scaleX = scale
                scaleY = scale
            }
            .offset(x = pressTranslate, y = pressTranslate)
            .then(clickModifier)
            .drawBehind {
                val r = (size.height / 2f).coerceAtMost(18.dp.toPx())
                val rrShadow = RoundRect(
                    rect = Rect(
                        offset = Offset(activeShadow.toPx(), activeShadow.toPx()),
                        size = size
                    ),
                    topLeft = CornerRadius(r * 1.1f, r * 0.9f),
                    topRight = CornerRadius(r * 0.85f, r * 1.05f),
                    bottomRight = CornerRadius(r * 1.08f, r * 0.92f),
                    bottomLeft = CornerRadius(r * 0.9f, r * 1.1f)
                )
                val shadowPath = Path().apply { addRoundRect(rrShadow) }
                drawPath(shadowPath, color = shadowColor)

                val rrFill = RoundRect(
                    rect = Rect(offset = Offset.Zero, size = size),
                    topLeft = CornerRadius(r * 1.1f, r * 0.9f),
                    topRight = CornerRadius(r * 0.85f, r * 1.05f),
                    bottomRight = CornerRadius(r * 1.08f, r * 0.92f),
                    bottomLeft = CornerRadius(r * 0.9f, r * 1.1f)
                )
                val fillPath = Path().apply { addRoundRect(rrFill) }
                drawPath(fillPath, color = backgroundColor)
                drawPath(
                    fillPath,
                    color = borderColor,
                    style = Stroke(
                        width = borderWidth.toPx(),
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )
            }
            .clip(RoundedCornerShape(18.dp)),
        contentAlignment = contentAlignment,
        content = content
    )
}

/**
 * Translucent masking tape accent (.sketch-tape) placed on polaroids and sticky notes.
 */
@Composable
fun SketchTape(
    modifier: Modifier = Modifier,
    rotationDegrees: Float = -2f,
    content: @Composable (BoxScope.() -> Unit)? = null
) {
    Box(
        modifier = modifier
            .rotate(rotationDegrees)
            .drawBehind {
                drawRect(
                    color = OnSurfaceCharcoal.copy(alpha = 0.2f),
                    topLeft = Offset(1.dp.toPx(), 1.dp.toPx()),
                    size = size
                )
                drawRect(
                    color = TapeAmber,
                    topLeft = Offset.Zero,
                    size = size
                )
                drawRect(
                    color = OnSurfaceCharcoal.copy(alpha = 0.22f),
                    topLeft = Offset.Zero,
                    size = size,
                    style = Stroke(width = 1.dp.toPx())
                )
            },
        contentAlignment = Alignment.Center
    ) {
        if (content != null) {
            content()
        }
    }
}

/**
 * Hand-drawn wavy divider line between sections.
 */
@Composable
fun WavyDividerDoodle(
    color: Color,
    isDashed: Boolean = true,
    invertWave: Boolean = false,
    modifier: Modifier = Modifier
) {
    val (scrollProgress, trackMod) = rememberScrollParallaxProgress()
    Box(
        modifier = modifier
            .fillMaxWidth()
            .then(trackMod)
            .padding(horizontal = 24.dp, vertical = 6.dp)
            .graphicsLayer {
                val p = scrollProgress.value
                translationX = p * 16.dp.toPx()
                alpha = (1f - abs(p) * 0.35f).coerceIn(0.4f, 1f)
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(12.dp)
        ) {
            val path = Path()
            val midY = size.height / 2f
            val amp = if (invertWave) -4.dp.toPx() else 4.dp.toPx()
            path.moveTo(2f, midY)
            val segments = 6
            val segWidth = (size.width - 4f) / segments
            for (i in 0 until segments) {
                val startX = 2f + i * segWidth
                val ctrlX = startX + segWidth / 2f
                val endX = startX + segWidth
                val dir = if (i % 2 == 0) -1f else 1f
                path.quadraticTo(ctrlX, midY + amp * dir, endX, midY)
            }
            drawPath(
                path = path,
                color = color,
                style = Stroke(
                    width = 2.dp.toPx(),
                    cap = StrokeCap.Round,
                    pathEffect = if (isDashed) {
                        PathEffect.dashPathEffect(floatArrayOf(6.dp.toPx(), 4.dp.toPx()), 0f)
                    } else null
                )
            )
        }
    }
}

/**
 * Dashed horizontal separator inside cards.
 */
@Composable
fun DashedLineSeparator(
    modifier: Modifier = Modifier,
    color: Color = OnSurfaceCharcoal.copy(alpha = 0.16f)
) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(1.5.dp)
    ) {
        drawLine(
            color = color,
            start = Offset(0f, size.height / 2f),
            end = Offset(size.width, size.height / 2f),
            strokeWidth = 1.2.dp.toPx(),
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(5.dp.toPx(), 4.dp.toPx()), 0f)
        )
    }
}
